const { default: ffmpeg } = await 'fluent-ffmpeg'.import()
const path = await 'path'.import()
const { mkdir, writeFile, unlink, readFile } = await 'fs/promises'.import()
const { existsSync } = await 'fs'.import()
const axios = await 'axios'.import()

async function hdVideo(url) {

  const tempDir = path.join(process.cwd(), 'tmp')
  if (!existsSync(tempDir)) await mkdir(tempDir, { recursive: true })

  const inputPath = path.join(tempDir, `input_${Date.now()}.mp4`)
  const outputPath = path.join(tempDir, `output_${Date.now()}.mp4`)

  try {
    const res = await axios.get(url, { responseType: 'arraybuffer' })
    await writeFile(inputPath, res.data)

    await new Promise((resolve, reject) => {
      ffmpeg(inputPath)
        .outputOptions([
          '-vf', 'scale=iw*1.5:ih*1.5:flags=lanczos,eq=contrast=1:saturation=1.7,hqdn3d=1.5:1.5:6:6,unsharp=5:5:0.8:5:5:0.8',
          '-r', '60',
          '-preset', 'faster',
          '-crf', '25',
          '-c:v', 'libx264',
          '-pix_fmt', 'yuv420p',
          '-c:a', 'aac',
          '-b:a', '128k'
        ])
        .on('end', resolve)
        .on('error', reject)
        .save(outputPath)
    })

    const buffer = await readFile(outputPath)
    return buffer

  } catch (err) {
    console.error('❌ Gagal proses HD Video:', err.message)
    return null
  } finally {
    setTimeout(() => {
      unlink(inputPath).catch(() => {})
      unlink(outputPath).catch(() => {})
    }, 15_000)
  }
}

export { hdVideo }