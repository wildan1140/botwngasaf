/*
* Nama fitur : Search Plugin (film, game, hp)
* Type : Plugin Esm
* Sumber : https://whatsapp.com/channel/0029Vb6T6Qw5q08m9GqqEh2E
* Author : © Xaviermarket 
*/

const axios = (await import('axios')).default
const translate = await import('@vitalets/google-translate-api')
const cheerio = await import('cheerio')

//==================== IMDB MOVIE API ====================//
async function getIMDbMovie(query) {
  try {
    if (query.includes('imdb.com/title/')) {
      console.log('Menggunakan URL IMDb langsung:', query)
      const movieUrl = query.replace('m.imdb.com', 'www.imdb.com')
      return await scrapeIMDbPage(movieUrl)
    }
    
    const omdbApiKey = 'http://www.omdbapi.com/?apikey=trilogy&t='
    const omdbUrl = `${omdbApiKey}${encodeURIComponent(query)}`
    
    console.log('Mencari film via OMDB:', omdbUrl)
    
    const omdbResponse = await axios.get(omdbUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    })
    
    const omdbData = omdbResponse.data
    
    if (omdbData.Response === 'False') {
      console.log('Film tidak ditemukan di OMDB, coba IMDb scraping...')
      
      const searchUrl = `https://www.imdb.com/find/?q=${encodeURIComponent(query)}&s=tt&ttype=ft&ref_=fn_ft`
      
      const searchResponse = await axios.get(searchUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.9',
          'Accept-Encoding': 'gzip, deflate',
          'Connection': 'keep-alive',
          'Upgrade-Insecure-Requests': '1'
        }
      })
      
      const $ = cheerio.load(searchResponse.data)
      let firstResult = $('.ipc-metadata-list-summary-item__t').first().attr('href') ||
                       $('.find-section .find-title-result').first().find('h3 a').attr('href') ||
                       $('.findResult').first().find('.result_text a').attr('href') ||
                       $('.titleResult').first().find('a').attr('href')
      
      if (!firstResult) return null
      
      const movieUrl = firstResult.startsWith('http') ? firstResult : `https://www.imdb.com${firstResult}`
      return await scrapeIMDbPage(movieUrl)
    }
    
    const movie = {
      title: omdbData.Title,
      year: omdbData.Year,
      rating: omdbData.imdbRating && omdbData.imdbRating !== 'N/A' ? omdbData.imdbRating : null,
      ratingCount: omdbData.imdbVotes,
      duration: omdbData.Runtime,
      genre: omdbData.Genre ? omdbData.Genre.split(', ') : [],
      plot: omdbData.Plot,
      director: omdbData.Director ? omdbData.Director.split(', ') : [],
      cast: omdbData.Actors ? omdbData.Actors.split(', ').slice(0, 5) : [],
      poster: omdbData.Poster && omdbData.Poster !== 'N/A' ? omdbData.Poster : null,
      releaseDate: omdbData.Released,
      country: omdbData.Country,
      language: omdbData.Language,
      budget: omdbData.BoxOffice,
      boxOffice: omdbData.BoxOffice
    }
    
    return movie
  } catch (error) {
    console.error('Error fetching movie:', error.message)
    throw new Error(`Gagal mengambil data film: ${error.message}`)
  }
}

async function scrapeIMDbPage(movieUrl) {
  try {
    console.log('Scraping IMDb URL:', movieUrl)
    
    const movieResponse = await axios.get(movieUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Referer': 'https://www.imdb.com/',
        'Cache-Control': 'no-cache'
      }
    })
    
    const $ = cheerio.load(movieResponse.data)
    const movie = {}
    
    movie.title = $('h1[data-testid="hero-title-block__title"]').text().trim() ||
                  $('h1.titleBar h1').text().trim() ||
                  $('h1.sc-afe43def-0').text().trim() ||
                  $('.title_wrapper h1').text().trim() ||
                  $('h1').first().text().trim()
    
    movie.year = $('.sc-afe43def-0 a').first().text().trim() ||
                 $('[data-testid="hero-title-block__metadata"] a').first().text().trim() ||
                 $('.titleBar .subtext a').first().text().trim() ||
                 $('span.titleYear a').text().trim().replace(/[()]/g, '')
    
    movie.rating = $('[data-testid="hero-rating-bar__aggregate-rating__score"] span').first().text().trim() ||
                   $('.ratingValue strong span').text().trim() ||
                   $('.sc-bde20123-1').text().trim()
    
    movie.ratingCount = $('[data-testid="hero-rating-bar__aggregate-rating__score"]').next().text().trim() ||
                        $('.imdbRating .small').text().trim() ||
                        $('.sc-bde20123-3').text().trim()
    
    movie.duration = $('[data-testid="title-techspec_runtime"] .ipc-metadata-list-item__content-container').text().trim() ||
                     $('.subtext time').text().trim() ||
                     $('time[datetime]').text().trim()
    
    movie.genre = []
    $('[data-testid="genres"] .ipc-chip').each((i, elem) => {
      const genre = $(elem).text().trim()
      if (genre) movie.genre.push(genre)
    })
    
    if (movie.genre.length === 0) {
      $('.subtext a[href*="/genre/"]').each((i, elem) => {
        const genre = $(elem).text().trim()
        if (genre) movie.genre.push(genre)
      })
    }
    
    movie.plot = $('[data-testid="plot"] .sc-466bb6c-0').text().trim() ||
                 $('[data-testid="storyline-plot-summary"]').text().trim() ||
                 $('.summary_text').text().trim() ||
                 $('.plot_summary .summary_text').text().trim() ||
                 $('p[data-testid="plot"]').text().trim()
    
    movie.director = []
    $('[data-testid="title-pc-principal-credit"]:contains("Director") a').each((i, elem) => {
      const director = $(elem).text().trim()
      if (director) movie.director.push(director)
    })
    
    if (movie.director.length === 0) {
      $('.credit_summary_item h4:contains("Director")').next('p').find('a').each((i, elem) => {
        const director = $(elem).text().trim()
        if (director && !director.includes('more')) movie.director.push(director)
      })
    }

    movie.cast = []
    $('[data-testid="title-cast"] [data-testid="title-cast-item"] a[data-testid="title-cast-item__actor"]').each((i, elem) => {
      if (i < 5) {
        const actor = $(elem).text().trim()
        if (actor) movie.cast.push(actor)
      }
    })
    
    if (movie.cast.length === 0) {
      $('.cast_list .primary_photo + td a').each((i, elem) => {
        if (i < 5) {
          const actor = $(elem).text().trim()
          if (actor) movie.cast.push(actor)
        }
      })
    }
    
    movie.poster = $('[data-testid="hero-media__poster"] img').attr('src') ||
                   $('.poster img').attr('src') ||
                   $('img[alt*="Poster"]').attr('src') ||
                   $('.titlePoster img').attr('src')
    
    if (movie.poster && movie.poster.includes('@')) {
      movie.poster = movie.poster.split('@')[0] + '@._V1_UX300_CR0,0,300,444_AL_.jpg'
    }
    
    movie.releaseDate = $('[data-testid="title-details-releasedate"] a').text().trim() ||
                        $('.subtext a[title*="Release Info"]').text().trim()
    
    movie.country = $('[data-testid="title-details-origin"] .ipc-metadata-list-item__list-content-item').first().text().trim() ||
                    $('a[href*="/country/"]').first().text().trim()
    
    movie.language = $('[data-testid="title-details-languages"] .ipc-metadata-list-item__list-content-item').first().text().trim() ||
                     $('a[href*="/language/"]').first().text().trim()
    
    console.log('Scraped movie data:', {
      title: movie.title,
      year: movie.year,
      rating: movie.rating,
      hasGenres: movie.genre.length > 0,
      hasPlot: !!movie.plot,
      hasPoster: !!movie.poster
    })
    
    return movie
  } catch (error) {
    console.error('Error scraping IMDb page:', error.message)
    return null
  }
}

//==================== PHONE SPECS API ====================//
async function getPhoneSpecs(query) {
  try {
    const searchUrl = `https://www.gsmarena.com/results.php3?sQuickSearch=yes&sName=${encodeURIComponent(query)}`
    
    const searchResponse = await axios.get(searchUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1'
      }
    })
    
    const $ = cheerio.load(searchResponse.data)
    let firstResult = $('.makers ul li').first().find('a').attr('href')
    
    if (!firstResult) {
      firstResult = $('div.makers ul li').first().find('a').attr('href')
    }
    
    if (!firstResult) return null
    
    const phoneUrl = firstResult.startsWith('http') ? firstResult : `https://www.gsmarena.com/${firstResult}`
    
    const phoneResponse = await axios.get(phoneUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Referer': 'https://www.gsmarena.com/'
      }
    })
    
    const phoneData = cheerio.load(phoneResponse.data)
    
    const specs = {}
    
    specs.name = phoneData('h1.specs-phone-name-title').text().trim() || 
                phoneData('.specs-phone-name-title').text().trim() ||
                phoneData('h1').first().text().trim()
                
    specs.image = phoneData('.specs-photo-main img').attr('src') || 
                  phoneData('img.center').attr('src')
    
    if (specs.image && !specs.image.startsWith('http')) {
      specs.image = `https://www.gsmarena.com/${specs.image}`
    }
    
    phoneData('#specs-list table, .specs-brief table').each((i, table) => {
      const category = phoneData(table).find('th').first().text().trim().toLowerCase()
      
      phoneData(table).find('tr').each((j, row) => {
        const key = phoneData(row).find('.ttl, td:first-child').text().trim()
        const value = phoneData(row).find('.nfo, td:last-child').text().trim()
        
        if (key && value && key !== value) {
          const keyLower = key.toLowerCase()
          
          if (keyLower.includes('technology')) specs.technology = value
          if (keyLower.includes('2g') && keyLower.includes('band')) specs.bands2g = value  
          if (keyLower.includes('3g') && keyLower.includes('band')) specs.bands3g = value
          if (keyLower.includes('4g') && keyLower.includes('band')) specs.bands4g = value
          if (keyLower.includes('speed')) specs.speed = value
          if (keyLower.includes('announced')) specs.announced = value
          if (keyLower.includes('status')) specs.status = value
          if (keyLower.includes('dimensions')) specs.dimensions = value
          if (keyLower.includes('weight')) specs.weight = value
          if (keyLower.includes('build')) specs.build = value
          if (keyLower.includes('sim')) specs.sim = value
          if (keyLower.includes('type') && !specs.displayType) specs.displayType = value
          if (keyLower.includes('size') && keyLower.includes('inch')) specs.displaySize = value
          if (keyLower.includes('resolution')) specs.resolution = value
          if (keyLower.includes('protection')) specs.protection = value
          if (keyLower.includes('os')) specs.os = value
          if (keyLower.includes('chipset')) specs.chipset = value
          if (keyLower.includes('cpu')) specs.cpu = value
          if (keyLower.includes('gpu')) specs.gpu = value
          if (keyLower.includes('card slot')) specs.cardSlot = value
          if (keyLower.includes('internal') && !specs.internal) specs.internal = value
          
          if (keyLower.includes('triple') || keyLower.includes('quad') || keyLower.includes('dual')) {
            if (!specs.mainCamera) specs.mainCamera = value
          }
          if (keyLower.includes('primary') || (keyLower.includes('main') && keyLower.includes('camera'))) {
            if (!specs.mainCamera) specs.mainCamera = value
          }
          if (keyLower.includes('secondary') || keyLower.includes('selfie') || keyLower.includes('front')) {
            if (!specs.selfieCamera) specs.selfieCamera = value
          }
          if (keyLower.includes('single') && category.includes('selfie')) {
            specs.selfieCamera = value
          }
        }
      })
    })
    
    if (!specs.mainCamera || !specs.selfieCamera) {
      phoneData('table').each((i, table) => {
        const tableText = phoneData(table).text().toLowerCase()
        
        if (tableText.includes('main camera') || tableText.includes('primary camera')) {
          phoneData(table).find('tr').each((j, row) => {
            const cells = phoneData(row).find('td')
            if (cells.length >= 2) {
              const key = phoneData(cells[0]).text().trim().toLowerCase()
              const value = phoneData(cells[1]).text().trim()
              
              if ((key.includes('triple') || key.includes('quad') || key.includes('dual') || key.includes('primary')) && value) {
                if (!specs.mainCamera) specs.mainCamera = value
              }
            }
          })
        }
        
        if (tableText.includes('selfie camera') || tableText.includes('secondary camera')) {
          phoneData(table).find('tr').each((j, row) => {
            const cells = phoneData(row).find('td')
            if (cells.length >= 2) {
              const key = phoneData(cells[0]).text().trim().toLowerCase()
              const value = phoneData(cells[1]).text().trim()
              
              if ((key.includes('single') || key.includes('secondary') || key.includes('selfie')) && value) {
                if (!specs.selfieCamera) specs.selfieCamera = value
              }
            }
          })
        }
      })
    }
    
    return specs
  } catch (error) {
    console.error('Error fetching phone specs:', error.message)
    throw new Error(`Gagal mengambil data: ${error.message}`)
  }
}

//==================== RAWG GAME API ====================//
async function getRAWGGame(query) {
  try {
    const apiKey = "6dc0ad5a17da4266979daba28d46bc14"
    
    console.log('Mencari game via RAWG:', query)
    
    const searchUrl = `https://api.rawg.io/api/games?key=${apiKey}&search=${encodeURIComponent(query)}&page_size=10`
    
    const searchResponse = await axios.get(searchUrl, { 
      timeout: 10000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    })

    const searchData = searchResponse.data

    if (!searchData.results || searchData.results.length === 0) {
      console.log('Game tidak ditemukan di RAWG')
      return null
    }

    const searchLower = query.toLowerCase()
    
    const calculateSimilarity = (gameName, searchQuery) => {
      const gameNameLower = gameName.toLowerCase()
      const queryWords = searchQuery.toLowerCase().split(' ')
      let score = 0
      
      if (gameNameLower === searchQuery) return 100
      
      if (searchQuery.includes('god of war 2') || searchQuery.includes('god of war ii')) {
        if (gameNameLower.includes('god of war ii') || 
            gameNameLower.includes('god of war 2') ||
            gameNameLower.match(/god of war\s*2(?!\d)/)) {
          score += 80
        }
        if (gameNameLower.includes('2018') || gameNameLower.includes('(2018)')) {
          score -= 30
        }
      }
      
      if (gameNameLower.includes(searchQuery)) score += 50
      
      queryWords.forEach(word => {
        if (gameNameLower.includes(word)) score += 10
      })
      
      if (searchQuery.includes('2') && gameNameLower.includes('ii')) score += 20
      if (searchQuery.includes('3') && gameNameLower.includes('iii')) score += 20
      if (searchQuery.includes('4') && gameNameLower.includes('iv')) score += 20
      
      const gameWords = gameNameLower.split(' ')
      const extraWords = gameWords.length - queryWords.length
      if (extraWords > 2) score -= extraWords * 5
      
      return score
    }
    
    const scoredResults = searchData.results.map(game => ({
      ...game,
      score: calculateSimilarity(game.name, searchLower)
    }))
    
    scoredResults.sort((a, b) => b.score - a.score)
    
    const bestMatch = scoredResults[0]
    
    console.log("Search results scoring:")
    scoredResults.slice(0, 5).forEach(game => {
      console.log(`${game.name}: ${game.score}`)
    })
    
    if (bestMatch.score < 15) {
      console.log('Tidak ada match yang cukup baik')
      return null
    }

    const gameUrl = `https://api.rawg.io/api/games/${bestMatch.slug}?key=${apiKey}`
    
    const gameResponse = await axios.get(gameUrl, { 
      timeout: 10000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    })

    const game = gameResponse.data

    const gameData = {
      title: game.name || "Tidak diketahui",
      about: game.description_raw || game.description || "Deskripsi tidak tersedia",
      platform: game.platforms?.map(p => p.platform?.name).filter(Boolean) || [],
      metascore: game.metacritic || "Belum ada skor",
      genre: game.genres?.map(g => g.name).filter(Boolean) || [],
      releaseDate: game.released || "Tanggal rilis tidak diketahui",
      developer: game.developers?.map(d => d.name).filter(Boolean) || [],
      publisher: game.publishers?.map(p => p.name).filter(Boolean) || [],
      ageRating: game.esrb_rating?.name || "Belum ada rating",
      tags: game.tags?.slice(0, 8).map(t => t.name).filter(Boolean) || [],
      image: game.background_image || ""
    }

    let translatedAbout = gameData.about
    if (translatedAbout && translatedAbout.length > 50 && translatedAbout !== "Deskripsi tidak tersedia") {
      try {
        const maxLength = 1000
        let shortDesc = translatedAbout
        
        if (translatedAbout.length > maxLength) {
          const sentences = translatedAbout.match(/[^\.!?]+[\.!?]+/g)
          if (sentences) {
            let currentLength = 0
            let cutIndex = 0
            
            for (let i = 0; i < sentences.length; i++) {
              currentLength += sentences[i].length
              if (currentLength > maxLength) break
              cutIndex = currentLength
            }
            
            if (cutIndex > 0) {
              shortDesc = translatedAbout.substring(0, cutIndex).trim()
            } else {
              shortDesc = translatedAbout.substring(0, maxLength) + "..."
            }
          } else {
            shortDesc = translatedAbout.substring(0, maxLength) + "..."
          }
        }
        
        const translated = await translate.translate(shortDesc, { to: "id" })
        translatedAbout = translated.text
        
        if (translatedAbout.length > 500) {
          const lastPeriod = translatedAbout.lastIndexOf('.')
          const lastExclamation = translatedAbout.lastIndexOf('!')
          const lastQuestion = translatedAbout.lastIndexOf('?')
          const lastSentenceEnd = Math.max(lastPeriod, lastExclamation, lastQuestion)
          
          if (lastSentenceEnd > 300) {
            translatedAbout = translatedAbout.substring(0, lastSentenceEnd + 1)
          }
        }
        
      } catch (translateError) {
        console.warn("Translation failed:", translateError.message)
        if (translatedAbout.length > 800) {
          const lastPeriod = translatedAbout.lastIndexOf('.', 800)
          if (lastPeriod > 300) {
            translatedAbout = translatedAbout.substring(0, lastPeriod + 1)
          } else {
            translatedAbout = translatedAbout.substring(0, 800) + "..."
          }
        }
      }
    }

    gameData.translatedAbout = translatedAbout

    console.log('Game data fetched:', {
      title: gameData.title,
      platform: gameData.platform.length,
      hasDescription: !!gameData.translatedAbout,
      hasImage: !!gameData.image
    })

    return gameData

  } catch (error) {
    console.error('Error fetching game:', error.message)
    throw new Error(`ada kesalahan: ${error.message}`)
  }
}

/*
* Nama fitur : Search Plugin (film, game, hp)
* Type : Plugin Esm
* Sumber : https://whatsapp.com/channel/0029Vb6T6Qw5q08m9GqqEh2E
* Author : © Xaviermarket 
*/

export { getIMDbMovie, getPhoneSpecs, getRAWGGame }