const { catbox } = await (fol[0] + 'catbox.js').r()
const sharp = (await 'sharp'.import()).default;
const axios = 'axios'.import();

async function profileUser(ppUrl) {
  const ppBuffer = (await axios.get(ppUrl, { responseType: 'arraybuffer' })).data;

  const profileImg = await sharp(ppBuffer)
    .resize(506, 506)
    .png()
    .toBuffer();

  const overlays = [
    'https://files.catbox.moe/11rx1s.png',
    'https://files.catbox.moe/ea03t0.png'
  ];
  const randomOverlay = overlays[Math.floor(Math.random() * overlays.length)];
  const overlayBuffer = (await axios.get(randomOverlay, { responseType: 'arraybuffer' })).data;

  const resultBuffer = await sharp({
    create: {
      width: 1920,
      height: 1080,
      channels: 4,
      background: { r: 0, g: 0, b: 0, alpha: 0 }
    }
  })
    .composite([
      { input: profileImg, top: 287, left: 707 },
      { input: overlayBuffer, top: 0, left: 0 }
    ])
    .jpeg({ quality: 75 })
    .toBuffer();

  const res = await catbox(resultBuffer)
  return res;
}


async function profileKece(url1, url2, teks = "", overlay) {
  const teksAsli = teks && teks.trim() ? teks : "ELAINA";
  const teksFinal = teksAsli
    .toUpperCase()
    .slice(0, 6)
    .split("").join(" ");

  let overlayURL;
  let overlayBlend = 'over';
  if (overlay === "ice") {
    overlayURL = "https://files.catbox.moe/rkxu9w.png";
    overlayBlend = 'color-dodge';
  } else {
    overlayURL = "https://files.catbox.moe/hi4eux.png";
    overlayBlend = 'over';
  }

  const img1Buffer = (
     await axios.get(
       url1, 
       {
          responseType: 'arraybuffer' 
       }
     )
  ).data;
  
  const img2Buffer = (
     await axios.get(
       url2, 
       {
          responseType: 'arraybuffer'
       }
     )
  ).data;
  
  const overlayBuffer = (
     await axios.get(
       overlayURL, 
       { 
         responseType: 'arraybuffer' 
       }
     )
  ).data;

  const background = await sharp(img1Buffer)
    .resize(1080, 1080, { fit: 'cover' })
    .blur(15)
    .toBuffer();

  const kotakLebar = 883;
  const kotakTinggi = 357;

  const fokusKotak = await sharp(img1Buffer)
    .resize(kotakLebar, kotakTinggi, { fit: 'cover' })
    .png()
    .toBuffer();

  const kotakStrokeShadow = Buffer.from(`
    <svg width="${kotakLebar + 8}" height="${kotakTinggi + 8}" xmlns="http://www.w3.org/2000/svg">
      <filter id="shadow" x="-50%" y="-50%" width="200%" height="200%">
        <feDropShadow dx="0" dy="0" stdDeviation="4" flood-color="black" flood-opacity="0.6"/>
      </filter>
      <rect x="4" y="4" width="${kotakLebar}" height="${kotakTinggi}" 
        fill="none" stroke="white" stroke-width="4" rx="4" ry="4" filter="url(#shadow)"/>
    </svg>
  `);

  const kotakFinal = await sharp({
    create: {
      width: kotakLebar + 8,
      height: kotakTinggi + 8,
      channels: 4,
      background: {
        r: 0, 
        g: 0, 
        b: 0, 
        alpha: 0 }
    }
  })
    .composite([
      {
         input: fokusKotak, 
         top: 4, 
         left: 4 
      },
      { 
        input: kotakStrokeShadow,
        top: 0,
        left: 0
      }
    ])
    .png()
    .toBuffer();

  const ukuranBulat = 254;
  const maskBulat = Buffer.from(
    `<svg width="${ukuranBulat}" height="${ukuranBulat}"><circle cx="${ukuranBulat / 2}" cy="${ukuranBulat / 2}" r="${ukuranBulat / 2}" fill="black"/></svg>`
  );
  const strokeBulat = Buffer.from(`
    <svg width="${ukuranBulat}" height="${ukuranBulat}" xmlns="http://www.w3.org/2000/svg">
      <circle cx="${ukuranBulat / 2}" cy="${ukuranBulat / 2}" r="${(ukuranBulat / 2) - 2}" 
        fill="none" stroke="white" stroke-width="4"/>
    </svg>
  `);

  const img2Bulat = await sharp(img2Buffer)
    .resize(ukuranBulat, ukuranBulat)
    .composite([{ input: maskBulat, blend: 'dest-in' }])
    .png()
    .toBuffer();

  const bulatFinal = await sharp({
    create: {
      width: ukuranBulat,
      height: ukuranBulat,
      channels: 4,
      background: { r: 0, g: 0, b: 0, alpha: 0 }
    }
  })
    .composite([
      { input: img2Bulat, top: 0, left: 0 },
      { input: strokeBulat, top: 0, left: 0 }
    ])
    .png()
    .toBuffer();

  const areaWidth = 1080 - 285;
  const marginKanan = 20;
  const posX = areaWidth - marginKanan;

  const teksSVG = Buffer.from(`
    <svg width="${areaWidth}" height="150" xmlns="http://www.w3.org/2000/svg">
      <style>
        .title {
          font-family: Arial, sans-serif;
          font-size: 40px;
          font-weight: bold;
          fill: white;
          fill-opacity: 0.65;
          letter-spacing: 4px;
        }
      </style>
      <text x="${posX}" y="50%" text-anchor="end" dominant-baseline="middle" class="title">${teksFinal}</text>
    </svg>
  `);

  const hasil = await sharp(background)
    .composite([
      {
         input: kotakFinal, 
         top: 245, 
         left: 95 
      },
      { 
        input: bulatFinal, 
        top: 545, 
        left: 95
      },
      { 
        input: 
        teksSVG, 
        top: 565,
        left: 190 
      },
      {
        input: overlayBuffer,
        top: 0,
        left: 0,
        blend: 'over', 
        blend: overlayBlend
      }
    ])
    .png()
    .toBuffer();

  return hasil;
}

export { profileUser, profileKece }