/*!-======[ Module Imports ]======-!*/
const chalk = 'chalk'.import();

/*!-======[ Default Export Function ]======-!*/
export default async function client({ Exp, store, cht, is }) {
  let { func } = Exp;
  try {
    if (cht.memories?.banned && !is.owner) {
      if (cht.memories.banned * 1 > Date.now()) return;
      func.archiveMemories.delItem(cht.sender, 'banned');
    }

    Data.preferences[cht.id].ai_interactive ??= Data.preferences[
      cht.id
    ].ai_interactive = cfg.ai_interactive[is.group ? 'group' : 'private'];
    let frmtEdMsg = cht?.msg?.length > 50 ? `\n${cht.msg}` : cht.msg;

    if (cht.msg) {
      cfg['autotyping'] && (await Exp.sendPresenceUpdate('composing', cht.id));
      cfg[is.group ? 'autoreadgc' : 'autoreadpc'] &&
        (await Exp.readMessages([cht.key]));
      console.log(
        func.logMessage(
          is.group ? 'GROUP' : 'PRIVATE',
          cht.id,
          cht.pushName,
          frmtEdMsg
        )
      );
    }

/*]========[ FUNGSI ]========[*/ 

let jam = parseInt(func.newDate().split(", ")[2].split(":")[0]);
let ucapan;
if (jam >= 4 && jam < 10) {
  ucapan = 'Selamat pagi... 🌄';
} else if (jam >= 10 && jam < 15) {
  ucapan = 'Selamat siang... ☀️';
} else if (jam >= 15 && jam < 18) {
  ucapan = 'Selamat Sore... 🌇';
} else if (jam >= 18 && jam <= 23) {
  ucapan = 'Selamat malam... 🌃';
} else {
  ucapan = 'Kamu gak tidur? 🙃';
}

const fakeQuoted = {
    key: {
      remoteJid: "status@broadcast",
      fromMe: false,
      id: "FAKE_ORDER_ID",
      participant: "0@s.whatsapp.net"
    },
    message: {
      orderMessage: {
        orderId: "1234567890",
        itemCount: 9999,
        status: 1,
        surface: 1,
        message: `ASTROBOT MD`,
        orderTitle: "Order #654321",
        thumbnail: Buffer.alloc(0),
        sellerJid: "0@s.whatsapp.net"
      }
    }
};

/*]========[ MENYAPA OWNER 😷 ]========[*/ 

const ownerIds = ['6283163686712@s.whatsapp.net'];
const cooldown = 30 * 60 * 1000;

const groupId = cht.id;
const sender = cht.sender;

if (is.group && ownerIds.includes(sender)) {
  Data.ownerMentioned ??= {};
  Data.ownerMentioned[groupId] ??= 0;

  const lastPing = Data.ownerMentioned[groupId];

  if (Date.now() - lastPing > cooldown) {
    Data.ownerMentioned[groupId] = Date.now();

    const teksList = [
  `Hyyy *${cht.pushName}*, ${ucapan}`,
  `😳 Ehh... muncul owner ku *${cht.pushName}*, apa kabar? Btw *${ucapan}*`,
  `😨 Alamak owner *${cht.pushName}* datang, ihkk takokknyee...`,
  `Owner *${cht.pushName}* terpantau 🤭`
];

    const teks = teksList[Math.floor(Math.random() * teksList.length)];

    await Exp.sendMessage(groupId, {
      text: teks,
      mentions: [sender]
    }, { quoted: fakeQuoted });
  }
}

/*spam group*/
const barDB = Data.preferences[cht.id] || {}
const spamDb = barDB.spamDb = barDB.spamDb || {}
const now = Date.now()

if (!spamDb[cht.sender]) spamDb[cht.sender] = []

spamDb[cht.sender].push(now)
spamDb[cht.sender] = spamDb[cht.sender].filter(ts => now - ts <= 10000)

const spamCount = spamDb[cht.sender].length

if (barDB.antispam && spamCount > 5 && is.group && !is.me && !is.owner && !is.groupAdmins && is.botAdmin) {
   	await Exp.groupParticipantsUpdate(cht.id, [cht.sender], 'remove')

	return await Exp.sendMessage(cht.id, {
		text: `\`[ WARNING ]\`\n\nHama grup terdeteksi...\n@${cht.sender.split('@')[0]} telah melakukan spam, dan telah di basmi dari grup ini 😤😏`,
		mentions: [cht.sender]
	}, { quoted: fakeQuoted })
}

    /*!-======[ Block Chat ]======-!*/
    if (!cfg.public && !is.owner && !is.me && !is.offline) return;
    if (cfg.public === 'onlygc' && !is.group && !is.owner) return;
    if (cfg.public === 'onlypc' && is.group && !is.owner) return;
    if (
      cfg.public === 'onlyjoingc' &&
      !is.owner &&
      cht.cmd &&
      cht.memories?.premium?.time < Date.now() &&
      cfg.gcurl?.length > 0
    ) {
      let isJoin;
      let list = cfg.gcurl.map((a) => `- ${a}`).join('\n');
      for (let i of cfg.gcurl) {
        let ii = i.split('/').slice(-1)[0];
        keys[ii] ??= await Exp.groupGetInviteInfo(ii).then((a) => a.id);
        let mem = await func
          .getGroupMetadata(keys[ii], Exp)
          .then((a) => a.participants.map((a) => a.id));
        if (mem.includes(cht.sender)) {
          isJoin = true;
          break;
        }
      }
      if (
        !isJoin &&
        (!cht.memories.cdIsJoin || cht.memories.cdIsJoin >= Date.now())
      ) {
        cht.memories.cdIsJoin = Date.now() + func.parseTimeString('10 menit');
        return cht.reply(
          `Anda harus bergabung ke salah satu grup dibawah sebelum dapat menggunakan bot!\n\`LIST INVITELINK\`\n${list}\n\n_Setelah bergabung harap tunggu selama 1 menit sebelum menggunakan bot!, data anggota grup hanya di perbarui setiap 1 menit sekali guna mengurangi rate-limit!_`
        );
      }
    }
    let except = is.antiTagall || is.antibot || is.antilink;
    if ((is.baileys || is.mute || is.onlyadmin) && !except) return;

    let exps = { Exp, store, cht, is };
    let ev = new Data.EventEmitter(exps);
    Data.ev ??= ev;
    if (!is.offline && !is.afk && (cht.cmd || cht.reaction)) {
      cht.cmd &&
        (await Promise.all([
          'questionCmd' in cht.memories &&
            func.archiveMemories.delItem(cht.sender, 'questionCmd'),
          ev.emit(cht.cmd),
        ]));
      cht.reaction && (await Data.reaction({ ev, ...exps }));
    } else {
      await Data.In({ ev, ...exps });
    }

    /*!-======[ Chat Interactions Add ]======-!*/
    !cht.cmd &&
      is.botMention &&
      (await func.archiveMemories.addChat(cht.sender));

    await func.archiveMemories.setItem(cht.sender, 'name', cht.pushName);
    func.archiveMemories.setItem(cht.sender, 'lastChat', Date.now());
  } catch (error) {
    console.error('Error in client.js:', error);
  }
  return;
}
