/*!-======[ Module Imports ]======-!*/
const fs = 'fs'.import();
const { generateWAMessageFromContent } = 'baileys'.import();
const { TermaiCdn } = await (fol[0] + 'cdn.termai.js').r();
let exif = await (fol[0] + 'exif.js').r();
let { convert } = exif;

const { imageEdit } = await (fol[2] + 'imageEdit.js').r();

/*!-======[ Default Export Function ]======-!*/
export default async function on({ cht, Exp, store, ev, is }) {
  let { sender, id } = cht;
  let { func } = Exp;
  let infos = Data.infos;

  ev.on(
    {
      cmd: ['pin', 'pinterest', 'pinterestsearch'],
      listmenu: ['pinterest'],
      tag: 'search',
      args: 'Cari apa?',
      badword: true,
      energy: 5,
    },
    async () => {
      let [query, geser] = cht?.q?.split('--geser');
      let amount = parseInt(geser?.split(' ')?.[1] || 5);
      amount = amount > 15 ? 15 : amount < 1 ? 1 : amount;
      let res = await fetch(
        `${api.xterm.url}/api/search/pinterest-image?query=${query}&key=${api.xterm.key}`
      ).then((a) => a.json());
      let { data } = res || {};
      if (data.length < 1) return cht.reply('Tidak ditemukan!');
      if (typeof geser == 'string') {
        let cards = [];
        data = data.slice(0, amount);

        for (let i of data) {
          let img = await Exp.func.uploadToServer(i);
          cards.push({
            header: {
              imageMessage: img,
              hasMediaAttachment: true,
            },
            body: { text: `#${cards.length + 1}` },
            nativeFlowMessage: {
              buttons: [
                {
                  name: 'cta_url',
                  buttonParamsJson:
                    '{"display_text":"WhatsappChannel","url":"https://whatsapp.com/channel/0029VaauxAt4Y9li9UtlCu1V","webview_presentation":null}',
                },
              ],
            },
          });
        }

        let msg = generateWAMessageFromContent(
          id,
          {
            viewOnceMessage: {
              message: {
                interactiveMessage: {
                  body: {
                    text: `Result from "${query?.trim()}"`,
                  },
                  carouselMessage: {
                    cards,
                    messageVersion: 1,
                  },
                },
              },
            },
          },
          {}
        );

        Exp.relayMessage(msg.key.remoteJid, msg.message, {
          messageId: msg.key.id,
        });
      } else {
        Exp.sendMessage(
          id,
          { image: { url: data.slice(0, 10).getRandom() } },
          { quoted: cht }
        );
      }
    }
  );

ev.on(
    {
      cmd: ['tofigur1', 'jadifigur1'],
      listmenu: ['tofigur1'],
      tag: "tools",
      energy: 55,
      media: {
        type: [
          'image'
        ]
      }
    },
    async ({ media }) => {
    
      let promp = "use the model 1/7 scale in the ilustration, in a realistic style and environment. place the figure on a computer desk, use in circular transparent acrylic base without any text. on the computer screen, display the 3D modeling process off the figure. next to the computer screen place a tamiya-style toy packaging box printed with the original artwork"
      try {
        if (is.sticker || is.quoted?.sticker) {
          let url = await tmpFiles(media);
          let cv = await convert({
            url,
            from: 'webp',
            to: 'png',
          });
          media = await func.getBuffer(cv);
        }
        
        Exp.sendMessage(
          id,
          {
            image: await imageEdit(await func.minimizeImage(media), promp),
            caption: "✅ Berhasil membuat figur"
          }, { quoted: cht }
        )
      
      } catch (e) {
        return reply(
          "Gagal membuat figur\n\n*Error*:\n" + e
        )
      }
    }
  );
  
ev.on(
  {
    cmd: ['tofigur', 'jadifigur'],
    listmenu: ['tofigur'],
    tag: "tools",
    energy: 55,
    media: {
      type: ['image']
    }
  },
  async ({ media }) => {
    const promp = "use the model 1/7 scale in the ilustration, in a realistic style and environment. place the figure on a computer desk, use in circular transparent acrylic base without any text. on the computer screen, display the 3D modeling process off the figure. next to the computer screen place a tamiya-style toy packaging box printed with the original artwork";

    try {
      if (is.sticker || is.quoted?.sticker) {
        media = await sharp(media).png().toBuffer();
      }

      const imageBuffer = await imageEdit(media, promp);
      if (!Buffer.isBuffer(imageBuffer)) throw new Error("Gagal menghasilkan gambar.");

      await Exp.sendMessage(id, {
        image: imageBuffer,
        caption: "✅ Berhasil membuat figur"
      }, { quoted: cht });

    } catch (e) {
      reply("Gagal membuat figur\n\n*Error:*\n" + e.message);
    }
  }
);

ev.on({
 cmd: ['infogempa'],
 listmenu: ['infogempa'],
 tags: "search",
 energy: 25
}, async ({ cht }) => {

 cht.reply("*Mencari informasi gempa...*");
 await sleep(2500);

try {
        const response = await fetch("https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json");
        const data = await response.json();
        
        if (!data || !data.Infogempa || !data.Infogempa.gempa) {
            return cht.reply("Gagal mendapatkan data gempa dari BMKG.");
        }
        
        const gempa = data.Infogempa.gempa;
        
        let caption = `*📈 INFO GEMPA TERKINI*\n\n`;
        caption += `*Tanggal:* ${gempa.Tanggal}\n`;
        caption += `*Waktu:* ${gempa.Jam}\n`;
        caption += `*Magnitudo:* ${gempa.Magnitude}\n`;
        caption += `*Kedalaman:* ${gempa.Kedalaman}\n`;
        caption += `*Lokasi:* ${gempa.Wilayah}\n`;
        caption += `*Koordinat:* ${gempa.Lintang} ${gempa.Bujur}\n`;
        caption += `*Potensi:* ${gempa.Potensi}\n`;
        caption += `*Dirasakan:* ${gempa.Dirasakan}\n\n`;
        caption += `Sumber: BMKG (https://www.bmkg.go.id/)`;
        
        if (gempa.Shakemap) {
            const shakemapUrl = `https://data.bmkg.go.id/DataMKG/TEWS/${gempa.Shakemap}`;
            await Exp.sendMessage(cht.id, {
                image: { url: shakemapUrl },
                caption: caption
            }, { quoted: cht });
        } else {
           await Exp.sendMessage(cht.id, { text: caption }, { quoted: cht });
        }
    } catch (error) {
        console.log(error);
        cht.reply("Terjadi kesalahan saat mengambil data gempa.");
    }
})

ev.on({
  cmd: ['ppcp', 'propilcouple'],
  listmenu: ['ppcp'],
  tag: 'search',
  energy: 25
}, async ({ cht }) => {
  await cht.edit("*_Woke Tunggu..._*", keys[sender])
  try {
    const res = await fetch('https://api.botcahx.eu.org/api/randomgambar/couplepp?apikey=barXbar');
    const data = await res.json();

    if (!data?.status || !data?.result) {
      return cht.reply('👾 Api tidak merespon permintaan');
    }

    const { male, female } = data.result;

    await Exp.sendMessage(cht.id, {
      image: { url: male },
      caption: 'Ini untuk pp cowok'
    }, { quoted: cht });
    await sleep(1000)
    await Exp.sendMessage(cht.id, {
      image: { url: female },
      caption: 'Dan ini untuk pp ceweknya...'
    }, { quoted: cht });

  } catch (e) {
    console.error(e);
    return cht.reply(`Gagal mendapatkan pp couple\n\n• *Error*:\n${e.message}\n\n> Segera lapor ke owner`);
  }
});


  ev.on(
    {
      cmd: ['pinstik', 'pinstick', 'pinstiker', 'pinsticker'],
      listmenu: ['pinsticker'],
      tag: 'search',
      energy: 5,
      args: `Mau cari sticker apa?`,
    },
    async ({ args }) => {
      try {
        let res = await fetch(
          `${api.xterm.url}/api/search/pinterest-image?query=${args}&key=${api.xterm.key}`
        ).then((a) => a.json());
        let { data } = res || {};
        if (data.length < 1) return cht.reply('Tidak ditemukan!');
        let url = await convert({
          url: data.slice(0, 20).getRandom(),
          from: 'jpg',
          to: 'webp',
        });
        let buff = await func.getBuffer(url);
        let s = await exif['writeExifImg'](
          buff,
          {
            packname: 'My sticker',
            author: 'Ⓒ' + cht.pushName,
          },
          true
        );
        Exp.sendMessage(
          id,
          {
            sticker: {
              url: s,
            },
          },
          {
            quoted: cht,
          }
        );
      } catch (e) {
        console.error(e);
        await cht.reply('Failed convert image to sticker!');
        throw new Error(e);
      }
    }
  );

ev.on({
  cmd: ['spotifysearch','spsh'],
  listmenu: ['spotifysh'],
  tag: 'search',
  energy: 15
}, async ({ cht, args }) => {
  const query = Array.isArray(args) ? args.join(' ') : String(args || '');
  if (!query) return cht.reply('❌ Masukkan kata kunci lagu!\nContoh: *.spotifysearch nona Ambon*');
  
  await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });

  try {
    const res = await fetch(`https://api.botcahx.eu.org/api/search/spotify?query=${encodeURIComponent(query)}&apikey=barXbar`);
    const json = await res.json();

    const data = json?.result?.data;
    if (!json?.status || !data || !data.length) {
      return cht.reply('❌ Lagu tidak ditemukan.');
    }

    const shuffled = data.sort(() => 0.10 - Math.random());
    const selected = shuffled.slice(0, 10);

    const teks = selected.map((lagu, i) => 
      `${i + 1}. \`${lagu.title}\`\n⏳ Durasi: ${lagu.duration}\n📊 Popularitas: ${lagu.popularity}\n🔗 ${lagu.url}`
    ).join('\n\n');

   await Exp.sendMessage(cht.id, {
    text: teks,
    contextInfo: {
      externalAdReply: {
        title: `Spotify Search 🔍`,
        body: `© ASTROBOT MD ✓`,
        thumbnail: fs.readFileSync(fol[3] + 'spotify.jpg'),
        mediaUrl: `https://chat.whatsapp.com/G6axMRtSDIT4wvgNRgBTPz`,
        sourceUrl: `https://www.tiktok.com/@barzz918`,
        renderLargerThumbnail: true,
        showAdAttribution: true,
        mediaType: 1,
      },
      forwardingScore: 1999,
      isForwarded: true,
    }
  }, { quoted: cht });
  
  } catch (e) {
    console.error(e);
    cht.reply('❌ Gagal mencari lagu di Spotify.');
  }
})

  ev.on(
    {
      cmd: ['gis', 'image', 'gimage', 'googleimage', 'gimg', 'googleimg'],
      listmenu: ['googleimage'],
      tag: 'search',
      args: `Contoh: ${cht.msg} Xun'er`,
      badword: true,
      energy: 5,
    },
    async () => {
      let url = await await fetch(
        api.xterm.url + '/api/search/google-image?query=' + cht.q
      ).then(async (a) => (await a.json()).data.getRandom());
      Exp.sendMessage(
        id,
        { image: { url }, caption: `Google image search: \`${cht.q}\`` },
        { quoted: cht }
      ).catch(() => cht.reply(`Failed downloading url: ${url}`));
    }
  );


ev.on({
  cmd: ['tiktoksh', 'ttsh'],
  listmenu: ['tiktoksh ℗'],
  tag: 'search',
  energy: 25,
  premium: true
}, async ({ cht, args }) => {
  const query = Array.isArray(args) ? args.join(' ') : String(args || '');
  if (!query) return cht.reply('❌ Masukkan kata kunci TikTok!\nContoh: *.tiktok seiha*');
  
  await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });

  try {
    const res = await fetch(`https://api.botcahx.eu.org/api/search/tiktoks?query=${encodeURIComponent(query)}&apikey=barXbar`);
    const json = await res.json();

    const list = json?.result?.data;
    if (!json?.status || !list?.length) {
      return cht.reply('❌ Video tidak ditemukan.');
    }

    const video = list[Math.floor(Math.random() * list.length)];

    const teks = `🎬 *${video.title}*\n\n📍 Region: ${video.region}\n⏱️ Durasi: ${video.duration} detik\n🎥 Author: @${video.author?.unique_id}\n▶️ Views: ${video.play_count}\n❤️ Likes: ${video.digg_count}`;

    await Exp.sendMessage(cht.id, {
      video: { url: video.play },
      caption: teks
    });

  } catch (err) {
    console.error(err);
    cht.reply('❌ Gagal mencari video TikTok.');
  }
})

  ev.on(
    {
      cmd: ['chord', 'akor'],
      listmenu: ['chord'],
      tag: "search",
      args: "*❗ Masukkan judul atau lirik lagunya*",
      energy: 25
    },
    async ({args}) => {
      await Exp.sendMessage(
        cht.id,
        { 
          react: {
             text: "⏱️", 
             key: cht.key
          }
        }
      )
      
      const api = await fetch(`https://api.botcahx.eu.org/api/search/chord?song=${encodeURIComponent(args)}&apikey=barXbar`)
      const res = await api.json()
      
      if (!res.result) return cht.reply(`Data chord *${args}* tidak di temukan `)
      
      const { 
        title,
        chord
      } = res.result
      
      try {
        await Exp.sendMessage(
          cht.id,
          {
            text: chord,
            contextInfo: {
              externalAdReply: {
                title: `❏ Astrobot md`,
                body: `chord search`,
                thumbnail: fs.readFileSync(fol[3] + 'bell.jpg'),
                mediaUrl: `https://wa.me/${owner[0]}`,
                sourceUrl: `https://wa.me/${owner[0]}`,
                renderLargerThumbnail: true,
                showAdAttribution: true,
                mediaType: 1,
              },
              forwardingScore: 5,
              isForwarded: true,
            }
          }, 
          { quoted: cht}
        )
        
      } catch (e) {
        return cht.reply(`Gagal mengirim chord untuk lagu ${args}\n\n*Error*:\n` + e)
      }
      
    }
  )
  
  
ev.on({
  cmd: ['ytsearch','ytsh'],
  listmenu: ['ytsh'],
  tag: "search",
  energy: 15,
  args: "*❗ Silahkan ketik judul nya*"
}, async ({ args, cht }) => {
   await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
   await sleep(1500);
   
   try {
     const res = await fetch(`https://api.siputzx.my.id/api/s/youtube?query=${encodeURIComponent(args)}`);
     
     const json = await res.json();
     
     if (!json.status || !json.data[0]) {
        return cht.reply("👾 Gagal mengambil data akun tersebut, mungkin apinya *Error*");
     }
     
     const {
       url,
       title,
       description,
       thumbnail,
       seconds,
       timestamp,
       ago,
       views,
       author: {
         name: nameAuthor, url: urlAuthor
       }
     } = json.data[0];
     
     const teks = `\n\`[ YOUTUBE SEARCH ]\`\n\`\`\`\n• Author    : ${nameAuthor}\n• Judul     : ${title}\n• Deskripsi :\n- ${description}\n\n• Durasi    : ${timestamp}\n• Penonton  : ${views}\n• Di buat   :\n- ${ago}\n\n• Link      :\n- ${url}\n\`\`\``.trim();

     await Exp.sendMessage(cht.id, {
       text: teks,
        contextInfo: {
          externalAdReply: {
            title: `YouTube Search 🔎`,
            body: `© ASTROBOT MD ✓`,
            thumbnailUrl: `${thumbnail}`,
            mediaUrl: `https://chat.whatsapp.com/G6axMRtSDIT4wvgNRgBTPz`,
            sourceUrl: `${urlAuthor}`,
            renderLargerThumbnail: true,
            showAdAttribution: true,
            mediaType: 1,
          },
          forwardingScore: 1999,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
            newsletterJid: "120363388627433447@newsletter",
            newslettedName: "🪀 bagus dev",
            //serverMessageId: 152
          }
        }
    },{ quoted: cht });
  
  } catch (e) {
      console.error(e);
      return cht.reply(`Gagal mengambil data akun tersebut\n\n• *Error:*\n${e.message}\n\n> Segera lapor ke owner`);
  }
})

  ev.on(
    {
      cmd: ['pinvid', 'pinterestvid', 'pinterestvideo'],
      listmenu: ['pinterestvideo'],
      tag: 'search',
      args: 'Cari apa?',
      badword: true,
      energy: 21,
    },
    async () => {
      try {
        let [query, geser] = cht?.q?.split('--geser');
        let amount = parseInt(geser?.split(' ')?.[1] || 5);
        amount = amount > 10 ? 10 : amount < 1 ? 1 : amount;

        await cht.edit(infos.messages.wait, keys[sender]);

        let data =
          (
            await fetch(
              api.xterm.url +
                '/api/search/pinterest-video?query=' +
                query +
                '&key=' +
                api.xterm.key
            ).then((a) => a.json())
          ).data?.pins || [];

        if (data.length < 1) return cht.reply('Video tidak ditemukan!');

        if (typeof geser == 'string') {
          let res = await fetch(
            `${api.xterm.url}/api/search/pinterest-image?query=${query}&key=${api.xterm.key}`
          ).then((a) => a.json());
          let cards = [];
          if (data) {
            data = data.slice(0, amount);

            for (let i of data) {
              let p = (
                await fetch(
                  api.xterm.url +
                    '/api/downloader/pinterest?url=' +
                    i.link +
                    '&key=' +
                    api.xterm.key
                ).then((a) => a.json())
              ).data;
              let _pin = Object.values(p.videos)[0].url;
              let vid = await Exp.func.uploadToServer(_pin, 'video');
              cards.push({
                header: {
                  videoMessage: vid,
                  hasMediaAttachment: true,
                },
                body: { text: i.title },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: 'cta_url',
                      buttonParamsJson:
                        '{"display_text":"WhatsappChannel","url":"https://whatsapp.com/channel/0029VaauxAt4Y9li9UtlCu1V","webview_presentation":null}',
                    },
                  ],
                },
              });
            }

            let msg = generateWAMessageFromContent(
              id,
              {
                viewOnceMessage: {
                  message: {
                    interactiveMessage: {
                      body: {
                        text: `Result from "${query?.trim()}"`,
                      },
                      carouselMessage: {
                        cards,
                        messageVersion: 1,
                      },
                    },
                  },
                },
              },
              {}
            );

            Exp.relayMessage(msg.key.remoteJid, msg.message, {
              messageId: msg.key.id,
            });
          }
        } else {
          let pin = data[Math.floor(Math.random() * data.length)];
          let p = (
            await fetch(
              api.xterm.url +
                '/api/downloader/pinterest?url=' +
                pin.link +
                '&key=' +
                api.xterm.key
            ).then((a) => a.json())
          ).data;
          let _pin = Object.values(p.videos)[0].url;
          Exp.sendMessage(
            id,
            { video: { url: _pin }, caption: pin.title, mimetype: 'video/mp4' },
            { quoted: cht }
          );
        }
      } catch (e) {
        return cht.reply('TypeErr:' + e.message);
      }
    }
  );

  ev.on(
    {
      cmd: ['animesearch'],
      listmenu: ['animesearch'],
      tag: 'search',
      media: {
        type: ['image', 'sticker'],
        msg: `Reply gambar/sticker dengan caption ${cht.prefix}animesearch untuk mencari anime!`,
        save: false,
      },
      energy: 5,
    },
    async ({ media }) => {
      try {
        let link = await TermaiCdn(media);
        const apiUrl = `https://api.trace.moe/search?url=${encodeURIComponent(link)}`;

        const res = await fetch(apiUrl);
        const { result } = await res.json();

        if (!res.ok || !result || result.length < 1) {
          return cht.reply(
            '❌ Tidak ditemukan informasi anime untuk gambar yang diberikan.'
          );
        }

        const anime = result[0];
        const { anilist, filename, episode, similarity, video, image } = anime;

        const caption =
          `🎥 *Anime Found!* 🎥\n\n` +
          `📄 *Episode*: ${episode || 'Unknown'}\n` +
          `🔗 *Similarity*: ${(similarity * 100).toFixed(2)}%\n` +
          `🖼️ *Filename*: ${filename || 'Unknown'}\n\n` +
          `📺 \`Preview Video\`: ${video}\n` +
          `🌟 \`Anilist Link\`: https://anilist.co/anime/${anilist}`;

        await Exp.sendMessage(
          cht.id,
          { image: { url: image }, caption },
          { quoted: cht }
        );
        Exp.sendMessage(
          cht.id,
          {
            video: { url: video },
            caption: `📺 \`Preview Video\`: ${filename}`,
          },
          { quoted: cht }
        );
      } catch (error) {
        console.error(error);
        cht.reply(
          '❌ Terjadi kesalahan saat menghubungi API. Silakan coba lagi nanti.'
        );
      }
    }
  );
}
