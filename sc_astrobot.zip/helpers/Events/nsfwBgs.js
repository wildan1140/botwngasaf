const cheerio = await "cheerio".import();
const axios = await 'axios'.import()
const { catbox } = await (fol[0] + 'catbox.js').r();

export default async function on({ cht, Exp, store, ev, is }) {
  const { sender, id, reply, edit } = cht
  const { func } = Exp
 
  const Barr = cfg.bar;

  const pap = [
  "https://telegra.ph/file/c1599cc2424ec477dba9c.jpg",
  "https://telegra.ph/file/b855baefdec15510c8fdc.jpg",
  "https://telegra.ph/file/49f7b55ddfe2eba3a4e70.jpg",
  "https://telegra.ph/file/9b3e6f0c7e4f4b9dc3832.jpg",
  "https://telegra.ph/file/bf3444292b5c5e43cae2f.jpg",
  "https://telegra.ph/file/067e8dc26b6a7860d23e8.jpg",
  "https://telegra.ph/file/f0dfebc4a7cabdb2f18d4.jpg",
  "https://telegra.ph/file/5e5888813807387170227.jpg",
  "https://telegra.ph/file/85d92052a774e5fff90d3.jpg",
  "https://telegra.ph/file/7359e5d3c60962d3d5638.jpg",
  "https://telegra.ph/file/81466171835a42ceb8ef5.jpg",
  "https://telegra.ph/file/708bd8a7b0faa7f70078b.jpg",
  "https://telegra.ph/file/03d2778acd65eec07774f.jpg",
  "https://telegra.ph/file/ac3e6a46d5097365bee7d.jpg",
  "https://telegra.ph/file/810cb10e72ab1de7567b8.jpg",
  "https://telegra.ph/file/bb2890eb91aac9ea24084.jpg",
  "https://telegra.ph/file/59ff6a1ad944738d10cb5.jpg",
  "https://telegra.ph/file/4edeee22e6981dc65e116.jpg",
  "https://telegra.ph/file/ebf26e276a90ea52eeb03.jpg",
  "https://telegra.ph/file/595ed4cc6d33c85bbb266.jpg",
  "https://telegra.ph/file/20bdc9133add55672465a.jpg",
  "https://telegra.ph/file/a6f5b277d78fdebc59c11.jpg",
  "https://telegra.ph/file/4ba39741593bd18a27414.jpg",
  "https://telegra.ph/file/cfabf1adc3eda83b6bf50.jpg",
  "https://telegra.ph/file/c421cde8c8015f3ff870a.jpg",
  "https://telegra.ph/file/a92efe35f03a5b1380548.jpg",
  "https://telegra.ph/file/20c7e2cc4d48ad96577f7.jpg",
  "https://telegra.ph/file/1d0fad7ae5ee470bf8ec4.jpg",
  "https://telegra.ph/file/73cf2c2af00661dc241b4.jpg",
  "https://telegra.ph/file/c534bda9ddd02d2dfc02c.jpg",
  "https://telegra.ph/file/29b9d63971bca2dbc9def.jpg",
  "https://telegra.ph/file/b70cc42e27ce9fce33760.jpg",
  "https://telegra.ph/file/612277ee5e01346913ed2.jpg",
  "https://telegra.ph/file/a66fe3f4caa11a9884d68.jpg",
  "https://telegra.ph/file/fb6c019fc6d21e3d90e16.jpg",
  "https://telegra.ph/file/ee51a2125297766440dc6.jpg",
  "https://telegra.ph/file/58c13ffc4e9f46e531619.jpg",
  "https://telegra.ph/file/567b6440cc673af7d62c3.jpg",
  "https://telegra.ph/file/1be40b365ab187aea062d.jpg",
  "https://telegra.ph/file/d55722b2eab3c2cd9a636.jpg",
  "https://telegra.ph/file/58696efaa503641dee44d.jpg",
  "https://telegra.ph/file/5fddc12ec1fc965b16e66.jpg",
  "https://telegra.ph/file/2fafa3b5c5dbb0ba5de7f.jpg",
  "https://telegra.ph/file/49883e6a83459ba168480.jpg",
  "https://telegra.ph/file/209fe1c309cb74c8b1671.jpg",
  "https://telegra.ph/file/043996d5f18bd042750c6.jpg",
  "https://telegra.ph/file/761f92f07d43fbcd77e58.jpg",
  "https://telegra.ph/file/63f25862ac7cd6f26e782.jpg",
  "https://telegra.ph/file/3c42b93253ca6063b2be8.jpg",
"https://telegra.ph/file/b657d69a13d0f40bfa50b.jpg",
"https://telegra.ph/file/12c68c8a65f8b2fb47820.jpg",
"https://telegra.ph/file/bdbacd6027a79c3ae28d4.jpg",
"https://telegra.ph/file/140476cb094b90f50caf7.jpg",
"https://telegra.ph/file/dc3b139cc938fd67362e7.jpg",
"https://telegra.ph/file/2197e893f86ab365d9262.jpg",
"https://telegra.ph/file/b4986b162b9362d21d6c1.jpg",
"https://telegra.ph/file/12b8f6f5a9e0c9d9825b1.jpg",
"https://telegra.ph/file/4c0959cbbb38720a864d1.jpg",
"https://telegra.ph/file/0aff0e5acdac17cf5ed0c.jpg",
"https://telegra.ph/file/6331436680c27e512a72b.jpg",
"https://telegra.ph/file/11b1a5d94895c145e01bb.jpg",
"https://telegra.ph/file/b78526a218d6e87b9b705.jpg",
"https://telegra.ph/file/803427fe8f503de9aa619.jpg",
 "https://telegra.ph/file/a5730f376956d82f9689c.jpg",
 "https://telegra.ph/file/8fb304f891b9827fa88a5.jpg",
 "https://telegra.ph/file/0c8d173a9cb44fe54f3d3.mp4",
 "https://telegra.ph/file/b58a5b8177521565c503b.mp4",
 "https://telegra.ph/file/34d9348cd0b420eca47e5.jpg",
 "https://telegra.ph/file/73c0fecd276c19560133e.jpg",
 "https://telegra.ph/file/af029472c3fcf859fd281.jpg",
 "https://telegra.ph/file/0e5be819fa70516f63766.jpg",
 "https://telegra.ph/file/29146a2c1a9836c01f5a3.jpg",
 "https://telegra.ph/file/85883c0024081ffb551b8.jpg",
 "https://telegra.ph/file/d8b79ac5e98796efd9d7d.jpg",
 "https://telegra.ph/file/267744a1a8c897b1636b9.jpg",
"https://cosplaytele.com/wp-content/uploads/2023/02/Chengzimiaojj-cosplay-Keqing-Genshin-Impact-36_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/02/Chengzimiaojj-cosplay-Keqing-Genshin-Impact-37_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/02/Chengzimiaojj-cosplay-Keqing-Genshin-Impact-28_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/02/Chengzimiaojj-cosplay-Keqing-Genshin-Impact-17_result.webp",
"https://cosplaytele.com/wp-content/uploads/2024/10/Hakuto-Shojo-cosplay-Sagiri-Izumi-Eromanga-Sensei-18_result.webp",
"https://cosplaytele.com/wp-content/uploads/2024/12/Ayame-Base-cosplay-Hutao-Genshin-Impact-20_result.webp",
"https://cosplaytele.com/wp-content/uploads/2024/12/Ayame-Base-cosplay-Hutao-Genshin-Impact-18_result.webp",
"https://cosplaytele.com/wp-content/uploads/2024/12/Ayame-Base-cosplay-Hutao-Genshin-Impact-15_result.webp",
"https://cosplaytele.com/wp-content/uploads/2024/12/Ayame-Base-cosplay-Hutao-Genshin-Impact-1_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/09/Shojo-eiga-cosplay-Elaina-Majo-No-Tabitabi-6_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/07/PUSSYLET-Candy-Moist-5_result-scaled.webp",
"https://cosplaytele.com/wp-content/uploads/2023/07/PUSSYLET-Candy-Moist-4_result-scaled.webp",
"https://cosplaytele.com/wp-content/uploads/2023/09/SweetRabbit233-cosplay-Nahida-Genshin-Impact-Part-2-66_result-scaled.webp",
"https://cosplaytele.com/wp-content/uploads/2023/09/SweetRabbit233-cosplay-Nahida-Genshin-Impact-Part-2-9_result-scaled.webp",
"https://cosplaytele.com/wp-content/uploads/2023/09/SweetRabbit233-cosplay-Nahida-Genshin-Impact-Part-2-3_result-scaled.webp",
"https://cosplaytele.com/wp-content/uploads/2023/09/SweetRabbit233-cosplay-Nahida-Genshin-Impact-Part-2-2_result-scaled.webp",
"https://cosplaytele.com/wp-content/uploads/2022/12/Nekokoyoshi-sweet-maid-44_result.webp",
"https://cosplaytele.com/wp-content/uploads/2022/12/Nekokoyoshi-sweet-maid-94_result.webp",
"https://cosplaytele.com/wp-content/uploads/2022/12/Nekokoyoshi-sweet-maid-83_result.webp",
"https://cosplaytele.com/wp-content/uploads/2022/12/Nekokoyoshi-sweet-maid-57_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/08/ATFM-Tsubaki-Mini-Skirt-And-Half-T-shirtt-36_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/08/ATFM-Tsubaki-Mini-Skirt-And-Half-T-shirtt-29_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/08/ATFM-Tsubaki-Mini-Skirt-And-Half-T-shirtt-27_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/08/ATFM-Tsubaki-Mini-Skirt-And-Half-T-shirtt-12_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/07/winkwin44566322-cosplay-Rem-Bunnyy-ReZero-63_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/07/winkwin44566322-cosplay-Rem-Bunnyy-ReZero-17_result.webp",
"https://cosplaytele.com/wp-content/uploads/2024/04/Chunmomo-Red-School-Uniform-28_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/12/Fantasy-Factory-Xiao-Dingg-ELF-32_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/12/Fantasy-Factory-Xiao-Dingg-ELF-25_result.webp",
"https://cosplaytele.com/wp-content/uploads/2025/04/Fantasy-Factory-Xiao-Ding-cosplay-Holo-Spice-And-Wolf-25_result.webp",
"https://cosplaytele.com/wp-content/uploads/2025/04/Fantasy-Factory-Xiao-Ding-cosplay-Holo-Spice-And-Wolf-14_result.webp",
"https://cosplaytele.com/wp-content/uploads/2025/04/Fantasy-Factory-Xiao-Ding-cosplay-Holo-Spice-And-Wolf-10_result.webp",
"https://cosplaytele.com/wp-content/uploads/2025/04/Fantasy-Factory-Xiao-Ding-cosplay-Holo-Spice-And-Wolf-4_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/12/Fantasy-Factory-Xiao-Ding-OIL-22_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/12/Fantasy-Factory-Xiao-Ding-OIL-18_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/09/Fantasy-Factory-Xiao-Ding-Milk-Bath-15_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/09/Fantasy-Factory-Xiao-Ding-Milk-Bath-27_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/09/Fantasy-Factory-Xiao-Ding-Milk-Bath-45_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/12/Fantasy-Factory-Xiao-Ding-cosplay-Mashu-Kyrielight-FateGrand-Order-34_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/12/Fantasy-Factory-Xiao-Ding-cosplay-Mashu-Kyrielight-FateGrand-Order-80_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/12/Fantasy-Factory-Xiao-Ding-cosplay-Mashu-Kyrielight-FateGrand-Order-102_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/12/Fantasy-Factory-Xiao-Ding-cosplay-Mashu-Kyrielight-FateGrand-Order-106_result.webp",
"https://cosplaytele.com/wp-content/uploads/2024/01/Fantasy-Factory-Xiao-Ding-Night-31_result.webp",
"https://cosplaytele.com/wp-content/uploads/2024/01/Fantasy-Factory-Xiao-Ding-Night-55_result.webp",
"https://cosplaytele.com/wp-content/uploads/2024/01/Fantasy-Factory-Xiao-Ding-Night-65_result.webp",
"https://cosplaytele.com/wp-content/uploads/2024/01/Fantasy-Factory-Xiao-Ding-Night-71_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/08/Xiao-Ding-cosplay-Misaki-Blue-Archive-37_result-scaled.webp",
"https://cosplaytele.com/wp-content/uploads/2023/08/Xiao-Ding-cosplay-Misaki-Blue-Archive-38_result-scaled.webp",
"https://cosplaytele.com/wp-content/uploads/2024/11/lovewxnn-cosplay-Huohuo-HonkaiStar-Rail-21_result.webp",
"https://cosplaytele.com/wp-content/uploads/2024/07/SleeppyLee1-Collection-8_result.webp",
"https://cosplaytele.com/wp-content/uploads/2024/07/SleeppyLee1-Collection-11_result.webp",
"https://cosplaytele.com/wp-content/uploads/2024/07/SleeppyLee1-Collection-16_result.webp",
"https://cosplaytele.com/wp-content/uploads/2024/07/SleeppyLee1-Collection-19_result.webp",
"https://cosplaytele.com/wp-content/uploads/2024/07/SleeppyLee1-Collection-21_result.webp",
"https://cosplaytele.com/wp-content/uploads/2024/07/SleeppyLee1-Collection-26_result.webp",
"https://cosplaytele.com/wp-content/uploads/2024/07/SleeppyLee1-Collection-42_result.webp",
"https://cosplaytele.com/wp-content/uploads/2024/07/SleeppyLee1-Collection-74_result.webp",
"https://cosplaytele.com/wp-content/uploads/2024/07/SleeppyLee1-Collection-76_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/07/SweetRabbit233-cosplay-Nahida-Genshin-Impact-12_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/07/SweetRabbit233-cosplay-Nahida-Genshin-Impact-48_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/07/SweetRabbit233-cosplay-Nahida-Genshin-Impact-49_result.webp",
"https://cosplaytele.com/wp-content/uploads/2023/07/SweetRabbit233-cosplay-Nahida-Genshin-Impact-52_result.webp",
"https://cosplaytele.com/wp-content/uploads/2024/08/Astra-cosplay-Ganyu-Genshin-Impact-43_result.webp",
"https://cosplaytele.com/wp-content/uploads/2024/04/Inkyung-Afternoon-Part-2-1_result.webp",
"https://cosplaytele.com/wp-content/uploads/2024/01/Meiilyn-yuumeilyn-cosplay-Ayaka-Kamisato-%E2%80%93-Genshin-Impact-Part-2-25_result.webp",
"https://cosplaytele.com/wp-content/uploads/2025/02/Hokunaimeko-cosplay-Shenhe-Genshin-Impact-9_result.webp",
"https://cosplaytele.com/wp-content/uploads/2025/02/Hokunaimeko-cosplay-Shenhe-Genshin-Impact-15_result.webp",
"https://cosplaytele.com/wp-content/uploads/2025/02/Hokunaimeko-cosplay-Shenhe-Genshin-Impact-24_result.webp",
"https://cosplaytele.com/wp-content/uploads/2025/02/Hokunaimeko-cosplay-Shenhe-Genshin-Impact-25_result.webp",
"https://cosplaytele.com/wp-content/uploads/2025/02/Hokunaimeko-cosplay-Shenhe-Genshin-Impact-26_result.webp",
"https://cosplaytele.com/wp-content/uploads/2025/02/Hokunaimeko-cosplay-Shenhe-Genshin-Impact-27_result.webp",
"https://cosplaytele.com/wp-content/uploads/2025/02/Hokunaimeko-cosplay-Shenhe-Genshin-Impact-29_result.webp",
"https://cosplaytele.com/wp-content/uploads/2025/02/Hokunaimeko-cosplay-Shenhe-Genshin-Impact-42_result.webp",
"https://cosplaytele.com/wp-content/uploads/2025/02/Hokunaimeko-cosplay-Shenhe-Genshin-Impact-45_result.webp"
];

async function getRandomMonsnodeVideo() {
  try {
    const page = Math.floor(Math.random() * 20) + 1 
    const res = await fetch(`https://monsnode.com/?page=${page}`, {
      headers: { 'User-Agent': 'Mozilla/5.0' }
    })

    const html = await res.text()
    const $ = cheerio.load(html)

    const links = []
    $('a[href^="https://monsnode.com/redirect.php?v="]').each((_, el) => {
      const href = $(el).attr('href')
      if (href) links.push(href)
    })

    if (links.length === 0) return null
    const randomLink = links[Math.floor(Math.random() * links.length)]
    return randomLink
  } catch (err) {
    console.error('❌ Gagal fetch dari monsnode.com:', err)
    return null
  }
}

async function getMp4FromRedirectPage(url) {
  try {
    const res = await fetch(url, {
      headers: { 'User-Agent': 'Mozilla/5.0' }
    })

    const html = await res.text()
    const $ = cheerio.load(html)

    const mp4Link = $('a[href$=".mp4"]').attr('href')
    return mp4Link || null
  } catch (err) {
    console.error('❌ Gagal fetch halaman redirect:', err)
    return null
  }
}

  ev.on({
    cmd: ['ass'],
    listmenu: ['ass ℗'],
    tag: "nsfw",
    premium: true
  }, async () => {
    await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
    
    const url = "https://api.nekorinn.my.id/waifuim/ass"
    try {
    await Exp.sendMessage(cht.id, {
      image: { url },
      caption: "✅ Nihh kak..."
    }, { quoted: cht })
    
    } catch (e) {
      console.error(e)
      return reply(`Terjadi kesalahan saat memproses permintaan\n\n• *Error*:\n${e.messsage}\n\n> Segera lapor ke owner`)
    }
  })
  
  ev.on({
    cmd: ['bdsm'],
    listmenu: ['bdsm ℗'],
    tag: "nsfw",
    premium: true
  }, async () => {
    await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
    
    const url = `https://api.botcahx.eu.org/api/nsfw/bdsm?apikey=barXbar`
    try {
    await Exp.sendMessage(cht.id, {
      image: { url },
      caption: "✅ Nihh kak..."
    }, { quoted: cht })
    
    } catch (e) {
      console.error(e)
      return reply(`Terjadi kesalahan saat memproses permintaan\n\n• *Error*:\n${e.messsage}\n\n> Segera lapor ke owner`)
    }
  })
  
  ev.on({
    cmd: ['blowjob'],
    listmenu: ['blowjob ℗'],
    tag: "nsfw",
    premium: true
  }, async () => {
    await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
    
    const url = `https://api.botcahx.eu.org/api/nsfw/blowjob?apikey=barXbar`
    try {
    await Exp.sendMessage(cht.id, {
      image: { url },
      caption: "✅ Nihh kak..."
    }, { quoted: cht })
    
    } catch (e) {
      console.error(e)
      return reply(`Terjadi kesalahan saat memproses permintaan\n\n• *Error*:\n${e.messsage}\n\n> Segera lapor ke owner`)
    }
  })

ev.on({
  cmd: ['bokepvid', 'bokep', 'bokeh'],
  listmenu: ['bokepvid ℗'],
  tag: "nsfw",
  premium: true,
  energy: 55
}, async ({ cht }) => {
  await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
  
  let mp4Link = null
  let tries = 0

  while (!mp4Link && tries < 3) {
    tries++
    console.log(`Percobaan ke-${tries}`)
    const redirectUrl = await getRandomMonsnodeVideo()
    if (!redirectUrl) continue
    mp4Link = await getMp4FromRedirectPage(redirectUrl)
  }

  if (!mp4Link) {
    return await cht.reply('❌ Gagal ambil video setelah 3 percobaan. Coba lagi nanti.')
  }

  try {
    await Exp.sendMessage(cht.id, {
      document: { url: mp4Link },
      fileName: 'video.mp4',
      mimetype: 'video/mp4',
     caption: 'Nih kak, jangan ketagihan 🥵'
  }, { quoted: cht })

  } catch (e) {
    console.error(e)
    return cht.reply(`Gagal mengirim video\n\n• *Error*:\n${e.message}\n\n> Segera lapor ke owner`)
  }
})

  ev.on({
    cmd: ['ecchi'],
    listmenu: ['ecchi ℗'],
    tag: "nsfw",
    premium: true
  }, async () => {
    await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
    
    const url = "https://api.nekorinn.my.id/waifuim/ecchi"
    try {
    await Exp.sendMessage(cht.id, {
      image: { url },
      caption: "✅ Nihh kak..."
    }, { quoted: cht })
    
    } catch (e) {
      console.error(e)
      return reply(`Terjadi kesalahan saat memproses permintaan\n\n• *Error*:\n${e.messsage}\n\n> Segera lapor ke owner`)
    }
  })
  
  ev.on({
    cmd: ['ero'],
    listmenu: ['ero ℗'],
    tag: "nsfw",
    premium: true
  }, async () => {
    await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
    
    const url = "https://api.nekorinn.my.id/waifuim/ero"
    try {
    await Exp.sendMessage(cht.id, {
      image: { url },
      caption: "✅ Nihh kak..."
    }, { quoted: cht })
    
    } catch (e) {
      console.error(e)
      return reply(`Terjadi kesalahan saat memproses permintaan\n\n• *Error*:\n${e.messsage}\n\n> Segera lapor ke owner`)
    }
  })
  
  ev.on({
    cmd: ['hentai'],
    listmenu: ['hentai ℗'],
    tag: "nsfw",
    premium: true
  }, async () => {
    await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
    
    const url = `https://api.botcahx.eu.org/api/nsfw/hentai?apikey=barXbar`
    try {
    await Exp.sendMessage(cht.id, {
      image: { url },
      caption: "✅ Nihh kak..."
    }, { quoted: cht })
    
    } catch (e) {
      console.error(e)
      return reply(`Terjadi kesalahan saat memproses permintaan\n\n• *Error*:\n${e.messsage}\n\n> Segera lapor ke owner`)
    }
  })
  
ev.on({
 cmd: ['hentaipict'],
 listmenu: ['hentaipict ℗'],
 tag: "nsfw",
 premium: true
}, async ({ cht }) => {
await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
    const arrlist = [
        "animal",
        "animalears",
        "anusview",
        "ass",
        "barefoot",
        "bed",
        "bell",
        "bikini",
        "blonde",
        "bondage",
        "bra",
        "breasthold",
        "breasts",
        "bunnyears",
        "bunnygirl",
        "chain",
        "closeview",
        "cloudsview",
        "cum",
        "dress",
        "drunk",
        "elbowgloves",
        "erectnipples",
        "fateseries",
        "fingering",
        "flatchest",
        "food",
        "foxgirl",
        "gamecg",
        "genshin",
        "glasses",
        "gloves",
        "greenhair",
        "hatsunemiku",
        "hcatgirl",
        "headband",
        "headdress",
        "headphones",
        "hentaimiku",
        "hentaivideo",
        "hloli",
        "hneko",
        "hololove",
        "horns",
        "inshorts",
        "japanesecloths",
        "necklace",
        "nipples",
        "nobra",
        "nsfwbeach",
        "nsfwbell",
        "nsfwdemon",
        "nsfwidol",
        "nsfwmaid",
        "nsfwmenu",
        "nsfwvampire",
        "nude",
        "openshirt",
        "pantyhose",
        "pantypull",
        "penis",
        "pinkhair",
        "ponytail",
        "pussy",
        "ribbons",
        "schoolswimsuit",
        "schooluniform",
        "seethrough",
        "sex",
        "sex2",
        "sex3",
        "shirt",
        "shirtlift",
        "skirt",
        "spreadlegs",
        "spreadpussy",
        "squirt",
        "stockings",
        "sunglasses",
        "swimsuit",
        "tail",
        "tattoo",
        "tears",
        "thighhighs",
        "thogirls",
        "topless",
        "torncloths",
        "touhou",
        "twintails",
        "uncensored",
        "underwear",
        "vocaloid",
        "weapon",
        "wet",
        "white",
        "whitehair",
        "wings",
        "withflowers",
        "withgun",
        "withpetals",
        "withtie",
        "withtree",
        "wolfgirl",
        "yuri"
    ];

  const hasilRandom = arrlist[Math.floor(Math.random() * arrlist.length)]
  
  try {
    const response = await fetch(`https://fantox-apis.vercel.app/${hasilRandom}`);
const data = await response.json();

await Exp.sendMessage(cht.id, {
  image: { url: data.url }, caption: `✅ \`${hasilRandom} Berhasil terkirim...\`\n> Jangan ketagihan yahh💋`
}, { quoted: cht });

  } catch (e) {
    cht.reply(`Terjadi kesalahan saat mengambil gambar\n\n*Error*:\n${e.message}\n\ncoba lagi nanti...`);
  }
})

ev.on({
  cmd: ['hentaivid', 'hentaivideo'],
  listmenu: ['hentaivid ℗'],
  tag: "nsfw",
  energy: 55,
  premium: true
}, async ({ cht }) => {
  await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
  const pageRandom = Math.floor(Math.random() * 50)
  
  try {
    const res = await axios.get(`https://sfmcompile.club/category/dead-or-alive/page/${pageRandom}/`)
    const $ = cheerio.load(res.data)

    const posts = []
    $('.entry-title a').each((_, el) => {
      const link = $(el).attr('href')
      if (link) posts.push(link)
    })

    if (posts.length === 0) return cht.reply('❌ Tidak ditemukan postingan video.')

    const randomLink = posts[Math.floor(Math.random() * posts.length)]

    const res2 = await axios.get(randomLink)
    const $2 = cheerio.load(res2.data)

    let videoUrl = $2('video source').attr('src') || $2('video').attr('src')
    if (!videoUrl || !videoUrl.includes('.mp4')) {
      return cht.reply('❌ Gagal mengambil video dari postingan.')
    }

    const title = $2('h1.entry-title').text().trim()

    await Exp.sendMessage(cht.id, {
      video: { url: videoUrl },
      caption: `\`${title || 'Tanpa Judul'}\``
    })

  } catch (e) {
    console.error(e)
    cht.reply('Gagal mengambil data video\n\n*Error*:\n' + e)
  }
})

  ev.on({
    cmd: ['masturbasi'],
    listmenu: ['masturbasi ℗'],
    tag: "nsfw",
    premium: true
  }, async () => {
    await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });

    const url = `https://api.botcahx.eu.org/api/nsfw/masturbation?apikey=barXbar`
    try {
    await Exp.sendMessage(cht.id, {
      image: { url },
      caption: "✅ Nihh kak..."
    }, { quoted: cht })
    
    } catch (e) {
      console.error(e)
      return reply(`Terjadi kesalahan saat memproses permintaan\n\n• *Error*:\n${e.messsage}\n\n> Segera lapor ke owner`)
    }
  })
  
  ev.on({
    cmd: ['nekohen'],
    listmenu: ['nekohen ℗'],
    tag: "nsfw",
    premium: true
  }, async () => {
    await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });

    const url = "https://api.vreden.my.id/api/neko"
    try {
    await Exp.sendMessage(cht.id, {
      image: { url },
      caption: "✅ Nihh kak..."
    }, { quoted: cht })
    
    } catch (e) {
      console.error(e)
      return reply(`Terjadi kesalahan saat memproses permintaan\n\n• *Error*:\n${e.messsage}\n\n> Segera lapor ke owner`)
    }
  })
  
ev.on({
  cmd: ['ncosplay'],
  listmenu: ['ncosplay ℗'],
  tag: "nsfw",
  premium: true,
  args: '*❗ Masukkan nama cosplayers nya, atau karakter yang di cosplay*'
}, async ({ cht, args }) => {
await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
  try {
    const url = `https://cosplaytele.com/?s=${encodeURIComponent(args)}`;
    const res = await fetch(url);
    const html = await res.text();
    const $ = cheerio.load(html);

    const imageUrls = [];
    $('img').each((i, el) => {
      const src = $(el).attr('src');
      if (src && /\.(webp|jpg|jpeg|png)$/i.test(src) && !src.includes('icon') && !src.includes('logo')) {
        imageUrls.push(src);
      }
    });

    if (imageUrls.length === 0)
      return cht.reply('❌ Tidak ditemukan hasil untuk cosplay tersebut.');

    const selectedImages = imageUrls.sort(() => Math.random() - 0.5).slice(0, 3);

    const catboxLinks = [];
    for (const img of selectedImages) {
      try {
        const buffer = await func.getBuffer(img);
        const link = await catbox(buffer);
        catboxLinks.push(link);
      } catch (e) {
        console.error(`❌ Gagal upload ke catbox: ${img}`, e.message);
      }
    }

    if (catboxLinks.length === 0)
      return cht.reply('⚠️ Gagal mengupload gambar ke catbox.');

    await cht.reply(`Berikut hasil untuk \`${args}\``);
     await sleep(1500)
    for (const link of catboxLinks) {
      await Exp.sendMessage(cht.id, {
        image: { url: link }
      });
      await sleep(1500);
    }

  } catch (err) {
    console.error(err);
    cht.reply(`❌ Gagal mengambil data cosplay.\n\n• *Error:* ${err.message}\n\n> Laporkan ke owner ya`);
  }
})


  ev.on({
    cmd: ['oppai'],
    listmenu: ['oppai ℗'],
    tag: "nsfw",
    premium: true
  }, async () => {
    await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
    
    const url = "https://api.nekorinn.my.id/waifuim/oppai"
    try {
    await Exp.sendMessage(cht.id, {
      image: { url },
      caption: "✅ Nihh kak..."
    }, { quoted: cht })
    
    } catch (e) {
      console.error(e)
      return reply(`Terjadi kesalahan saat memproses permintaan\n\n• *Error*:\n${e.messsage}\n\n> Segera lapor ke owner`)
    }
  })
  
  ev.on({
    cmd: ['oral'],
    listmenu: ['oral ℗'],
    tag: "nsfw",
    premium: true
  }, async () => {
    await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
    
    const url = "https://api.nekorinn.my.id/waifuim/oral"
    try {
    await Exp.sendMessage(cht.id, {
      image: { url },
      caption: "✅ Nihh kak..."
    }, { quoted: cht })
    
    } catch (e) {
      console.error(e)
      return reply(`Terjadi kesalahan saat memproses permintaan\n\n• *Error*:\n${e.messsage}\n\n> Segera lapor ke owner`)
    }
  })
  
  ev.on({
    cmd: ['paizuri'],
    listmenu: ['paizuri ℗'],
    tag: "nsfw",
    premium: true
  }, async () => {
    await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
    
    const url = "https://api.nekorinn.my.id/waifuim/paizuri"
    try {
    await Exp.sendMessage(cht.id, {
      image: { url },
      caption: "✅ Nihh kak..."
    }, { quoted: cht })
    
    } catch (e) {
      console.error(e)
      return reply(`Terjadi kesalahan saat memproses permintaan\n\n• *Error*:\n${e.messsage}\n\n> Segera lapor ke owner`)
    }
  })

ev.on({
 cmd: ['paptt','tetek'],
 listmenu: ['paptt ℗'],
 tag: "nsfw",
 premium: true
}, async () => {
  await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
  
    const ahAh = pap[Math.floor(Math.random() * pap.length)];

    try {
    await Exp.sendMessage(cht.id, {
      image: { url: ahAh },
      caption: "✅ Nihh kak..."
    }, { quoted: cht })
    
    } catch (e) {
      console.error(e)
      return reply(`Terjadi kesalahan saat memproses permintaan\n\n• *Error*:\n${e.messsage}\n\n> Segera lapor ke owner`)
    }
  })
  
  ev.on({
    cmd: ['pussy'],
    listmenu: ['pussy ℗'],
    tag: "nsfw",
    premium: true
  }, async () => {
    await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
    
    const url = `https://api.botcahx.eu.org/api/nsfw/pussy?apikey=barXbar`
    try {
    await Exp.sendMessage(cht.id, {
      image: { url },
      caption: "✅ Nihh kak..."
    }, { quoted: cht })
    
    } catch (e) {
      console.error(e)
      return reply(`Terjadi kesalahan saat memproses permintaan\n\n• *Error*:\n${e.messsage}\n\n> Segera lapor ke owner`)
    }
  })
  
  ev.on({
    cmd: ['yuri'],
    listmenu: ['yuri ℗'],
    tag: "nsfw",
    premium: true
  }, async () => {
    await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
    
    const url = `https://api.botcahx.eu.org/api/anime/yuri?apikey=barXbar`
    try {
    await Exp.sendMessage(cht.id, {
      image: { url },
      caption: "✅ Nihh kak..."
    }, { quoted: cht })
    
    } catch (e) {
      console.error(e)
      return reply(`Terjadi kesalahan saat memproses permintaan\n\n• *Error*:\n${e.messsage}\n\n> Segera lapor ke owner`)
    }
  })

}