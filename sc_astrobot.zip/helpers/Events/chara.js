const fs = await import("fs")
const { default: ms } = await import("ms")
const axios = (await import('axios')).default
const translate = await import('@vitalets/google-translate-api')

const { getPhoneSpecs, getIMDbMovie, getRAWGGame } = await (fol[2] + 'scrape.js').r()

export default async function on({ cht, Exp, store, ev, is }) {
   const { sender, id, reply, edit } = cht
   const { func } = Exp

  ev.on({
    cmd: ['cekfilm', 'film', 'movie', 'imdb'],
    listmenu: ['cekfilm'],
    tag: 'search',
    energy: 50,
    args: 'Contoh: .cekfilm Avengers Endgame atau .cekfilm https://m.imdb.com/title/tt1447791/'
  }, async ({ cht, args }) => {
    try {
      const text = Array.isArray(args) ? args.join(' ').trim() : String(args || '').trim()
      if (!text) return cht.reply('Contoh: .cekfilm Avengers Endgame atau .cekfilm https://m.imdb.com/title/tt1447791/')

      const movie = await getIMDbMovie(text)
      if (!movie || !movie.title) return cht.reply('Film tidak ditemukan atau gagal mengambil data')

      let translatedPlot = movie.plot || 'Sinopsis tidak tersedia'
      if (movie.plot && movie.plot.length > 10) {
        try {
          const translated = await translate.translate(movie.plot, { to: 'id' })
          translatedPlot = translated.text
        } catch (err) {
          console.warn('Gagal terjemahkan plot:', err)
        }
      }

      const caption = [
        `🎬 *${movie.title}*`,
        ``,
        `*INFORMASI UMUM*`,
        `- Tahun: ${movie.year || '-'}`,
        `- Rating: ${movie.rating ? `⭐ ${movie.rating}/10` : '-'} ${movie.ratingCount ? `(${movie.ratingCount})` : ''}`,
        `- Durasi: ${movie.duration || '-'}`,
        `- Genre: ${movie.genre.length > 0 ? movie.genre.join(', ') : '-'}`,
        `- Negara: ${movie.country || '-'}`,
        `- Bahasa: ${movie.language || '-'}`,
        ``,
        `*PRODUKSI*`,
        `- Sutradara: ${movie.director.length > 0 ? movie.director.join(', ') : '-'}`,
        `- Pemeran: ${movie.cast.length > 0 ? movie.cast.join(', ') : '-'}`,
        `- Tanggal Rilis: ${movie.releaseDate || '-'}`,
        ``,
        `*BOX OFFICE*`,
        `- Budget: ${movie.budget || '-'}`,
        `- Pendapatan: ${movie.boxOffice || '-'}`,
        ``,
        `📖 *SINOPSIS*`,
        translatedPlot,
        ``,
        `> Data dari IMDb`
      ].join('\n')

      if (movie.poster && movie.poster.startsWith('http')) {
        try {
          const response = await axios.get(movie.poster, {
            responseType: 'arraybuffer',
            timeout: 10000,
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
              'Referer': 'https://www.imdb.com/'
            }
          })
          
          const imageBuffer = Buffer.from(response.data)
          
          await Exp.sendMessage(cht.id, {
            image: imageBuffer,
            caption: caption
          }, { quoted: cht })
          
          return
          
        } catch (imgError) {
          console.log('Gagal download poster film, kirim text saja...')
        }
      }
      
      cht.reply(caption)

    } catch (e) {
      console.error('CEKFILM ERROR:', e)
      cht.reply(`Gagal mengambil data film\n\n*Error:* ${e.message}`)
    }
  })

  ev.on({
    cmd: ['cekgame', 'game', 'infogame'],
    listmenu: ['cekgame'],
    tag: 'search',
    energy: 50,
    args: 'Contoh: .cekgame God of War 2'
  }, async ({ cht, args }) => {
    try {
      const text = Array.isArray(args) ? args.join(' ').trim() : String(args || '').trim()
      if (!text) return cht.reply('Contoh: .cekgame God of War 2')

      const game = await getRAWGGame(text)
      if (!game || !game.title) return cht.reply('Game tidak ditemukan atau gagal mengambil data')

      const formatList = (arr, fallback = "-") => {
        return arr.length > 0 ? arr.join(", ") : fallback
      }

      const caption = [
        `🎮 *${game.title}*`,
        ``,
        `*INFORMASI UMUM*`,
        `- Platform: ${formatList(game.platform)}`,
        `- Metascore: ${game.metascore}`,
        `- Genre: ${formatList(game.genre)}`,
        `- Tanggal Rilis: ${game.releaseDate}`,
        `- Rating Usia: ${game.ageRating}`,
        ``,
        `*PRODUKSI*`,
        `- Developer: ${formatList(game.developer)}`,
        `- Publisher: ${formatList(game.publisher)}`,
        ``,
        `*TAG GAME*`,
        `- ${formatList(game.tags)}`,
        ``,
        `*TENTANG GAME*`,
        game.translatedAbout,
        ``,
        `> Data dari RAWG.io`
      ].join('\n')

      if (game.image && game.image.startsWith('http')) {
        try {
          const response = await axios.get(game.image, {
            responseType: 'arraybuffer',
            timeout: 10000,
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
          })
          
          const imageBuffer = Buffer.from(response.data)
          
          await Exp.sendMessage(cht.id, {
            image: imageBuffer,
            caption: caption
          }, { quoted: cht })
          
          return
          
        } catch (imgError) {
          console.log('Gagal download gambar game, kirim text saja...')
        }
      }
      
      cht.reply(caption)

    } catch (e) {
      console.error('CEKGAME ERROR:', e)
      cht.reply(`Gagal mengambil data game\n\n*Error:* ${e.message}`)
    }
  })

  ev.on({
    cmd: ['cekhp', 'hp', 'phone'],
    listmenu: ['cekhp'],
    tag: 'search',
    energy: 50,
    args: 'Contoh: .cekhp Xiaomi Redmi Note 14'
  }, async ({ cht, args }) => {
    try {
      const text = Array.isArray(args) ? args.join(' ').trim() : String(args || '').trim()
      if (!text) return cht.reply('Contoh: .cekhp Xiaomi Redmi Note 14')

      const specs = await getPhoneSpecs(text)
      if (!specs || !specs.name) return cht.reply('HP tidak ditemukan atau gagal mengambil data')

      const caption = [
        `📱 *${specs.name}*`,
        ``,
        `*JARINGAN*`,
        `- Teknologi: ${specs.technology || '-'}`,
        `- 2G: ${specs.bands2g || '-'}`,
        `- 3G: ${specs.bands3g || '-'}`,
        `- 4G: ${specs.bands4g || '-'}`,
        `- Kecepatan: ${specs.speed || '-'}`,
        ``,
        `*PELUNCURAN*`,
        `- Diumumkan: ${specs.announced || '-'}`,
        `- Status: ${specs.status || '-'}`,
        ``,
        `*DESAIN*`,
        `- Dimensi: ${specs.dimensions || '-'}`,
        `- Berat: ${specs.weight || '-'}`,
        `- Build: ${specs.build || '-'}`,
        `- SIM: ${specs.sim || '-'}`,
        ``,
        `*LAYAR*`,
        `- Tipe: ${specs.displayType || '-'}`,
        `- Ukuran: ${specs.displaySize || '-'}`,
        `- Resolusi: ${specs.resolution || '-'}`,
        `- Proteksi: ${specs.protection || '-'}`,
        ``,
        `*PLATFORM*`,
        `- OS: ${specs.os || '-'}`,
        `- Chipset: ${specs.chipset || '-'}`,
        `- CPU: ${specs.cpu || '-'}`,
        `- GPU: ${specs.gpu || '-'}`,
        ``,
        `*MEMORI*`,
        `- Slot Kartu: ${specs.cardSlot || '-'}`,
        `- Internal: ${specs.internal || '-'}`,
        ``,
        `*KAMERA*`,
        `- Kamera Utama: ${specs.mainCamera || '-'}`,
        `- Kamera Depan: ${specs.selfieCamera || '-'}`,
        ``,
        `> Data dari GSMArena`
      ].join('\n')

      if (specs.image && specs.image.startsWith('http')) {
        try {
          const response = await axios.get(specs.image, {
            responseType: 'arraybuffer',
            timeout: 10000,
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
          })
          
          const imageBuffer = Buffer.from(response.data)
          
          await Exp.sendMessage(cht.id, {
            image: imageBuffer,
            caption: caption
          }, { quoted: cht })
          
          return
          
        } catch (imgError) {
          console.log('Gagal download gambar HP, kirim text saja...')
        }
      }
      
      cht.reply(caption)

    } catch (e) {
      console.error('CEKHP ERROR:', e)
      cht.reply(`Gagal mengambil data HP\n\n*Error:* ${e.message}`)
    }
  })

}