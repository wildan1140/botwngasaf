const axios = "axios".import();
const fs = "fs".import();
const FormData = (await import('form-data')).default;

const { GeminiImage } = await (fol[2] + 'gemini.js').r();
const { imageEdit } = await (fol[2] + 'imageEdit.js').r();

let exif = await (fol[0] + 'exif.js').r();
let { convert } = exif;

export default async function on({ Exp, ev, store, cht, ai, is }) {
  let infos = Data.infos;
  let { sender, id } = cht;
  const { func } = Exp;

    const uploadToUguu = async (buffer, filename = 'upload.jpg') => {
        try {
            const form = new FormData();
            form.append('files[]', buffer, { filename });

            const response = await axios.post('https://uguu.se/upload.php', form, {
                headers: form.getHeaders()
            });

            const uploadUrl = response.data?.files?.[0]?.url;
            if (!uploadUrl) {
                throw new Error('No URL returned from Uguu service');
            }

            return uploadUrl;
        } catch (error) {
            console.error('Uguu upload error:', error);
            throw new Error('Gagal mengunggah ke Uguu');
        }
    };

    const makeAPIRequest = async (url, responseType = 'json') => {
        try {
            const config = { 
                timeout: 30000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            };
            
            if (responseType === 'buffer') {
                config.responseType = 'arraybuffer';
                const response = await axios.get(url, config);
                return Buffer.from(response.data);
            } else {
                const response = await axios.get(url, config);
                return response.data;
            }
        } catch (error) {
            throw new Error(`API request failed: ${error.message}`);
        }
    };
    
    ev.on({
        cmd: ['topink'],
        listmenu: ['topink'],
        tag: "art",
        energy: 15,
        media: { type: ["image"] },
    }, async ({ media, cht }) => {
        try {
            const sharp = (await import("sharp")).default;
            const buffer = await media;

            const darkColor = [0, 100, 0];
            const lightColor = [255, 105, 180]; 
            const { data, info } = await sharp(buffer)
                .grayscale()
                .raw()
                .toBuffer({ resolveWithObject: true });

            const out = Buffer.alloc(data.length * 3);

            for (let i = 0; i < data.length; i++) {
                const t = data[i] / 255;
                out[i * 3 + 0] = darkColor[0] * (1 - t) + lightColor[0] * t;
                out[i * 3 + 1] = darkColor[1] * (1 - t) + lightColor[1] * t;
                out[i * 3 + 2] = darkColor[2] * (1 - t) + lightColor[2] * t;
            }

            const output = await sharp(out, {
                raw: {
                    width: info.width,
                    height: info.height,
                    channels: 3,
                },
            })
                .jpeg({ quality: 90 })
                .toBuffer();

            await Exp.sendMessage(cht.id, {
                image: output,
                caption: ``
            }, { quoted: cht });

        } catch (e) {
            console.error(e);
            return cht.reply(`*Error*:\n${e.message}`);
        }
    });

    ev.on({
        cmd: ['toanime'],
        listmenu: ['toanime'],
        tag: "art",
        media: { type: ["image"] }
    }, async ({ cht, media }) => {
        const { id } = cht;

        try {
            await cht.reply(infos.messages.wait);

            const uploadedUrl = await uploadToUguu(media, `toanime_${Date.now()}.jpg`);
            const apiUrl = `https://api.betabotz.eu.org/api/maker/jadianime?url=${encodeURIComponent(uploadedUrl)}&apikey=gara`;

            const response = await axios.get(apiUrl);
            const imageUrl = response.data?.result?.img_1;

            if (!imageUrl || !/^https?:\/\//.test(imageUrl)) {
                throw new Error("Gagal menerima gambar dari API");
            }

            await Exp.sendMessage(id, {
                image: { url: imageUrl },
                caption: ``
            }, { quoted: cht });

        } catch (error) {
            console.error('ToAnime Error:', error);
            await cht.reply(`Gagal mengedit gambar ke anime: ${error.message || error}`);
        }
    });
    
    ev.on({
        cmd: ['toanime2', 'jadianime2', 'jadinyata', 'toreal'],
        listmenu: ['toanime2','toreal'],
        tag: 'art',
        energy: 50,
        media: {
            type: ['image'],
            save: false,
        },
    }, async ({ media }) => {
        const _key = keys[sender];
        let tryng = 0;
        let type = 'anime2d';

        if (['filter', 'filters'].includes(cht.cmd)) {
            if (!cht.q) return cht.reply(infos.ai.filters);
            type = cht.q;
        } else if (['jadinyata', 'toreal'].includes(cht.cmd)) {
            type = 'anime2real';
        } else if (['imglarger', 'enlarger', 'enlarge'].includes(cht.cmd)) {
            type = 'enlarger';
        }

        let i = 0;
        await cht.edit(infos.messages.wait, _key, true);

        const minimized = await func.minimizeImage(media);
        const tph = await uploadToUguu(minimized, `anime2_${Date.now()}.jpg`);

        try {
            let ai = await fetch(
                api.xterm.url +
                '/api/img2img/filters?action=' +
                type +
                '&url=' +
                encodeURIComponent(tph) +
                '&key=' +
                api.xterm.key
            ).then((a) => a.json());

            console.log(ai);
            if (!ai.status) return cht.reply(ai?.msg || 'Error!');

            while (tryng < 50) {
                if (i === Data.spinner.length) i = 0;
                let s = await fetch(
                    api.xterm.url + '/api/img2img/filters/batchProgress?id=' + ai.id
                ).then((a) => a.json());

                await cht.edit(
                    `${Data.spinner[i++]} ${s?.progress || 'Prepare...'}`,
                    _key,
                    true
                );

                if (s.status == 3) {
                    return Exp.sendMessage(
                        id,
                        { image: { url: s.url } },
                        { quoted: cht }
                    );
                }

                if (s.status == 4) {
                    return cht.reply(infos.ai.failTryImage);
                }

                await new Promise((resolve) => setTimeout(resolve, 1200));
            }
        } catch (e) {
            console.error(e);
            cht.reply(`Type-Err! :\n${e}`);
        }
    });

    ev.on({
        cmd: ['animediff'],
        listmenu: ['animediff'],
        tag: 'stablediffusion',
        args: infos.ai.isPrompt,
        energy: 17,
    }, async () => {
        let [text1, text2] = cht.q ? cht.q.split('|') : [];
        await cht.edit(infos.messages.wait, keys[sender]);
        await Exp.sendMessage(
            id,
            {
                image: {
                    url:
                        api.xterm.url +
                        '/api/text2img/animediff?prompt=' +
                        text1 +
                        '&key=' +
                        api.xterm.key +
                        (text2 ? '&prompt=' + text2 : ''),
                },
            },
            { quoted: cht }
        );
    });


    ev.on({
        cmd: ['geminiimage', 'geminiimg'],
        listmenu: ['geminiimage'],
        tag: 'ai',
        energy: 20,
        args: infos.ai.isQuery,
        media: {
            type: ['image'],
        },
    }, async ({ media }) => {
        let res = await GeminiImage(await func.minimizeImage(media), cht.q);
        cht.reply(res);
    });

    const bufferStyles = {
        tohitam: { endpoint: 'hitam', caption: 'Hitam' },
        tohijab: { endpoint: 'hijab', caption: 'Hijab' },
        topixar: { endpoint: 'pixar', caption: 'Pixar' },
        toputih: { endpoint: 'putih', caption: 'Putih' },
        tocyberpunk: { endpoint: 'cyberpunk', caption: 'Cyberpunk' },
        todisney: { endpoint: 'disney', caption: 'Disney' },
        tovangogh: { endpoint: 'vangogh', caption: 'Van Gogh' },
        topixelart: { endpoint: 'pixelart', caption: 'Pixel Art' },
        tocomicbook: { endpoint: 'comicbook', caption: 'Comic Book' },
        tocartoon: { endpoint: 'cartoon', caption: 'Cartoon' }
    };

    Object.entries(bufferStyles).forEach(([cmdName, { endpoint, caption }]) => {
        ev.on({
            cmd: [cmdName],
            listmenu: [cmdName],
            tag: "art",
            media: { type: ["image"] }
        }, async ({ cht, media }) => {
            const { id } = cht;

            try {
                await cht.reply(infos.messages.wait);

                const uploadedUrl = await uploadToUguu(media, `${cmdName}_${Date.now()}.jpg`);
                const apiUrl = `https://api.betabotz.eu.org/api/maker/jadi${endpoint}?url=${encodeURIComponent(uploadedUrl)}&apikey=gara`;

                const buffer = await makeAPIRequest(apiUrl, 'buffer');

                await Exp.sendMessage(id, {
                    image: buffer,
                    caption: ``
                }, { quoted: cht });

            } catch (error) {
                console.error(`${cmdName} Error:`, error);
                await cht.reply(`Gagal mengedit gambar ke ${endpoint}: ${error.message || error}`);
            }
        });
    });

    const jsonStyles = {
        togta: { endpoint: 'gta', caption: 'GTA' },
        tozombie: { endpoint: 'zombie', caption: 'Zombie' }
    };

    Object.entries(jsonStyles).forEach(([cmdName, { endpoint, caption }]) => {
        ev.on({
            cmd: [cmdName],
            listmenu: [cmdName],
            tag: "art",
            media: { type: ["image"] }
        }, async ({ cht, media }) => {
            const { id } = cht;

            try {
                await cht.reply(infos.messages.wait);

                const uploadedUrl = await uploadToUguu(media, `${cmdName}_${Date.now()}.jpg`);
                const apiUrl = `https://api.betabotz.eu.org/api/maker/jadi${endpoint}?url=${encodeURIComponent(uploadedUrl)}&apikey=gara`;

                const response = await makeAPIRequest(apiUrl);
                const imageUrl = response?.result;

                if (!imageUrl || !/^https?:\/\//.test(imageUrl)) {
                    throw new Error(`Gagal mengedit gambar gaya: ${endpoint}`);
                }

                await Exp.sendMessage(id, {
                    image: { url: imageUrl },
                    caption: ``
                }, { quoted: cht });

            } catch (error) {
                console.error(`${cmdName} Error:`, error);
                await cht.reply(`Gagal mengedit gambar ke ${endpoint}: ${error.message || error}`);
            }
        });
    });

    ev.on({
        cmd: ['togta2'],
        listmenu: ['togta2'],
        tag: "art",
        energy: 35,
        media: { type: ["image"] }
    }, async ({ cht, media, sender }) => {
        const _key = keys[sender];

        const getNonce = async () => {
            try {
                const { data } = await axios.get("https://photostylelab.com/photo-styles/gta", {
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
                    }
                });
                
                console.log('HTML Sample:', data.substring(0, 1000));
                
                const patterns = [
                    /id="akismet_comment_nonce"[^>]*value="([^"]+)"/,
                    /name="akismet_comment_nonce"[^>]*value="([^"]+)"/,
                    /"akismet_comment_nonce"[^"]*"([^"]+)"/,
                    /akismet_comment_nonce.*?value=['"]([^'"]+)['"]/,
                    /wp_nonce['"]:\s*['"]([^'"]+)['"]/,
                    /_wpnonce['"]:\s*['"]([^'"]+)['"]/,
                    /nonce['"]:\s*['"]([^'"]+)['"]/
                ];
                
                for (const pattern of patterns) {
                    const match = data.match(pattern);
                    if (match && match[1]) {
                        console.log('Nonce found:', match[1]);
                        return match[1];
                    }
                }
                
                const genericNonce = data.match(/[a-f0-9]{10,}/);
                if (genericNonce) {
                    console.log('Generic nonce found:', genericNonce[0]);
                    return genericNonce[0];
                }
                
                throw new Error('Nonce tidak ditemukan di halaman');
            } catch (error) {
                console.error('getNonce Error:', error);
                throw error;
            }
        };

        try {
            await cht.edit(infos.messages.wait, _key, true);
            const imageUrl = await uploadToUguu(media, `gta_${Date.now()}.jpg`);
            const nonce = await getNonce();
            const imageBuffer = await makeAPIRequest(imageUrl, 'buffer');
            const form = new FormData();
            form.append("action", "photo_style_convert");
            form.append("image_data", imageBuffer, {
                filename: `gta_convert_${Date.now()}.jpg`,
                contentType: 'image/jpeg'
            });
            form.append("photo_style_converter_nonce", nonce);
            form.append("photo_style_name", "GTA");
            form.append("model_type", "default");
            form.append("additional_prompt", "");

            const config = {
                headers: {
                    ...form.getHeaders(),
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                    'Referer': 'https://photostylelab.com/photo-styles/gta',
                    'Origin': 'https://photostylelab.com'
                },
                timeout: 60000
            };
            
            console.log('Sending request to PhotoStyleLab...');
            const response = await axios.post("https://photostylelab.com/wp-admin/admin-ajax.php", form, config);
            
            console.log('PhotoStyleLab Response Status:', response.status);
            console.log('PhotoStyleLab Response Data:', JSON.stringify(response.data, null, 2));
            
            let convertedUrl = null;
            
            if (response.data?.success && response.data?.data) {
                if (typeof response.data.data === 'string' && response.data.data.startsWith('http')) {
                    convertedUrl = response.data.data;
                } else if (response.data.data?.converted_url) {
                    convertedUrl = response.data.data.converted_url;
                } else if (response.data.data?.url) {
                    convertedUrl = response.data.data.url;
                }
            }
            else if (response.data?.converted_url) {
                convertedUrl = response.data.converted_url;
            } else if (response.data?.url) {
                convertedUrl = response.data.url;
            } else if (response.data?.result) {
                convertedUrl = response.data.result;
            } else if (typeof response.data === 'string' && response.data.includes('http')) {
                const urlMatch = response.data.match(/https?:\/\/[^\s"'<>]+/);
                if (urlMatch) {
                    convertedUrl = urlMatch[0];
                }
            }

            if (!convertedUrl) {
                throw new Error(`Response tidak mengandung URL gambar. Response: ${JSON.stringify(response.data)}`);
            }

            console.log('Converted URL found:', convertedUrl);

            await Exp.sendMessage(cht.id, {
                image: { url: convertedUrl },
                caption: ``
            }, { quoted: cht });

        } catch (err) {
            console.error('togta2 Full Error:', err);
            console.error('Error response:', err.response?.data);
            cht.reply(`gagal proses GTA style: ${err.message || err}`);
        }
    });
}