const fs = "fs".import();
const path = 'path'.import();
const path = './toolkit/db/rpgGame.json';

export default async function on({ cht, Exp, store, ev, is }) {
    const { sender, id, reply, edit } = cht;
    const { func } = Exp;
    
    
    
  function loadDB() {
    if (!fs.existsSync(path)) fs.writeFileSync(path, '{}');
    return JSON.parse(fs.readFileSync(path));
  }
  
  

  function saveDB(data) {
    fs.writeFileSync(path, JSON.stringify(data, null, 2));
  }
  
  
function msToTime(ms) {
  let d = Math.floor(ms / 1000 / 60 / 60 / 24);
  let h = Math.floor(ms / 1000 / 60 / 60) % 24;
  let m = Math.floor(ms / 1000 / 60) % 60;
  let s = Math.floor(ms / 1000) % 60;

  let result = [];
  if (d) result.push(`${d} hari`);
  if (h) result.push(`${h} jam`);
  if (m) result.push(`${m} menit`);
  if (s) result.push(`${s} detik`);

  return result.join(' ') || '0 detik';
}


  function getTime() {
    return new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
  }

  const userId = cht.sender;
  const db = loadDB();
  const peringatanDaftar = `Sebelum memulai petualangan mu sialhakan \`.daftar Nama | Umur\` terlebih dahulu =⁠_⁠=`
  const contextInfo = {
     externalAdReply: {
       title: `❏ Elaina [ イレイナ ]`,
       body: `Time ${getTime()}`,
       thumbnail: fs.readFileSync(fol[10] + 'thumb1.jpg'),
       mediaUrl: `${cfg.gcurl}`,
       sourceUrl: `https://wa.me/${owner[0]}`,
       renderLargerThumbnail: false,
       showAdAttribution: true,
       mediaType: 2,
     },
     forwardingScore: 1999,
     isForwarded: true,
  }
  
  
async function checkLevelUp(user) {
  const levelUpExp = 100;
  let leveledUp = false;
  let naikLevel = 0;

  while (user.exp >= levelUpExp) {
    user.exp -= levelUpExp;
    user.level += 1;
    naikLevel++;
    leveledUp = true;
  }

  if (leveledUp) {
    const bonus = {
      attack: 2 * naikLevel,
      speed: 2 * naikLevel,
      defense: 2 * naikLevel,
      luck: 1 * naikLevel,
      berlian: 2 * naikLevel,
      emas: 10 * naikLevel,
      potion: 1 * naikLevel
    };

    user.stat.attack += bonus.attack;
    user.stat.speed += bonus.speed;
    user.stat.defense += bonus.defense;
    user.stat.luck += bonus.luck;

    user.inventory.berlian += bonus.berlian;
    user.inventory.emas += bonus.emas;
    user.inventory.potion += bonus.potion;

    const teks = `乂  *L E V E L  U P*

Kamu telah naik ke level *${user.level}* 🎊 (naik ${naikLevel} level)

Bonus:
◦ 💎 Berlian +${bonus.berlian}
◦ 🪙 Emas +${bonus.emas}
◦ 🥤 Potion +${bonus.potion}

Stats:
◦ Attack +${bonus.attack}
◦ Defense +${bonus.defense}
◦ Speed +${bonus.speed}
◦ Lucky +${bonus.luck}
`;

    await Exp.sendMessage(cht.id, {
      text: teks,
      contextInfo: {
        externalAdReply: {
          title: `❏ Elaina [ イレイナ ]`,
          body: `Time ${getTime()}`,
          thumbnail: fs.readFileSync(fol[10] + 'thumb1.jpg'),
          mediaUrl: `https://chat.whatsapp.com/IRCN3GDrdAG74X98zDi5Hc`,
          sourceUrl: `https://wa.me/6282238228919`,
          renderLargerThumbnail: false,
          showAdAttribution: true,
          mediaType: 2,
        },
        forwardingScore: 1999,
        isForwarded: true,
      }
    }, { quoted: cht });
  }
}


  function generateUniqueRekening(db) {
     let rekening;
     do {
       const random = Math.floor(Math.random() * 1000000);
       rekening = String(random).padStart(6, '0');
   
     } while (Object.values(db).some(player => player.rekening === rekening));
    return rekening;
  }
  
  
  function rupiah(angka) {
    return Number(angka).toLocaleString('id-ID');
  }
  
  
  function resetLimitUnbox(user) {
    if (!user.limitUnbox) {
      user.limitUnbox = {
        value: 1000, 
        lastReset: Date.now()
      };
      return;
    }

    const jakarta = new Date().toLocaleString('en-US', { timeZone: 'Asia/Jakarta' });
    const now = new Date(jakarta);

    const last = new Date(user.limitUnbox.lastReset || 0);
    const lastJakarta = new Date(new Date(last).toLocaleString('en-US', { timeZone: 'Asia/Jakarta' }));

    const sudahGantiHari = now.getDate() !== lastJakarta.getDate() ||
                         now.getMonth() !== lastJakarta.getMonth() ||
                         now.getFullYear() !== lastJakarta.getFullYear();

    if (sudahGantiHari) {
      user.limitUnbox.value += 1000; 
      user.limitUnbox.lastReset = Date.now();
    }
  }
  
  
  function waktuResetUnbox() {
    const now = new Date().toLocaleString('en-US', { timeZone: 'Asia/Jakarta' });
    const today = new Date(now);
    today.setHours(24, 0, 0, 0); 

    const waktuSisa = today - new Date(now);
    const menit = Math.floor((waktuSisa / 1000 / 60) % 60);
    const jam = Math.floor(waktuSisa / 1000 / 60 / 60);

    return `\`${jam} jam ${menit} menit lagi\``;
  }
  
  
  function keyFitur(jamSekarang = null) {
    const now = jamSekarang !== null ? jamSekarang : parseInt(func.newDate().split(", ")[2].split(":")[0]);
    const jamBuka = 20;
    const jamTutup = 22;

    return now >= jamBuka && now < jamTutup;
  }
  
  
  
ev.on({
  cmd: ['daftar', 'unreg'],
  listmenu: ['daftar', 'unreg'],
  tag: 'RPG',
  isGroup: true
}, async ({ args }) => {
 
  const player = db[userId];

  if (!args || !args.includes('|')) {
    return reply(`Contoh:\n\n- .${cht.cmd} Barr|16\nGunakan format: *nama|umur*`);
  }

  let [nama, umur] = args.split('|').map(v => v.trim());
  if (!nama || !umur || isNaN(umur)) {
    return reply(`Nama atau umur tidak valid.\nContoh penggunaan:\n.${cht.cmd} Barr|16`);
  }
  
  if (umur < 5) {
    return reply(`Dek dek, ngapain main hp padahal umur lu masih *${umur} tahun* loh ┐⁠(⁠￣⁠ヘ⁠￣⁠)`)
  }
  
  if (umur > 50) {
    return reply(`Tua bangka, udah tua masih aja main hp, ingat umur lu udah *${umur} tahun* ┐⁠(⁠￣⁠ヘ⁠￣⁠)`)
  }

 if (cht.cmd === "daftar") {
  if (player) return reply(`
Kamu sudah terdaftar di dunia rpg 
\`\`\`
▸ Nama   : ${player.nama}
▸ Umur   : ${player.umur}
▸ Level  : ${player.level}
\`\`\`
`);

  const rekening = generateUniqueRekening(db);

  db[userId] = {
    nama,
    umur,
    level: 1,
    exp: 0,
    atm: 1000,
    rekening,
    uang: 25000,
    nyawa: 100,
    tenaga: 100,
    point: 0,
    inventory: {
      tiket: 0,
      potion: 2,
      berlian: 0,
      emas: 0,
      besi: 0,
      batu: 0,
      kayu: 0,
      sampah: 0,
      umpan: 0,
      common: 0,
      uncommon: 0,
    },
    makanan: {
      roti: 1,
      pizza: 0,
      biskuit: 1,
      daging: 2,
      naspad: 0,
      mieayam: 0,
      sandwich: 0,
      burger: 0
    },
    peralatan: {
      kunci: false,
      beliung: false,
      pancing: false,
      kapak: false,
      busur: false,
      pedang: false
    },
    guild: {},
    cooldown: {
      gacha: 0,
      mancing: 0,
      menambang: 0,
      menebang: 0,
      berburu: 0,
      dungeon: 0,
      jelajah: 0,
      rampok: 0,
      kerja: 0,
      ngamen: 0,
      roket: 0,
      panen: 0
    },
    gudang: {},
    kandang: {
      ayam: 0,
      sapi: 0,
      babi: 0,
      domba: 0,
      kambing: 0,
      kerbau: 0,
      panda: 0,
      harimau: 0,
      gajah: 0,
      elang: 0,
      monyet: 0,
      serigala: 0,
      zebra: 0,
      rusa: 0
    },
    kolam: {
      arwana: 0,      
      bawal: 0,
      belut: 0,
      cupang: 0,
      gabus: 0,
      gurame: 0,
      koi: 0,    
      lele: 0,     
      mujair: 0,   
      nila: 0,     
      salmon: 0,   
      sarden: 0,   
      tuna: 0      
    },
    stat: {
      attack: 5,
      defense: 2,
      speed: 3,
      luck: 1
    },
    history: {},
    limitUnbox: {},
    donasi: {}
  };
  
  saveDB(db);

    const teks = `乂  *P E N D A F T A R A N  B E R H A S I L*
    
🎉 Selamat datang di dunia *RPG*, petualanganmu baru saja dimulai!
\`\`\`
▸ Nama   : ${nama}
▸ Umur   : ${umur}
▸ Level  : 1
▸ Uang   : Rp 25.000
\`\`\`
Kamu sekarang resmi jadi petualang!  
Jika ingin mengubah nama atau umur, ketik \`.unreg nama | umur\``

    await Exp.sendMessage(id, {
      text: teks,
      contextInfo
    }, { quoted: cht });

    await sleep(1500);
  
    await Exp.sendMessage(`${cfg.chId.newsletterJid}`, {
      text: `🎉 Selamat kepada *${nama}* yang telah resmi bergabung sebagai petualang di dunia RPG!
      
*Status:* \`\`\`
▸ Nama   : ${nama}
▸ Umur   : ${umur}
▸ Level  : 1
\`\`\``,
    contextInfo
    });
  
 } else {
    if (!player) return reply(peringatanDaftar);

    db[userId].nama = nama;
    db[userId].umur = umur;
    saveDB(db);

    const teks = `✅ Data berhasil diperbarui!
\`\`\`
▸ Nama Baru   : ${nama}
▸ Umur Baru   : ${umur}
▸ Level       : ${player.level}
\`\`\`
Kami cuma melakukan pergantian nama saat reg dan tidak menghapus ulang progres yang telah anda lakukan
`
  await Exp.sendMessage(id, {
    text: teks,
    contextInfo
  }, { quoted: cht });
  
 }
});

ev.on({
  cmd: ['status'],
  listmenu: ['status'],
  tag: 'RPG',
  isGroup: true
}, async () => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);

  const teks = `乂  *P R O F I L  K A M U*
\`\`\`
◦ 👤 Nama   : ${user.nama}
◦ 🎂 Umur   : ${user.umur}
◦ 🌟 Level  : ${user.level}
◦ ✨ Exp    : ${user.exp}
◦ ❤️ Health : ${user.nyawa}
◦ 🍗 Tenaga : ${user.tenaga}
◦ 💵 Uang   : ${rupiah(user.uang)}
◦ 💳 Atm    : ${rupiah(user.atm)}

◦ Stat:
  ▸ ATK     : ${user.stat.attack}
  ▸ DEF     : ${user.stat.defense}
  ▸ SPD     : ${user.stat.speed}
  ▸ LUCK    : ${user.stat.luck}
\`\`\``
  
  await Exp.sendMessage(id, {
    text: teks,
    contextInfo
  }, { quoted: cht })
  
});

ev.on({
  cmd: ['atm', 'uang', 'nabung', 'tarik'],
  listmenu: ['atm', 'uang', 'nabung', 'tarik'],
  tag: 'RPG',
  isGroup: true
}, async ({args}) => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);

if (cht.cmd === "uang" || cht.cmd === "atm") {
  const teks = `
◦ 💳 Atm          : Rp ${rupiah(user.atm)}
◦ 💵 Uang         : Rp ${rupiah(user.uang)}
◦ 🆔 No Rekening  : ${user.rekening}
`

  await Exp.sendMessage(id, {
    text: `乂  *D A N A  K A M U*\n\`\`\`${teks}\`\`\`\n- Ketik *.nabung* untuk menabung uang ke atm`,
    contextInfo
  }, { quoted: cht })
  
} else if (cht.cmd === "nabung") {
  if (!args) return reply(`Masukkan nominal uang yang ingin anda masukkan ke *ATM*`)
  
  if (args === "all") {

    const nominal = user.uang
    user.uang = 0
    user.atm += nominal
    saveDB(db)

    const teks = `
✅ Berhasil menabung seluruh uang sebesar *${rupiah(nominal)}* ke ATM.
\`\`\`
◦ 💳 ATM         : Rp ${rupiah(user.atm)}
◦ 🆔 No Rekening : ${user.rekening}
\`\`\``

    await Exp.sendMessage(id, {
      text: teks,
      contextInfo
    }, { quoted: cht })
  } else {
    if (!/^\d+$/.test(args)) return reply(`Nominal hanya boleh berupa angka, tanpa huruf atau simbol.`)
    
    if (user.uang < 20000) return reply(`Kamu membutuhkan minimal *20000* rupiah untuk menabung semua.`)
    
    const nominal = parseInt(args)
    if (nominal > user.uang) return reply(`Uang kamu tidak cukup untuk menabung sebanyak itu.`)
    if (nominal < 20000) return reply(`Nominal yang akan ditabung minimal *20000* rupiah.`)

    user.uang -= nominal
    user.atm += nominal
    saveDB(db)

    const teks = `
✅ Berhasil menabung sebesar *${rupiah(nominal)}* ke ATM.
\`\`\`
◦ 💳 ATM         : Rp ${rupiah(user.atm)}
◦ 🆔 No Rekening : ${user.rekening}
\`\`\``

    await Exp.sendMessage(id, {
      text: teks,
      contextInfo
    }, { quoted: cht })
  }
} else {
  if (!args) return reply(`Masukkan nominal uang yang ingin anda tarik dari *ATM*`)
  
  if (args === "all") {

    const nominal = user.atm
    user.atm = 0
    user.uang += nominal
    saveDB(db)

    const teks = `
✅ Berhasil menarik seluruh saldo sebesar *${rupiah(nominal)}*
\`\`\`
◦ 💳 ATM  : Rp ${rupiah(user.atm)}
◦ 💵 Uang : Rp ${rupiah(user.uang)}
\`\`\``

    await Exp.sendMessage(id, {
      text: teks,
      contextInfo
    }, { quoted: cht })
  } else {
    if (!/^\d+$/.test(args)) return reply(`Nominal hanya boleh berupa angka, tanpa huruf atau simbol.`)
    
    if (user.atm < 20000) return reply(`Minimal penarikan adalah *20000* rupiah.`)
        
    const nominal = parseInt(args)
    if (nominal > user.atm) return reply(`Saldo ATM kamu tidak cukup untuk menarik sebanyak itu.`)
    if (nominal < 20000) return reply(`Penarikan minimal adalah *20000* rupiah.`)

    user.uang += nominal
    user.atm -= nominal
    saveDB(db)

    const teks = `
✅ Berhasil menarik uang sebesar *${rupiah(nominal)}*
\`\`\`
◦ 💳 ATM  : Rp ${rupiah(user.atm)}
◦ 💵 Uang : Rp ${rupiah(user.uang)}
\`\`\``

    await Exp.sendMessage(id, {
      text: teks,
      contextInfo
    }, { quoted: cht })
  }
}
})

ev.on({
  cmd: ['buylimit', 'belilimit'],
  listmenu: ['belilimit'],
  tag: 'RPG',
  args: "*❗ Masukkan nominal nya*",
  isGroup: true
}, async ({args}) => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);
  
  const jumlah = parseInt(args)
  if (isNaN(jumlah) || jumlah <= 0) {
    return reply(`Masukkan nominal yang benar\ncontoh: \`.${cht.cmd} 5\``)
  }
    
  if (!user.limitUnbox) {
    user.limitUnbox = { 
      value: 1000,
      lastReset: Date.now()
    };
  }

  const totalJumlah = jumlah * 100000
  
  if (totalJumlah > user.uang) 
    return reply(`Uang kamu tidak cukup untuk membeli *${jumlah} limit* unbox.\nHarga total: Rp *${rupiah(totalJumlah)}*`)
    
  user.uang -= totalJumlah
  user.limitUnbox.value += jumlah
  saveDB(db)
  
  const text = `乂  *P E M B E L I A N*

✅ Kamu telah membeli limit sebanyak \`${jumlah}\` seharga \`${rupiah(totalJumlah)}\`
\`\`\`
🍩 Limit unbox  : ${user.limitUnbox.value}
💵 Uang         : ${rupiah(user.uang )}
\`\`\``
  
  await Exp.sendMessage(id, {
    text,
    contextInfo
  }, { quoted: cht })
  
})

ev.on({
  cmd: ['ceklimit', 'ceklimirunbox'],
  listmenu: ['ceklimit'],
  tag: 'RPG'
}, async () => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);
    
  if (!user.limitUnbox) {
    user.limitUnbox = { 
      value: 1000,
      lastReset: Date.now()
    };
  }
  
  const { value } = user.limitUnbox
  
  if (value === 0) return reply("Limit unbox kamu telah habis") 
  
  const text = `乂  *L I M I T  U N B O X*

Kamu masih memiliki \`${value} limit\` unbox

Beli limit jika ingin membuka uncommon/common
atau menunggu sampe esok hari`

  await Exp.sendMessage(id, {
    text,
    contextInfo
  }, { quoted: cht })
  
})
  
ev.on({
  cmd: ['point', 'pointgacha', 'cekpoint', 'tukarpoint'],
  listmenu: ['tukarpoint', 'cekpoint'],
  tag: 'RPG',
  isGroup: true
}, async ({args}) => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);
  
  if (!user.history.gacha) return reply("kamu belum pernah gacha sebelumnya, gacha aja dulu agar dapat point, menang atau ga tetap dapat point")
      
  const cc = cht.cmd
  const ppoint = user.point
  
  if (cc === "cekpoint" || cc === "pointgacha" || cc === "point") {
    const teks = `乂  *P O I N T  K A M U*

Kamu memiliki *${ppoint}* yang terkumpul...

Gunakan point ini untuk menukarnya menjadi limit unbox common atau uncommon, 1 limit setara 10 point\n`
  
    return Exp.sendMessage(id, {
      image: {
         url: "https://files.catbox.moe/rdtk3c.jpg" 
      },
      caption: teks,
      footer: `Kalau mau tukar point menjadi limit unbox silahkan pencet tombol di bawah untuk melihat list nya`,
      buttons: [
         {
            buttonId: `.tukarpoint`,
            buttonText: {
               displayText: "🍩 Tukar jadi limit"
            }
         }
      ],
      viewOnce: true,
      headerType: 6
    }, { quoted: cht })
  }
  
  if (cc === "tukarpoint") {
    const jumlah = Math.max(1, parseInt(args) || 1);
    const total = jumlah * 2;

    if (user.point < total) return reply(`Point kamu tidak cukup...\nDiperlukan: *${total} point*`);

    user.point -= total;
    user.limitUnbox.value += jumlah;
    saveDB(db)

    const teks = `乂  *T U K A R  P O I N T*

✅ Kamu telah menukar *${total} point* menjadi *${jumlah} limit unbox*
\`\`\`
◦ 🍩 Limit unbox  : ${user.limitUnbox.value}
◦ ❇️ Sisa point   : ${user.point}
\`\`\``

    return Exp.sendMessage(id, {
      text: teks,
      contextInfo
    }, { quoted: cht })
  }
  
})

ev.on({
  cmd: ['kandang', 'kolam'],
  listmenu: ['kandang', 'kolam'],
  tag: 'RPG',
  isGroup: true
}, async () => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);
  
if (cht.cmd === "kandang") {
  const {ayam, babi, harimau, kambing, gajah, elang, domba, kerbau, monyet, panda, rusa, sapi, serigala, zebra} = user.kandang;
  
  const list = `
◦ 🐓 Ayam      : ${ayam}
◦ 🐖 Babi      : ${babi}
◦ 🐏 Domba     : ${domba}
◦ 🦅 Elang     : ${elang}
◦ 🐘 Gajah     : ${gajah}
◦ 🐅 Harimau   : ${harimau}
◦ 🐐 Kambing   : ${kambing}
◦ 🐃 Kerbau    : ${kerbau}
◦ 🐒 Monyet    : ${monyet}
◦ 🐼 Panda     : ${panda}
◦ 🦌 Rusa      : ${rusa}
◦ 🐄 Sapi      : ${sapi}
◦ 🐺 Serigala  : ${serigala}
◦ 🦓 Zebra     : ${zebra}
`

  await Exp.sendMessage(id, {
    text: `乂  *K A N D A N G*\n\`\`\`${list}\`\`\``,
    contextInfo
  }, { quoted: cht });
  
} else {
  const { arwana, bawal, belut, cupang, gabus, gurame, koi, lele, mujair, nila, salmon, sarden, tuna } = user.kolam;
  
  const teks = `
◦ Arwana    : ${arwana}
◦ Bawal     : ${bawal}
◦ Belut     : ${belut}
◦ Cupang    : ${cupang}
◦ Gabus     : ${gabus}
◦ Gurame    : ${gurame}
◦ Koi       : ${koi}
◦ Lele      : ${lele}
◦ Mujair    : ${mujair}
◦ Nila      : ${nila}
◦ Salmon    : ${salmon}
◦ Sarden    : ${sarden}
◦ Tuna      : ${tuna}
`

  await Exp.sendMessage(id, {
    text: `乂  *K O L A M*\n\`\`\`${teks}\`\`\``, 
    contextInfo 
  }, { quoted: cht })

}
})

ev.on({
  cmd: ['tiket'],
  listmenu: ['tiket'],
  tag: 'RPG',
  isGroup: true
}, async () => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);
  
  if (user.inventory.tiket <= 0) return reply(`Kamu tidak memiliki tiket`);
  
  const teks = `乂  *T I K E T*

- Kamu memiliki ${user.inventory.tiket} tiket

Gunakan untuk gacha *energy* atau *premium*
1x spin = 1 tiket
`

  await Exp.sendMessage(id, {
    text: teks,
    contextInfo
  }, { quoted: cht })
  
})

ev.on({
  cmd: ['addlvl', 'adduang', 'addatm'],
  listmenu: ['addlvl', 'adduang', 'addatm'],
  tag: 'RPG',
  isMention: "*❗ Tag orangnya*",
  isOwner: true
}, async ({args}) => {
  const target = cht.mention[0]
  const targetId = target.split("@")[0]
  
  const barIn = db[target]
  const barIs = `Orang yang di tag belum daftar rpg`
  
  const jumlah = parseInt(args)
  const yh = cht.cmd
  
  if (yh === "adduang") {
    if (!barIn) return reply(barIs)
    if (jumlah > 99999999) return reply(`Maksimal nominal 99999999`)
    
    barIn.uang += jumlah
    saveDB(db)
    
    await reply(`✅ Berhasil menambah jumlah uang @${targetId} sebanyak *Rp ${rupiah(jumlah)}*`, { mentions: [target] })
  }
  
  if (yh === "addatm") {
    if (!barIn) return reply(barIs)
    if (jumlah > 99999999) return reply(`Maksimal nominal 99999999`)
    
    barIn.atm += jumlah
    saveDB(db)

    await reply(`✅ Berhasil menambah jumlah atm @${targetId} sebanyak *Rp ${rupiah(jumlah)}*`, { mentions: [target] })
  }
  
  if (yh === "addlvl") {
    if (!barIn) return reply(barIs)
    if (jumlah > 90) return reply(`Maksimal nominal 90`)
    
    barIn.level += jumlah
    saveDB(db)

    await reply(`✅ Berhasil menambah level @${targetId} sebanyak *${jumlah} level*`, { mentions: [target] })
  }
})
  
ev.on({
  cmd: ['inventory', 'inv', 'peralatan'],
  listmenu: ['inventory', 'peralatan'],
  tag: 'RPG',
  isGroup: true
}, async () => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);
  
if (cht.cmd === "inv" || cht.cmd === "inventory") {
  const { kayu, besi, emas, berlian, potion, umpan, batu, uncommon, common, sampah } = user.inventory
  
  const { roti, sandwich, pizza, burger, mieayam, naspad, daging, biskuit } = user.makanan

  const teks = `
▸ BARANG
◦ 💎 Berlian  : ${berlian}
◦ 🪙 Emas     : ${emas}
◦ 🔩 Besi     : ${besi}
◦ 🪨 Batu     : ${batu}
◦ 🪵 Kayu     : ${kayu}
◦ 🪾 Sampah   : ${sampah}
◦ 🗳️ Common   : ${common}
◦ 🎁 Uncommon : ${uncommon}

▸ KEBUTUHAN
◦ 🥤 Potion   : ${potion}
◦ 🍗 Daging   : ${daging}
◦ 🪱 Umpan    : ${umpan}
◦ 🍕 Pizza    : ${pizza}
◦ 🍞 Roti     : ${roti}
◦ 🍪 Biskuit  : ${biskuit}
◦ 🍜 Mieayam  : ${mieayam}
◦ 🥪 Sandwich : ${sandwich}
◦ 🍙 Naspad   : ${naspad}
`
  
  await Exp.sendMessage(id, { 
    text: `乂  *I N V E N T O R Y*\n\`\`\`${teks}\`\`\``,
    contextInfo
  }, { quoted: cht });
  
} else {
  const { kunci, beliung, pancing, kapak, busur, pedang } = user.peralatan;
  const toSymbol = (val) => val ? 'Ada ✅' : 'Tidak ada ❌';

  const teks = `
◦ 🗝️ Kunci    : ${toSymbol(kunci)}
◦ ⛏️ Beliung  : ${toSymbol(beliung)}
◦ 🪓 Kapak    : ${toSymbol(kapak)}
◦ 🎣 Pancing  : ${toSymbol(pancing)}
◦ 🏹 Busur    : ${toSymbol(busur)}
◦ 🗡️ Pedang   : ${toSymbol(pedang)}
` 
  await Exp.sendMessage(id, {
    text: `乂  *P E R A L A T A N*\n\`\`\`${teks}\`\`\``,
    contextInfo
  }, { quoted: cht })
  
}
})

ev.on({
  cmd: ['shop', 'toko'],
  listmenu: ['shop'],
  tag: 'RPG',
  isGroup: true
}, async () => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);

  const tokoTeks = `乂  *S H O P P I N G*

\`[ BARANG ]\`
🥤 *Potion*
› Harga beli: Rp 1.000
› Harga jual: Rp 500

💎 *Berlian*
› Harga beli: Rp 25.000
› Harga jual: Rp 15.000

🪙 *Emas*
› Harga beli: Rp 18.000
› Harga jual: Rp 10.000

🔩 *Besi*
› Harga beli: Rp 12.000
› Harga jual: Rp 7.000

🪨 *Batu*
› Harga beli: Rp 6.000
› Harga jual: Rp 3.000

🪵 *Kayu*
› Harga beli: Rp 4.000
› Harga jual: Rp 2.000

🪾 *Sampah*
› Harga beli: Tidak tersedia
› Harga jual: Rp 500


\`[ MAKANAN ]\`
🍗 *Daging*
› Harga beli: Rp 7.000
› Harga jual: Rp 4.000

🍙 *NASPAD*
› Harga beli: 5000
› Harga jual: 2000

🍪 *BISKUIT*
› Harga beli: 2000
› Harga jual: 500

🍜 *MIEAYAM*
› Harga beli: 15000
› Harga jual: 5000
    
🥪 *SANDWICH*
› Harga beli: 10000
› Harga jual: 4000

🍕 *PIZZA*
› Harga beli: 10000
› Harga jual: 3000

🍞 *ROTI*
› Harga beli: 5000
› Harga jual: 2000

    
\`[ EVENT ]\`
🗳️ *Common*
› Harga beli: Rp 100.000
› Harga jual: Rp 45.000

🎁 *Uncommon*
› Harga beli: Rp 150.000
› Harga jual: Rp 55.000

🎫 *Tiket*
› Harga beli: Rp 120.000
› Harga jual: Tidak Tersedia

🍩 *Limit*
› Harga beli: Rp 100.000
› Harga jual: Tidak tersedia


\`[ IKAN ]\`
🐟 *Arwana*
› Harga beli: Rp 30.000
› Harga jual: Rp 20.000

🐟 *Bawal*
› Harga beli: Rp 6.000
› Harga jual: Rp 3.500

🐟 *Belut*
› Harga beli: Rp 5.500
› Harga jual: Rp 3.000

🐟 *Cupang*
› Harga beli: Rp 4.000
› Harga jual: Rp 2.000

🐟 *Gabus*
› Harga beli: Rp 8.000
› Harga jual: Rp 5.000

🐟 *Gurame*
› Harga beli: Rp 10.000
› Harga jual: Rp 6.000

🐟 *Koi*
› Harga beli: Rp 14.000
› Harga jual: Rp 9.000

🐟 *Lele*
› Harga beli: Rp 4.500
› Harga jual: Rp 2.500

🐟 *Mujair*
› Harga beli: Rp 5.000
› Harga jual: Rp 3.000

🐟 *Nila*
› Harga beli: Rp 5.500
› Harga jual: Rp 3.200

🐟 *Salmon*
› Harga beli: Rp 18.000
› Harga jual: Rp 12.000

🐟 *Sarden*
› Harga beli: Rp 8.000
› Harga jual: Rp 5.000

🐟 *Tuna*
› Harga beli: Rp 16.000
› Harga jual: Rp 10.000


\`[ HEWAN ]\`
🐔 *Ayam*
› Harga beli: Rp 12.000
› Harga jual: Rp 7.000

🐄 *Sapi*
› Harga beli: Rp 40.000
› Harga jual: Rp 25.000

🐖 *Babi*
› Harga beli: Rp 35.000
› Harga jual: Rp 20.000

🐑 *Domba*
› Harga beli: Rp 30.000
› Harga jual: Rp 18.000

🐐 *Kambing*
› Harga beli: Rp 32.000
› Harga jual: Rp 20.000

🐃 *Kerbau*
› Harga beli: Rp 45.000
› Harga jual: Rp 28.000

🐼 *Panda*
› Harga beli: Rp 100.000
› Harga jual: Rp 75.000

🐅 *Harimau*
› Harga beli: Rp 90.000
› Harga jual: Rp 65.000

🐘 *Gajah*
› Harga beli: Rp 110.000
› Harga jual: Rp 80.000

🦅 *Elang*
› Harga beli: Rp 25.000
› Harga jual: Rp 16.000

🐒 *Monyet*
› Harga beli: Rp 20.000
› Harga jual: Rp 12.000

🐺 *Serigala*
› Harga beli: Rp 38.000
› Harga jual: Rp 24.000

🦓 *Zebra*
› Harga beli: Rp 55.000
› Harga jual: Rp 35.000

🦌 *Rusa*
› Harga beli: Rp 50.000
› Harga jual: Rp 30.000

🪱 *Umpan*
› Harga beli: Rp 5.000
› Harga jual: Rp 2.000


\`[ PERALATAN ]\`
🗝️ *Kunci*
› Harga beli: Rp 20.000
› Harga jual: Tidak tersedia

⛏️ *Beliung*
› Harga beli: Rp 75.000
› Harga jual: Tidak tersedia

🪓 *Kapak*
› Harga beli: Rp 65.000
› Harga jual: Tidak tersedia

🎣 *Pancing*
› Harga beli: Rp 55.000
› Harga jual: Tidak Tersedia

🗡️ *Pedang*
› Harga beli: 80.000
› Harga jual: Tidak tersedia 

🏹 *Busur*
› Harga beli: 80.000
› Harga jual: Tidak tersedia 



\`PEMBELIAN/JUAL BARANG\`
- *.beli potion 1*
- *.jual potion 1*

\`PEMBELIAN LIMIT UNBOX\`
- *.belilimit 1*

\`PEMBELIAN PERALATAN\`
- *.belipt kapak*
`;

  await Exp.sendMessage(id, {
    text: tokoTeks,
    contextInfo
  }, { quoted: cht })
  
});

ev.on({
  cmd: ['belipt'],
  listmenu: ['belipt'],
  tag: 'RPG',
  args: `Contoh:\n\n- .${cht.cmd} kapak`,
  isGroup: true
}, async ({ args }) => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);

  const barang = args.toLowerCase();
  
  const hargaPeralatan = {
    kunci: 20000,
    beliung: 75000,
    kapak: 65000,
    pancing: 55000,
    pedang: 80000,
    busur: 80000
  };

  if (!(barang in hargaPeralatan)) {
    return reply(`Peralatan *${barang}* tidak tersedia di toko peralatan`);
  }
  
  if (user.peralatan[barang] === true) return reply(`Peralatan *${barang}* sudah kamu miliki`);
  
  const harga = hargaPeralatan[barang];

  if (user.uang < harga) {
    return reply(`Uang kamu tidak cukup\nDibutuhkan: *Rp ${rupiah(harga)}*`);
  }

  user.uang -= harga;
  user.peralatan[barang] = true;
  
  saveDB(db);
  
  const teks = `✅ Kamu berhasil membeli *${barang}* seharga Rp ${rupiah(harga)}`
  
  await Exp.sendMessage(id, {
    text: teks,
    contextInfo
  }, { quoted: cht })
  
});

ev.on({
  cmd: ['beli', 'buy'],
  listmenu: ['beli'],
  tag: 'RPG',
  args: `Contoh:\n\n- .${cht.cmd} potion 1`,
  isGroup: true
}, async ({ args }) => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);

  const [itemArg, jumlahStr] = args.split(' ')
  const jumlahArg = parseInt(jumlahStr)
  const barang = itemArg.toLowerCase()

  if (!barang || isNaN(jumlahArg) || jumlahArg <= 0) {
    return reply(`Format salah!\nContoh: .${cht.cmd} potion 2`);
  }

  const hargaBeli = {
    potion: 1000,
    tiket: 120000,
    berlian: 25000,
    emas: 18000,
    besi: 12000,
    batu: 6000,
    kayu: 4000,
    common: 100000,
    uncommon: 150000,
    
    daging: 7000,
    naspad: 5000,
    biskuit: 2000,
    mieayam: 15000,
    sandwich: 10000,
    pizza: 10000,
    roti: 5000,
    
    arwana: 30000,
    bawal: 6000,
    belut: 5500,
    cupang: 4000,
    gabus: 8000,
    gurame: 10000,
    koi: 14000,
    lele: 4500,
    mujair: 5000,
    nila: 5500,
    salmon: 18000,
    sarden: 8000,
    tuna: 16000,
    umpan: 5000,
    
    ayam: 12000,
    sapi: 40000,
    babi: 35000,
    domba: 30000,
    kambing: 32000,
    kerbau: 45000,
    panda: 100000,
    harimau: 90000,
    gajah: 110000,
    elang: 25000,
    monyet: 20000,
    serigala: 38000,
    zebra: 55000,
    rusa: 50000
  };

  if (!(barang in hargaBeli)) {
    return reply(`Barang *${barang}* tidak tersedia di toko.`);
  }

  const totalHarga = hargaBeli[barang] * jumlahArg;
  if (user.uang < totalHarga) {
    return reply(`Uang kamu tidak cukup\nDibutuhkan: *Rp ${rupiah(totalHarga)}*`);
  }

  const isInventory = barang in user.inventory;
  const isKolam = barang in user.kolam;
  const isKandang = barang in user.kandang;
  const isMakanan = barang in user.makanan;

  if (!isInventory && !isKolam && !isKandang && !isMakanan) {
    return reply(`Barang *${barang}* tidak dikenali dalam database.`);
  }

  user.uang -= totalHarga;

  if (isInventory) {
    user.inventory[barang] += jumlahArg;
  }
  
  if (isMakanan) {
    user.makanan[barang] += jumlahArg;
  }
  
  if (isKolam) {
    user.kolam[barang] += jumlahArg;
  }
  
  if (isKandang) {
    user.kandang[barang] += jumlahArg;
  }

  saveDB(db);
  
  const teks = `\n✅ Kamu berhasil membeli *${jumlahArg} ${barang}* seharga *Rp ${rupiah(totalHarga)}*\n`;

  await Exp.sendMessage(id, {
    text: `乂  *P E M B E L I A N*\n${teks}`,
    contextInfo
  }, { quoted: cht });
})

ev.on({
 cmd: ['jual', 'sell'],
 listmenu: ['jual'],
 tag: 'RPG',
 args: `Contoh:\n\n- .${cht.cmd} potion 1\n- .${cht.cmd} potion all`,
 isGroup: true
}, async ({ args }) => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);

  const [itemArg, jumlahStrRaw] = args.split(' ');
  if (!itemArg || !jumlahStrRaw) {
    return reply(`Format salah!\nContoh: .${cht.cmd} potion 2\nAtau: .${cht.cmd} potion all`);
  }

  const barang = itemArg.toLowerCase();
  const jumlahStr = jumlahStrRaw.toLowerCase();
  let jumlahArg = parseInt(jumlahStr);

  const hargaJual = {
    potion: 500,
    berlian: 15000,
    emas: 10000,
    besi: 7000,
    batu: 3000,
    kayu: 2000,
    sampah: 500,
    common: 45000,
    uncommon: 55000,
    
    daging: 4000,
    naspad: 2000,
    biskuit: 500,
    mieayam: 5000,
    sandwich: 4000,
    pizza: 3000,
    roti: 2000,
    
    arwana: 20000,
    bawal: 3500,
    belut: 3000,
    cupang: 2000,
    gabus: 5000,
    gurame: 6000,
    koi: 9000,
    lele: 2500,
    mujair: 3000,
    nila: 3200,
    salmon: 12000,
    sarden: 5000,
    tuna: 10000,
    umpan: 2000,
    
    ayam: 7000,
    sapi: 25000,
    babi: 20000,
    domba: 18000,
    kambing: 20000,
    kerbau: 28000,
    panda: 75000,
    harimau: 65000,
    gajah: 80000,
    elang: 16000,
    monyet: 12000,
    serigala: 24000,
    zebra: 35000,
    rusa: 30000
  };

  if (!(barang in hargaJual)) {
    return reply(`Barang *${barang}* tidak tersedia untuk dijual.`);
  }

  if (hargaJual[barang] <= 0) {
    return reply(`Barang *${barang}* tidak bisa dijual.`);
  }

  const isInventory = barang in user.inventory;
  const isKolam = barang in user.kolam;
  const isKandang = barang in user.kandang;
  const isMakanan = barang in user.makanan;

  if (!isInventory && !isKolam && !isKandang && !isMakanan) {
    return reply(`Barang *${barang}* tidak ada dalam penyimpanan.`);
  }

  let stok = 0;
  if (isInventory) stok = user.inventory[barang];
  else if (isKolam) stok = user.kolam[barang];
  else if (isKandang) stok = user.kandang[barang];
  else if (isMakanan) stok = user.makanan[barang];

  if (jumlahStr === 'all') {
    jumlahArg = stok;
  }

  if (!jumlahArg || isNaN(jumlahArg) || jumlahArg <= 0) {
    return reply(`Jumlah tidak valid.\nKamu punya *${stok} ${barang}*.`);
  }

  if (stok < jumlahArg) {
    return reply(`Kamu hanya punya *${stok} ${barang}*.`);
  }

  if (isInventory) user.inventory[barang] -= jumlahArg;
  else if (isKolam) user.kolam[barang] -= jumlahArg;
  else if (isKandang) user.kandang[barang] -= jumlahArg;
  else if (isMakanan) user.makanan[barang] -= jumlahArg;

  const totalUang = hargaJual[barang] * jumlahArg;
  user.uang += totalUang;
  saveDB(db);
  
  const teks = `✅ Kamu berhasil menjual *${jumlahArg} ${barang}* seharga *Rp ${rupiah(totalUang)}*`;
  await Exp.sendMessage(id, {
    text: `乂  *P E N J U A L A N*\n\n${teks}`,
    contextInfo
  }, { quoted: cht });
})

ev.on({
  cmd: ['tf', 'transfer'],
  listmenu: ['tf'],
  tag: 'RPG',
  args: "*❗ Silahkan ketik nominal nya*",
  isGroup: true
}, async ({ args }) => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);

  const [noRek, jumlahNya] = args.split(' ')
  const jumlah = parseInt(jumlahNya);
  const rek = noRek.toLowerCase();

  if (isNaN(jumlah) || jumlah <= 0) return reply('Masukkan jumlah yang valid.');

  const targetId = Object.keys(db).find(id => db[id].rekening === rek);
  if (!targetId) return reply('Nomor rekening tidak ditemukan, pastikan nomor rekeningnya udah benar');

  const biayaTransfer = 500
  const total = jumlah + biayaTransfer

  if (user.uang < total) return reply(`Uang kamu tidak cukup. Dibutuhkan total: ${total} (termasuk biaya transfer 500)`);

  user.uang -= total;
  db[targetId].atm += jumlah;
  saveDB(db)
  
  const teks = `乂  *T R A N S F E R*

✅ Transaksi berhasil...

Kamu mengirim uang sebesar *Rp ${rupiah(jumlah)}*
Rekening tujuan:  \`${rek}\`
Biaya transfer: 500

Sisa Uang kamu: *${rupiah(user.uang)}*`
  await Exp.sendMessage(id, {
    text: teks,
    contextInfo
  }, { quoted: cht });
  
})

ev.on({
  cmd: ['ngemis', 'sedekah'],
  listmenu: ['ngemis', 'sedekah'],
  tag: 'RPG',
  args: "*❗ Masukkan nominal-nya*"
}, async ({ args }) => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);
  
  const jumlah = parseInt(args);
  
  if (cht.cmd === "ngemis") {
    if (user.donasi?.ngemis) return reply(`Kamu masih melakukan open donasi, tunggu ada yang bersedekah dan memberimu uang seikhlas nya`)
  
    if (!user.donasi) {
       user.donasi = {
         ngemis: false,
         nominal: 0
       };
    }

    if (jumlah > 50000) return reply(`Woi yang lu minta itu di luar nalar bangt jumlahnya ┐⁠(⁠￣⁠ヘ⁠￣⁠)\n\n- Maksimal 50k aja\n- Dan tunggu orang yang ingin donasi\n\nDasar miskin, rakus pula`);

    user.donasi.ngemis = true;
    user.donasi.nominal = jumlah;
    saveDB(db)
  
    const teks = `
Kini kamu melakukan open donasi
\`\`\`
◦ Nominal  : *Rp ${rupiah(user.donasi.nominal)}*
\`\`\`
tunggu ada orang kesihan yang melakukan donasi seikhlas nya
`

    await Exp.sendMessage(id, {
      text: teks,
      contextInfo
    }, { quoted: cht })
  
  } else {
 
    if (isNaN(jumlah) || jumlah <= 0) return reply("Masukkan jumlah sedekah yang valid!");
    if (user.uang < jumlah) return reply("Uang kamu tidak cukup untuk sedekah sebesar itu!");

    const daftarPengemis = Object.entries(db).filter(([id, data]) =>
      id !== userId &&
      data.donasi &&
      data.donasi.ngemis === true
    );

    let targetId;
    if (daftarPengemis.length > 0) {
      const random = Math.floor(Math.random() * daftarPengemis.length);
      targetId = daftarPengemis[random][0];
    } else {
      targetId = "6282238228919@s.whatsapp.net";
    }

    db[targetId].atm += jumlah
    user.uang -= jumlah
  
    if (targetId !== "6282238228919@s.whatsapp.net") {
      if (db[targetId].donasi) {
        db[targetId].donasi = {}
      }
      
      const teks = `
💵 Kamu menerima sedekah sebesar *Rp ${rupiah(jumlah)}* dari seseorang
Semoga bermanfaat 🤲
` 
    
      await Exp.sendMessage(targetId, {
        text: teks,
        contextInfo
      });
    }
    
    saveDB(db)
    
    const teks2 = `
✅ Sedekah sebesar *Rp ${rupiah(jumlah)}* berhasil dikirim ke ${targetId === "6282238228919@s.whatsapp.net" ? "Yayasan Pusat Kemanusiaan" : `@${targetId.split("@")[0]}`}

Sedekahmu bisa menjadi pahala bagimu
`

    await Exp.sendMessage(id, {
      text: `乂  *S E D E K A H*\n${teks2}`,
      contextInfo: {
         ...contextInfo,
         mentionedJid: [targetId]
      }
    }, { quoted: cht })
  }
})

ev.on({
  cmd: ['gacha'],
  listmenu: ['gacha'],
  tag: 'RPG',
  args: `*GACHA APA?*\n\n- .${cht.cmd} energy\n- .${cht.cmd} premium\n\nGacha tersebut menggunakan 1 tiket/gacha, dan dapatkan 10 point setiap gacha`,
  isGroup: true 
}, async ({ args, cht }) => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);
  
  if (!user.cooldown.gacha) user.cooldown.gacha = 0
  
  const now = Date.now()
  const cooldownMs = 1000 * 60 * 1
  const last = user.cooldown.gacha

  if (now - last < cooldownMs) {
    const sisa = msToTime(cooldownMs - (now - last))
    return reply(`Tunggu \`${sisa}\` lagi...`)
  }
  
  
  if (!keyFitur()) {
    return reply(`\`EVENT MASIH TERTUTUP\`\n\nEvents gacha cuma terbuka di jam 20:00 - 21:59 WIB`);
  }

  if (!['energy', 'premium'].includes(args)) {
    return reply(`\`PILIHAN GACHA\`\n\n- .${cht.cmd} energy\n- .${cht.cmd} premium`);
  }

  if (user.inventory.tiket <= 0) return reply(`Kamu tidak memiliki tiket`);
  
  user.cooldown.gacha = now
  user.inventory.tiket -= 1
  user.point = (user.point || 0) + 10
  user.history.gacha = (user.history.gacha || 0) + 1
  saveDB(db)
  
  await reply(`*-1 Tiket* 🎫`)
  const _key = keys[sender]
  
  await sleep(1500)
  await edit(`⏳ Hasil akan di tentukan selama 15 detik...`, _key)
  await sleep(10000)
  
  if (args === "energy") {
    const chance = Math.random();
    const sukses = chance < 0.2;
    if (!sukses) return await Exp.sendMessage(id, {
       text: `乂  *G A C H A*\n\n💩 \`KAMU GA BERUNTUNG\` 💩\n\nKamu kali ini tidak hoki, munkin belum baca bismillah atau tangsn lu tangan penggocok\n\n*+10 point*`,
       contextInfo
    }, { quoted: cht });

    const diKali = Math.floor(Math.random() * 5) + 1;
    const jumlah = Math.floor(Math.random() * 1000) + 5000;
    const hasil = jumlah * diKali;

    await func.archiveMemories["addEnergy"](userId, hasil);
    return await Exp.sendMessage(id, {
       text: `乂  *G A C H A*\n\n🎉 \`KAMU BERUNTUNG\` 🎉\n\nKamu gacha energy dan mendapat kan energy sebanyak *${hasil} Energy*\n\n*+10 Point*`,
       contextInfo
    }, { quoted: cht });
    
  } else if (args === "premium") {
    const chance = Math.random();
    const sukses = chance < 0.1
    if (!sukses) return await Exp.sendMessage(id, {
       text: `乂  *G A C H A*\n\n💩 \`KAMU GA BERUNTUNG\` 💩\n\nKamu kali ini tidak hoki, munkin belum baca bismillah atau tangsn lu tangan penggocok\n\n*+10 point*`,
       contextInfo
    }, { quoted: cht });

    const hari = Math.floor(Math.random() * 15) + 1;
    const userData = await func.archiveMemories.get(userId);
    const timeMs = func.parseTimeString(`${hari}d`);
    if (!("premium" in userData)) userData.premium = { time: 0 };

    const now = Date.now();
    const base = userData.premium.time < now ? now : userData.premium.time;
    userData.premium.time = base + timeMs;

    return await Exp.sendMessage(id, {
       text: `乂  *G A C H A*\n\n🎉 \`KAMU BERUNTUNG\` 🎉\n\nKamu gacha premium dan mendapatkan premium *${hari} hari*\n\n*+10 point*`,
       contextInfo
    }, { quoted: cht })
  }
})

ev.on({ 
  cmd: ['mining', 'menambang'],
  listmenu: ['mining'],
  tag: 'RPG',
  isGroup: true
}, async () => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);

  if (!user.peralatan?.beliung) return reply(`Kamu belum memiliki *beliung*`)

  const now = Date.now()
  const cooldownMs = 1000 * 60 * 10
  const last = user.cooldown.menambang

  if (now - last < cooldownMs) {
    const sisa = msToTime(cooldownMs - (now - last))
    return reply(`Kamu perlu istirahat terlebih dahulu\nKamu bisa mining lagi setelah ${sisa} lagi`)
  }
  
  if (user.nyawa < 30) return reply(`Health kamu terlalu rendah, silahkan minum potion untuk memulihkan Health`)
  if (user.tenaga < 15) return reply(`Kamu terlalu lapar, silahkan makan untuk memulihkan kekuatan`)
  
  let tenaga = Math.floor(Math.random() * 4) + 16
  let exp = Math.floor(Math.random() * 4) + 11
  let berlian = Math.floor(Math.random() * 4) + 1
  let emas = Math.floor(Math.random() * 4) + 6
  let besi = Math.floor(Math.random() * 4) + 16
  let batu = Math.floor(Math.random() * 4) + 26
  let misNyawa = Math.floor(Math.random() * 4) + 11
  
  user.inventory.berlian += berlian
  user.inventory.emas += emas
  user.inventory.besi += besi
  user.inventory.batu += batu
  user.nyawa -= misNyawa
  user.tenaga -= tenaga
  user.exp += exp
  user.history.mining = (user.history.mining || 0) + 1
  user.cooldown.menambang = now;
  
  await checkLevelUp(user)
  saveDB(db);
  
  await reply(`🤝 Kamu direkrut sebagai penambang di *PT PAMA* untuk bekerja sehari penuh!`)
  await sleep(2500)
  await edit(`⛏️ Kamu mulai menggali batuan dan mineral di dalam tambang...`, keys[sender])
  await sleep(3000)
  await edit(`🪨 Kamu terus memukul bebatuan keras dengan beliung, keringat mu mulai menetes dari dagu...`, keys[sender])
  await sleep(3000)
  
  if (Math.random() < 0.2) {
    user.peralatan.beliung = false
    await reply('💥 Beliung kamu patah saat mining tadi...')
  }
  
  const cederaTeks = ['kepala terbentur', 'menginjak serpihan', 'tangan keseleo', 'dehidrasi', 'kejepit'];
  const cederaAcak = cederaTeks.sort(() => 0.5 - Math.random()).slice(0, 2);
  const cederah = cederaAcak.join('\n› ');

  let teks = `乂  *M E N A M B A N G*

Dan kamu selesai menambang 😮‍💨
dan pendapatan kamu hari ini:
\`\`\`
◦ 💎 Berlian ${berlian}x
◦ 🪙 Emas ${emas}x
◦ 🔩 Besi ${besi}x
◦ 🪨 Batu ${batu}x
\`\`\`
› *+${exp} Exp*

Kamu juga mengalami cedera:
› ${cederah}
› -${misNyawa} Health

Hp kamu berkurang sebanyak *${misNyawa}*, dan sisa Hp kamu sebanyak *${user.nyawa}*, tenaga kamu juga ikut berkurang karena pekerjaan ini memerlukan tenaga ekstra, sisa tenaga *${user.tenaga}*
Material yang kamu dapatkan bisa di jual loh
`
  
  await Exp.sendMessage(id, {
    text: teks,
    contextInfo
  }, { quoted: cht })
})

ev.on({
  cmd: ['menebang'],
  listmenu: ['menebang'],
  tag: 'RPG',
  isGroup: true
}, async () => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);

  if (!user.peralatan?.kapak) return reply(`Kamu belum memiliki *kapak*`)
  
  const now = Date.now()
  const cooldownMs = 1000 * 60 * 10
  const last = user.cooldown.menebang

  if (now - last < cooldownMs) {
    const sisa = msToTime(cooldownMs - (now - last))
    return reply(`Kamu perlu istirahat terlebih dahulu\nKamu bisa menebang lagi setelah ${sisa} lagi`)
  }
 
  if (user.nyawa < 30) return reply(`Health kamu terlalu rendah, silahkan minum potion untuk memulihkan Health`)
  if (user.tenaga < 15) return reply(`kamu terlalu lapar, silahkan makan untuk memulihkan kekuatan`)

  let exp = Math.floor(Math.random() * 4) + 11
  let kayu = Math.floor(Math.random() * 4) + 6
  let daging = Math.floor(Math.random() * 4) + 1
  let sampah = Math.floor(Math.random() * 4) + 1
  
  user.inventory.kayu += kayu
  user.makanan.daging += daging
  user.inventory.sampah += sampah
  user.exp += exp
  user.history.menebang = (user.history.menebang || 0) + 1
  user.cooldown.menebang = now;

  await checkLevelUp(user)
  saveDB(db);
  
  await reply(`🌲 Kamu mulai menebang pohon besar di tepi hutan dengan kapakmu...`)
  await sleep(2500)
  await edit(`🪓 Setiap ayunan kapak menggema di antara pepohonan yang rindang...`, keys[sender])
  await sleep(2500)
  await edit(`🪵 Potongan demi potongan kayu mulai berjatuhan seiring kapakmu terus bekerja...`, keys[sender])
  await sleep(3000)
 
  if (Math.random() < 0.2) {
    user.peralatan.kapak = false
    await reply('💥 Kapak kamu patah saat menebang tadi...')
  }
  
  let teks = `乂  *M E N E B A N G*

Dan akhirnya kamu selesai menebang
dan pendapatan kamu hari ini:
\`\`\`
◦ 🪵 Kayu ${kayu}x
◦ 🍗 Daging ${daging}x
◦ 🪾 Sampah ${sampah}x
\`\`\`
› *+${exp} Exp*

Tenaga kamu terkuras lumayan banyak juga, karena menebang pohon menggunakan kapak, sisa tenaga *${user.tenaga}*
Barang yang kamu dapatkan bisa di jual loh
`
  await Exp.sendMessage(id, {
    text: teks,
    contextInfo
  }, { quoted: cht })
  
})

ev.on({
  cmd: ['mancing'],
  listmenu: ['mancing'],
  tag: 'RPG',
  isGroup: true
}, async () => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);

  if (!user.peralatan?.pancing) return reply(`Kamu belum memiliki *pancing*`)
  
  const now = Date.now()
  const cooldownMs = 1000 * 60 * 10
  const last = user.cooldown.mancing

  if (now - last < cooldownMs) {
    const sisa = msToTime(cooldownMs - (now - last))
    return reply(`Kamu perlu istirahat terlebih dahulu\nKamu bisa menebang lagi setelah ${sisa} lagi`)
  }
  
  if (user.inventory.umpan <= 0) return reply(`Kamu tidak memiliki umpan`)

  if (user.tenaga < 15) return reply(`kamu terlalu lapar, silahkan makan untuk memulihkan kekuatan`)
  
  let exp = Math.floor(Math.random() * 4) + 11
  
  let hasilIkan = {
    arwana: Math.floor(Math.random() * 2) + 1,
    bawal: Math.floor(Math.random() * 2) + 1,
    belut: Math.floor(Math.random() * 1) + 1,
    cupang: Math.floor(Math.random() * 2),
    gabus: Math.floor(Math.random() * 2),
    gurame: Math.floor(Math.random() * 2),
    koi: Math.floor(Math.random() * 2),
    lele: Math.floor(Math.random() * 2),
    mujair: Math.floor(Math.random() * 2),
    nila: Math.floor(Math.random() * 2),
    salmon: Math.floor(Math.random() * 2),
    sarden: Math.floor(Math.random() * 2),
    tuna: Math.floor(Math.random() * 2)
  }

  for (let ikan in hasilIkan) {
    user.kolam[ikan] += hasilIkan[ikan]
  }
  
  user.inventory.umpan -= 2
  user.exp += exp
  user.history.mancing = (user.history.mancing || 0 ) + 1
  user.cooldown.mancing = now
  
  await checkLevelUp(user)
  saveDB(db)

  await reply(`🎣 Kamu melemparkan kail ke sungai yang tenang...`)
  await sleep(2500)
  await edit(`💧 Air bergelombang pelan... umpanmu mulai tenggelam sedikit demi sedikit.`, keys[sender])
  await sleep(2500)
  await edit(`🐟 Sepertinya ada sesuatu yang menarik tali pancingmu!`, keys[sender])
  await sleep(3000)

  if (Math.random() < 0.2) {
    user.peralatan.pancing = false
    await reply('💥 Pancing kamu patah saat strike tadi...')
  }
  
  let hasilText = Object.entries(hasilIkan)
    .filter(([_, jumlah]) => jumlah > 0)
    .map(([ikan, jumlah]) => `◦ ${ikan[0].toUpperCase() + ikan.slice(1)} ${jumlah}x`)
  .join('\n')

  let teks = `乂  *M E M A N C I N G*

Dan akhirnya kamu selesai memancing
dan pendapatan kamu hari ini:
\`\`\`
${hasilText}
\`\`\`
› *+${exp} Exp*

Ikan yang kamu dapatkan bisa di jual loh
`

  await Exp.sendMessage(id, {
    text: teks,
    contextInfo
  }, { quoted: cht })
})

ev.on({
  cmd: ['unbox'],
  listmenu: ['unbox'],
  tag: 'RPG',
  args: `Contoh:\n- .${cht.cmd} common 99\n- .${cht.cmd} uncommon 99`,
  isGroup: true
}, async ({ args }) => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar)
  
  if (!user.peralatan?.kunci) return reply(`Kamu belum memiliki *kunci* untuk membuka box`);

  resetLimitUnbox(user);

  const [tipeRaw, jumlahRaw] = args.split(' ')
  const jumlah = parseInt(jumlahRaw)
  const tipe = tipeRaw.toLowerCase()

  if (jumlah > user.limitUnbox.value) {
    return reply(`Limit unbox kamu hanya tersisa *${user.limitUnbox.value} box* hari ini\n\nReset limit setelah: ${waktuResetUnbox()}`);
  }
  
  if (!tipe || isNaN(jumlah) || jumlah <= 0) {
    return reply(`Format salah!\nContoh: .${cht.cmd} common 2`);
  } 
  
  if (!['common', 'uncommon'].includes(tipe)) {
    return reply(`📦 Jenis box tidak tersedia!

*BOX YANG TERSEDIA:*
- common
- uncommon

Cara pakai:
.${cht.cmd} common 5
.${cht.cmd} uncommon 1`);
  }
  
  if(jumlah > 20000) return reply("Maksimal unbox adalah `20rb box`")
  
  if (user.inventory[tipe] < jumlah) return reply(`Jumlah *${tipeRaw}* yang kamu miliki ga cukup dengan jumlah yang ingin kamu buka`)

  let total = {
    berlian: 0,
    emas: 0,
    besi: 0,
    batu: 0,
    kayu: 0,
    sampah: 0,
    potion: 0,
    exp: 0
  };

  for (let i = 0; i < jumlah; i++) {
    let hadiah;
    if (tipe === 'common') {
      hadiah = {
        berlian: Math.floor(Math.random() * 1) + 1,
        emas: Math.floor(Math.random() * 2) + 4,
        besi: Math.floor(Math.random() * 2) + 5,
        batu: Math.floor(Math.random() * 4) + 2,
        kayu: Math.floor(Math.random() * 2) + 5,
        sampah: Math.floor(Math.random() * 2) + 7,
        potion: Math.floor(Math.random() * 2) + 1,
        exp: Math.floor(Math.random() * 2) + 5
      };
    } else if (tipe === 'uncommon') {
      hadiah = {
        berlian: Math.floor(Math.random() * 2) + 1,
        emas: Math.floor(Math.random() * 3) + 10,
        besi: Math.floor(Math.random() * 5) + 7,
        batu: Math.floor(Math.random() * 7) + 7,
        kayu: Math.floor(Math.random() * 5) + 7,
        sampah: Math.floor(Math.random() * 2) + 5,
        potion: Math.floor(Math.random() * 2) + 1,
        exp: Math.floor(Math.random() * 3) + 10
     };
    }

    for (let k in total) {
      total[k] += hadiah[k];
    }
  }
  
  user.inventory.berlian += total.berlian
  user.inventory.emas += total.emas
  user.inventory.besi += total.besi
  user.inventory.batu += total.batu
  user.inventory.kayu += total.kayu
  user.inventory.sampah += total.sampah
  user.inventory.potion += total.potion
  user.inventory[tipe] -= jumlah
  user.limitUnbox.value -= jumlah
  user.exp += total.exp
  
  await checkLevelUp(user)
  saveDB(db)
  
  if (Math.random() < 0.2) {
    user.peralatan.kunci = false
    saveDB(db)
    await reply('💥 Kunci kamu patah saat membuka box tadi...')
  }
  
  const teks = `乂  *U N B O X*

Kamu membuka *${tipe} box* sebanyak *${jumlah}x* dan mendapatkan:
\`\`\`
◦ 💎 Berlian ${total.berlian}x
◦ 🪙 Emas ${total.emas}x
◦ 🪨 Batu ${total.batu}x
◦ 🔩 Besi ${total.besi}x
◦ 🪵 Kayu ${total.kayu}x
◦ 🪾 Sampah ${total.sampah}x
◦ 🥤 Potion ${total.potion}x
\`\`\`
› *+${total.exp} Exp*

Box *${tipe}* tersisa *${user.inventory[tipe]}*
`
  await sleep(1500)
  await Exp.sendMessage(id, {
    text: teks,
    contextInfo
  }, { quoted: cht })
})

ev.on({
  cmd: ['heal', 'mam'],
  listmenu: ['heal', 'mam'],
  tag: 'RPG',
  isGroup: true
}, async ({ args }) => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);

  if (cht.cmd === 'heal') {
    if (user.nyawa >= 100) return reply(`Health kamu masih penuh`)
    const jumlah = Math.max(1, parseInt(args) || 1);
    
    if (user.inventory.potion < jumlah) {
      return reply(`🥤 Potion kamu tidak cukup untuk digunakan sebanyak *${jumlah}*`);
    }

    const total = 5 * jumlah;
    user.inventory.potion -= jumlah;
    user.nyawa = Math.min(user.nyawa + total, 100);

    saveDB(db);

    const teks = `
Kamu menggunakan *potion* sebanyak *${jumlah}*
› *+${total} Health*

Health kamu sekarang *${user.nyawa}/100*
Untuk makan agar tidak kelaparan ketik *.mam*
`;

    await Exp.sendMessage(id, {
      text: `乂  *H E A L*\n${teks}`,
      contextInfo
    }, { quoted: cht });

  } else {
    if (user.tenaga >= 100) return reply(`Tenaga kamu masih penuh`);

    const makananTenaga = {
      roti: 5,
      pizza: 10,
      biskuit: 4,
      daging: 3,
      naspad: 15,
      mieayam: 12,
      sandwich: 8,
      burger: 10
    };
    
    const [makananNama, jumlahArg] = args.split(' ');
    const makanan = makananNama.toLowerCase();
    const jumlah = Math.max(1, parseInt(jumlahArg) || 1);

    if (!makanan || !makananTenaga[makanan])
      return reply(`🍽️ Ketik nama makanan yang valid!\nContoh: *.mam roti 2*`);

    if (!user.makanan[makanan] || user.makanan[makanan] < jumlah)
      return reply(`🍽️ ${makanan} kamu tidak cukup untuk digunakan sebanyak *${jumlah}*`);

    const total = makananTenaga[makanan] * jumlah;
    user.makanan[makanan] -= jumlah;
    user.tenaga = Math.min(user.tenaga + total, 100);

    saveDB(db);

    const teks = `
Kamu memakan *${makanan}* sebanyak *${jumlah}*
› *+${total} Tenaga* 

Tenaga kamu sekarang *${user.tenaga}/100*
Untuk menyembuhkan health ketik *.heal*
`;

    await Exp.sendMessage(id, {
      text: `乂  *M A K A N*\n${teks}`,
      contextInfo
    }, { quoted: cht });
  }
})

ev.on({
  cmd: ['rampok', 'copet'],
  listmenu: ['rampok'],
  tag: 'RPG',
  isGroup: true,
  isMention: "*❗ Tag targetnya*"
}, async () => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);

  let target = cht.mention[0];
  let targetId = target.split("@")[0]
  
  if (!db[target]) return reply(`Orang yang kamu targetkan tidak terdaftar di *RPG*, coba cari yang lain`)
  if (db[target].uang <= 0) return reply(`orang yang kamu targetkan orang miskin, coba cari orang kaya aja deh`)
  if (user.tenaga < 15) return reply(`Kamu terlalu lelah untuk merampok. Coba makan terlebih dahulu`)
  
  const now = Date.now()
  const cooldownMs = 1000 * 60 * 10
  const last = user.cooldown.rampok

  if (now - last < cooldownMs) {
    const sisa = msToTime(cooldownMs - (now - last))
    return reply(`Kamu baru saja merampok, tunggu ${sisa} lagi`)
  }
  
  let hadiah = Math.floor(Math.random() * 5000) + 10000
  let kecepatan = user.stat.speed * 0.1
  let peluang = Math.floor(kecepatan * 100)

  if (peluang >= 70) {
    let targetGold = db[target].uang
    if (targetGold < hadiah) hadiah = targetGold
    
    user.tenaga -= 15
    user.uang += hadiah
    db[target].uang -= hadiah
    user.cooldown.rampok = now
    user.history.maling = (user.history.maling || 0) + 1
    saveDB(db)
    
    await Exp.sendMessage(id, {
      text: `乂  *N Y O P E T*\n\n💰 Kamu berhasil merampok *Rp ${rupiah(hadiah)}* dari @${targetId}, Dan terhindar dari penangkapan\n\n› Kecepatanmu: *${peluang}%*`,
      contextInfo: {
         ...contextInfo,
         mentionedJid: [target]
      }
    }, { quoted: cht })
    
  } else {
    let denda = Math.floor(hadiah / 2)
    user.uang = Math.max(0, user.uang - denda)
    user.cooldown.rampok = now
    saveDB(db)
    
    await Exp.sendMessage(id, {
      text: `乂  *N Y O P E T*\n\n🚨 Kamu gagal merampok @${targetId} dan malah ditangkap warga, dan di gebuk di tempat, kamu di paksa bayar denda *Rp ${rupiah(denda)}*.\n\n› Kecepatanmu: *${peluang}%*`,
      contextInfo: {
         ...contextInfo,
         mentionedJid: [target]
      }
    }, { quoted: cht })
  
  }
})

ev.on({
  cmd: ['ngamen'],
  listmenu: ['ngamen'],
  tag: 'RPG',
  isGroup: true
}, async () => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);
  
  const now = Date.now()
  const cooldownMs = 1000 * 60 * 10
  const last = user.cooldown.ngamen

  if (now - last < cooldownMs) {
    const sisa = msToTime(cooldownMs - (now - last))
    return reply(`Kamu baru saja ngamen, tunggu ${sisa} lagi`)
  }
  
  let hadiah = Math.floor(Math.random() * 25000) + 10000
  let potion = Math.floor(Math.random() * 1) + 3
  
  user.inventory.potion += potion
  user.uang += hadiah
  user.cooldown.ngamen = now
  saveDB(db)
  
  const teks = [
`🎻 Kamu mengamen keliling pasar. Anak-anak ikut joget, pedagang kasih koin. Total yang kamu kumpulkan hari ini: *Rp ${rupiah(hadiah)}*, Dan mendapatkan *${potion}x potion*`,
`🎤 Kamu mengamen tapi suaramu fals. Seorang nenek melempar sandal, tapi ada juga yang kasihan dan tetap ngasih *Rp ${rupiah(hadiah)}*, Dan mendapatkan *${potion}x potion*`,
`🪕 Kamu ngamen pakai ember dan sendok, tapi entah kenapa warga suka banget! Mereka kasih kamu *Rp ${rupiah(hadiah)}* buat beli alat musik beneran, Dan mendapatkan *${potion}x potion*`,
`🎶 Dengan suara merdu dan petikan gitar, kamu menyanyikan lagu kenangan di tengah keramaian. Orang-orang berkumpul dan memberi apresiasi dalam bentuk *Rp ${rupiah(hadiah)}*, Dan mendapatkan *${potion}x potion*`,
`🎸 Kamu mengamen di pinggir jalan dan menarik perhatian warga. Beberapa orang melemparkan uang receh ke topimu. Kamu mendapatkan *Rp ${rupiah(hadiah)}*, Dan mendapatkan *${potion}x potion*`
  ]
  
  const hhh = teks[Math.floor(Math.random() * teks.length)]
  
  await Exp.sendMessage(id, {
    text: `乂  *N G A M E N*\n\n${hhh}\n`,
    contextInfo
  }, { quoted: cht })
  
})

ev.on({
  cmd: ['taxi', 'taxy'],
  listmenu: ['taxi'],
  tag: 'RPG',
  isGroup: true
}, async () => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);

  const now = Date.now();
  const cooldownMs = 1000 * 60 * 10; 
  const last = user.cooldown.taxi || 0;

  if (now - last < cooldownMs) {
    const sisa = msToTime(cooldownMs - (now - last));
    return reply(`Kamu baru saja narik, tunggu ${sisa} lagi untuk dapat orderan baru.`);
  }

  if (user.tenaga < 20) return reply(`Tenaga kamu lelah, makan dulu untuk melanjutkan narik taxi.`);

  user.history.taxi = (user.history.taxi || 0) + 1
  user.cooldown.taxi = now;
  user.tenaga -= 20;

  await reply(`
🚶⬛⬛⬛⬛⬛⬛⬛⬛⬛
⬛⬜⬜⬜⬛⬜⬜⬜⬛⬛
⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛
🏘️🏘️🏘️🏘️🌳  🌳 🏘️       🚕

✅ Mendapatkan orderan....
`);
  await sleep(2000);

  await reply(`
🚶⬛⬛⬛⬛⬛🚐⬛⬛⬛🚓🚚
🚖⬜⬜⬜⬛⬜⬜⬜🚓⬛🚑
⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛🚙
🏘️🏘️🏢️🌳  🌳 🏘️  🏘️🏡

🚖 Mengantar ke tujuan...
`);
  await sleep(2000);

  await reply(`
⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛🚓
⬛⬜🚗⬜⬜⬛⬜🚐⬜⬜⬛🚙🚚🚑
⬛⬛⬛⬛🚒⬛⬛⬛⬛⬛⬛🚚
🏘️🏘️🏘️🏘️🌳  🌳 🏘️

🚖 Selesai mengantar pelanggan...
`);
  await sleep(2000);

  const bintang = Math.floor(Math.random() * 5) + 1;
  const review = {
    1: "🤬 Supir nya bau ketek ga pake deodoran, hidung gw jadi mimisan nge baunya",
    2: "🥱 Supir nya lambat banget, lebih ceoat naik sepeda",
    3: "😐 Biasa aja sih, ga buruk tapi juga ga bagus.",
    4: "😉 Nyaman, supir ramah, cuma muter-muter dikit.",
    5: "🌟 Perjalanan sangat nyaman dan cepat, terima kasih bang!"
  };

  const bonus = bintang * 5500;
  const gaji = Math.floor(Math.random() * 3000) + 5000 + bonus;
  user.uang += gaji;
  saveDB(db);

  let teks = `乂  *T A X Y*

Kamu selesai mengantar pelanggan sampai ke tujuan nya dengan selamat
\`\`\`
⭐ Rating  : ${'⭐'.repeat(bintang)}${'☆'.repeat(5 - bintang)}
💬 Ulasan  :
› "${review[bintang]}"
\`\`\`
Uang yang kamu dapatkan: *Rp ${rupiah(gaji)}*
`;

  await Exp.sendMessage(cht.id, {
    text: teks,
    contextInfo
  }, { quoted: cht })
})

ev.on({
  cmd: ['ngetod'],
  listmenu: ['ngetod'],
  tag: 'RPG',
  isGroup: true
}, async () => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);
  
  if (user.tenaga < 20) return reply("kamu terlalu lelah untuk ngentod")
   
  const now = Date.now()
  const cooldownMs = 1000 * 60 * 10 
  const last = user.cooldown.ngetod || 0

  if (now - last < cooldownMs) {
    const sisa = msToTime(cooldownMs - (now - last))
    return reply(`Kamu baru saja ngentod baru baru ini, tunggu ${sisa} lagi`)
  }
  
  const uang = Math.floor(Math.random() * 250000) + 20000
  const naspad = Math.floor(Math.random() * 5)
  const exp = Math.floor(Math.random() * 11) + 4
  
  user.uang += uang
  user.naspad += naspad
  user.exp += exp
  user.history.ngetod = (user.history.ngetod || 0) + 1
  user.cooldown.ngetod = now
  saveDB(db)
  
  await reply(`📲 Orderan Masuk dari [ Om Teguh ]

ᴋᴀᴍᴜ ᴅᴀɴ ᴏᴍ ᴛᴇɢᴜʜ ᴍᴇᴍʙᴏᴏᴋɪɴɢ ʜᴏᴛᴇʟ
▒▒[ᴏʏᴏ]▒▒
▒▒▄▄▄▒▒ Kalian Berdua Masuk Ke kamar
▒█▀█▀█▒ kamu Membuka bh mu
░█▀█▀█░ Tete Mu diremas oleh om tgh
░█▀█▀█░  ( . )( . )
███████.  | 🤚 |


Om Teguh Mulai Memasukan kntl nya ke dalam mmk mu....
`)

  await sleep(2500)
  await reply(`Kamu Kesakitan ...

(_)(_)=====D \\()/  

Rahim mu terasa hangat
`)

  await sleep(2500)
  await reply(`Om teguh pun crott 

()()=====D 💦💦💦   


✅ Orderan Selesai
`)
 
  await sleep(2500)
  await reply(`Om Teguh Memberimu Uang Lebih karena Goyanganmu Sangat unik 😝
`)

    const hsl = `
乂  *O P E N  B O*

Hasil yang di dapatkan dari orderan om teguh
\`\`\`
◦ 💵 Uang    : ${rupiah(uang)}
◦ ✨ Exp     : ${exp}
◦ 🍙 Naspad  : ${naspad}
\`\`\`
*+ 1 point ngetod*
`
  await Exp.sendMessage(id, {
    text: hsl,
    contextInfo
  }, { quoted: cht })
  
})

ev.on({
  cmd: ['panen'],
  listmenu: ['panen'],
  tag: 'RPG',
  isGroup: true
}, async () => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);

  if (user.tenaga < 15) return reply(`Kamu terlalu lelah untuk memanen, coba makan terlebih dahulu`)

  const now = Date.now()
  const cooldownMs = 1000 * 60 * 10
  const last = user.cooldown.panen

  if (now - last < cooldownMs) {
    const sisa = msToTime(cooldownMs - (now - last))
    return reply(`Kamu baru saja panen, tunggu ${sisa} lagi`)
  }

  const emojiTanaman = {
    tomat: '🍅',
    jagung: '🌽',
    gandum: '🌾',
    timun: '🥒',
    wortel: '🥕',
    ubi: '🍠',
    terong: '🍆',
    kentang: '🥔',
    nanas: '🍍',
    jeruk: '🍊',
    apel: '🍎',
    kiwi: '🥝',
    alpukat: '🥑',
    persik: '🍑'
  }

  const tanaman = {
    tomat: Math.floor(Math.random() * 5) + 5,
    jagung: Math.floor(Math.random() * 4) + 4,
    gandum: Math.floor(Math.random() * 6) + 5,
    timun: Math.floor(Math.random() * 3) + 3,
    wortel: Math.floor(Math.random() * 3) + 3,
    ubi: Math.floor(Math.random() * 3) + 3,
    terong: Math.floor(Math.random() * 2) + 3,
    kentang: Math.floor(Math.random() * 4) + 5,
    nanas: Math.floor(Math.random() * 2) + 1,
    jeruk: Math.floor(Math.random() * 3) + 2,
    apel: Math.floor(Math.random() * 2) + 2,
    kiwi: Math.floor(Math.random() * 2) + 1,
    alpukat: Math.floor(Math.random() * 1) + 1,
    persik: Math.floor(Math.random() * 1) + 1
  }

  const jenisTerpilih = Object.keys(tanaman)
    .sort(() => Math.random() - 0.5)
    .slice(0, 5)

  let pesanHasil = '乂  *P A N E N*\n\nAkhirnya kamu selesai memanen\n```\n'
  let totalUang = 0

  for (let jenis of jenisTerpilih) {
    const jumlah = tanaman[jenis]
    const nilai = jumlah * 2500
    totalUang += nilai
    const emoji = emojiTanaman[jenis]
    pesanHasil += `◦ ${emoji} ${jenis} ${jumlah}x = Rp ${rupiah(nilai)}\n`
  }

  user.uang += totalUang
  user.tenaga -= 15
  user.cooldown.panen = now
  saveDB(db)
  
  pesanHasil += `\`\`\`\n› Total pendapatan: *Rp${rupiah(totalUang)}*`

  await Exp.sendMessage(id, {
    text: pesanHasil,
    contextInfo
  }, { quoted: cht })
  
})

ev.on({
  cmd: ['berburu', 'hunt'],
  listmenu: ['berburu'],
  tag: 'RPG',
  isGroup: true
}, async () => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);
  
  if (user.tenaga < 15) return reply(`Kamu terlalu lelah untuk berburu, coba makan terlebih dahulu`) 
  
  if (user.nyawa < 35) return reply(`Kamu terlalu lelah untuk berburu, coba makan terlebih dahulu`)
  
  if (!user.peralatan?.panah && !user.peralatan?.pedang) {
    return reply(`Kamu belum memiliki alat untuk berburu, yaitu *panah* atau *pedang*`);
  }
  
  const now = Date.now()
  const cooldownMs = 1000 * 60 * 10
  const last = user.cooldown.berburu

  if (now - last < cooldownMs) {
    const sisa = msToTime(cooldownMs - (now - last))
    return reply(`Kamu baru saja *berburu*, tunggu ${sisa} lagi`)
  }
 
  let hp = Math.floor(Math.random() * 4) + 11
  let exp = Math.floor(Math.random() * 4) + 11
  
  const emojiHewan = {
    ayam: '🐔',
    sapi: '🐄',
    babi: '🐖',
    domba: '🐑',
    kambing: '🐐',
    kerbau: '🐃',
    panda: '🐼',
    harimau: '🐅',
    gajah: '🐘',
    elang: '🦅',
    monyet: '🐒',
    serigala: '🐺',
    zebra: '🦓',
    rusa: '🦌'
  };

  const hewan = {
    ayam: Math.floor(Math.random() * 5) + 1,
    sapi: Math.floor(Math.random() * 2) + 1,
    babi: Math.floor(Math.random() * 3) + 1,
    domba: Math.floor(Math.random() * 2) + 1,
    kambing: Math.floor(Math.random() * 2) + 1,
    kerbau: Math.floor(Math.random() * 2) + 1,
    panda: Math.floor(Math.random() * 2) + 1,
    harimau: Math.floor(Math.random() * 2) + 1,
    gajah: Math.floor(Math.random() * 1) + 1,
    elang: Math.floor(Math.random() * 2) + 1,
    monyet: Math.floor(Math.random() * 2) + 1,
    serigala: Math.floor(Math.random() * 2) + 1,
    zebra: Math.floor(Math.random() * 1) + 1,
    rusa: Math.floor(Math.random() * 1) + 1
  };

  const jenisTerpilih = Object.keys(hewan)
    .sort(() => Math.random() - 0.5)
    .slice(0, 5);

  let pesanHasil = '乂  *B E R B U R U*\n\nAkhirnya berburu pun selesai\n```\n';
  let total = 0;

  for (let jenis of jenisTerpilih) {
    const jumlah = hewan[jenis];
    user.kandang[jenis] += jumlah;
    const emoji = emojiHewan[jenis];
    pesanHasil += `◦ ${emoji} ${jenis} ${jumlah}x\n`;
    total += jumlah;
  }

  user.cooldown.berburu = now
  user.tenaga -= 15
  user.nyawa -= hp
  user.exp += exp
  user.history.berburu = (user.history.berburu || 0) + 1
  saveDB(db)
  
  pesanHasil += `\`\`\`\n› *+${exp} Exp*\n\nTotal hewan di dapatkan *${total}*, dan kamu sedikit mengalami cedera, -${hp} Health\n\nketik .kandang untuk mengecek hewan hasil buruan kamu`;
  
  await Exp.sendMessage(id, {
    text: pesanHasil,
    contextInfo
  }, { quoted: cht })
  
})

ev.on({
  cmd: ['ekplor', 'jelajah'],
  listmenu: ['jelajah'],
  tag: 'RPG',
  isGroup: true
}, async () => { 
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);
  
  if (user.tenaga < 15) return reply(`Kamu terlalu lelah untuk menjelajah, coba makan terlebih dahulu`) 
  
  if (user.nyawa < 35) return reply(`Kamu terlalu lelah untuk menjelajah, coba makan terlebih dahulu`)
  
  const now = Date.now()
  const cooldownMs = 1000 * 60 * 10
  const last = user.cooldown.jelajah

  if (now - last < cooldownMs) {
    const sisa = msToTime(cooldownMs - (now - last))
    return reply(`Kamu baru saja *menjelajah*, tunggu ${sisa} lagi`)
  }
  
  let hp = Math.floor(Math.random() * 4) + 11
  let exp = Math.floor(Math.random() * 4) + 11
  
  const emoh = {
    berlian: '💎',
    emas: '🪙',
    besi: '🔩',
    batu: '🪨',
    kayu: '🪵',
    sampah: '🪾',
    potion: '🥤',
    umpan: '🪱'
  };

  const loot = {
    berlian: Math.floor(Math.random() * 1) + 1,
    emas: Math.floor(Math.random() * 3) + 1,
    besi: Math.floor(Math.random() * 4) + 1,
    batu: Math.floor(Math.random() * 5) + 1,
    kayu: Math.floor(Math.random() * 7) + 1,
    sampah: Math.floor(Math.random() * 4) + 1,
    potion: Math.floor(Math.random() * 3) + 1,
    umpan: Math.floor(Math.random() * 2) + 1
  };

  const jenisTerpilih = Object.keys(loot)
    .sort(() => Math.random() - 0.5)
    .slice(0, 5); 

  let pesanHasil = '乂  *M E N J E L A J A H*\n\nAkhirnya menjelajah pun selesai\n```\n';
  let total = 0;

  for (let jenis of jenisTerpilih) {
    const jumlah = loot[jenis];
    user.inventory[jenis] += jumlah;
    const emoji = emoh[jenis];
    pesanHasil += `◦ ${emoji} ${jenis} ${jumlah}x\n`;
    total += jumlah;
  }

  user.cooldown.jelajah = now
  user.tenaga -= 15
  user.nyawa -= hp
  user.exp += exp
  user.history.menjelajah = (user.history.menjelajah || 0) + 1
  saveDB(db)
  
  pesanHasil += `\`\`\`\n› *+${exp} Exp*\n\nBarang yang di dapatkan berjumlah *${total}*, dan kamu sedikit mengalami cedera, -${hp} Health\n`;
  
  await Exp.sendMessage(id, {
    text: pesanHasil,
    contextInfo
  }, { quoted: cht })
})

ev.on({
  cmd: ['dungeon'],
  listmenu: ['dungeon'],
  tag: 'RPG',
  isGroup: true
}, async ({ args }) => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);
  
  const now = Date.now()
  const cooldownMs = 1000 * 60 * 60 * 24
  const last = user.cooldown.dungeon

  if (now - last < cooldownMs) {
    const sisa = msToTime(cooldownMs - (now - last))
    return reply(`Kamu baru saja keluar dari dungeon dengan penuh luka, kamu bisa masuk dungeon lagi setelah \`${sisa}\``)
  }
  
  if (user.nyawa < 20) return reply(`HP-mu terlalu rendah untuk bertarung!\nGunakan *heal potion* terlebih dahulu.`);

  if (user.tenaga < 15) return reply(`Tenaga kamu terlalu rendah\nCobalah makan makanan dulu biar kuat.`);

  const params = args;
  const type = params.toLowerCase();

  if (!type) {
    const teks0 = `乂  *D U N G E O N  T U A*

Kamu berdiri di depan sebuah dungeon gelap penuh misteri.
Apa yang ingin kamu lakukan?

ꕺ \`.${cht.cmd} daftar\` ➜ Untuk daftar dungeon
ꕺ \`.${cht.cmd} join\` ➜ Untuk bersiap masuk dungeon
ꕺ \`.${cht.cmd} lanjut\` ➜ Untuk lanjutkan dungeon
ꕺ \`.${cht.cmd} floor\` ➜ Untuk cek lantai dungeon
ꕺ \`.${cht.cmd} out\` ➜ Untuk keluar dari dungeon

`
    return Exp.sendMessage(id, {
      text: teks0,
      contextInfo
    }, { quoted: cht })
  }

  switch (type) {
    case 'daftar':
      if (user.dungeon) return reply(`Kamu telah terdaftar`)
     
      user.dungeon = {
        lantai: 1,
        clear: 0,
        percent: 0.1,
        status: "idle"
      };
      saveDB(db)
      
      const teks1 = `乂  *D U N G E O N  T U A*

✅ Kamu berhasil daftar di dungeon

Sialhkan ketik \`.${cht.cmd} join\` untuk bersiap masuk dungeon
`
      return await Exp.sendMessage(id, {
        text: teks1,
        contextInfo
      }, { quoted: cht })
      
      break;
      
    case 'join':
      if (!user.dungeon) return reply(`Kamu belum daftar dungeon.\nKetik \`.${cht.cmd} daftar\` dulu!`);
      if (user.dungeon.status === 'berlangsung') return reply(`
Kamu sudah berada di dalam dungeon! ketik *.${cht.cmd} lanjut* untuk melanjutkan\n`);

      user.dungeon.status = 'berlangsung';
      user.dungeon.lantai = 1;
      user.dungeon.percent = 0.1;
      saveDB(db)
      
      const teks2 = `乂  *D U N G E O N  T U A*
      
Kamu memasuki dungeon yang gelap dan menyeramkan...\nMonster mengintai di balik bayangan!\n\nKetik *.${cht.cmd} lanjut* untuk mulai bertarung!`

      await Exp.sendMessage(id, {
        text: teks2,
        contextInfo
      }, { quoted: cht })
      
      break;
    
    case 'floor':
      if (!user.dungeon) return
      if (user.dungeon.status === "idle") return reply(`Kamu telah keluar dari dungeon`)
      
      const lantaiSekrang = user.dungeon.lantai
      
      const teks3 = `乂  *D U N G E O N  T U A*
      
Sekarang kamu sedang berada di lantai *${lantaiSekrang}*
`
      await Exp.sendMessage(id, {
        text: teks3,
        contextInfo
      }, { quoted: cht })
      
      break;
      
    case 'lanjut':
      if (!user.dungeon) return reply(`Kamu belum masuk dungeon.\nKetik \`.${cht.cmd} join\` dulu!`);
      
      if (user.dungeon.status === "idle") return reply(`Silahkan ketik \`.${cht.cmd} join\` untuk bersiap menasuki dungeon`)
      
      const monster = [
        "Orc", 
        "Pejabat", 
        "Tobrut jahat",
        "Windah Batubara", 
        "Jawir", 
        "Herobrine", 
        "Karbit", 
        "Lizart", 
        "Ambazing", 
        "Raja hitam", 
        "Ambatron", 
        "witch"
      ];
      
      const encounter = monster[Math.floor(Math.random() * monster.length)];
      const totalStat = user.stat.attack + user.stat.defense + user.stat.luck + user.stat.speed
      const difficulty = 50;
      const success = Math.random() < (totalStat / difficulty);

      if (success) {
        user.history.dungeon = (user.history.dungeon || 0) + 1
        user.dungeon.percent += 0.1;
        user.dungeon.clear += 1;
        user.tenaga -= 10;
        saveDB(db)

        if (user.dungeon.percent >= 1) {
          const rewardExp = 14 + Math.floor(Math.random() * 6);
          const rewardUang = 10000 + Math.floor(Math.random() * 15000);
          
          user.cooldown.dungeon = now
          user.dungeon.lantai = 1
          user.dungeon.percent = 0.1
          user.history.dungeon = (user.history.dungeon || 0) + 1
          user.uang += rewardUang
          user.dungeon.status = 'idle';
          saveDB(db)

          const teks4 = `乂  *D U N G E O N  T U A*
          
✅ Kamu berhasil menaklukkan lantai terakhir

Kamu mendapatkan uang *Rp ${rupiah(rewardUang)}* dan kamu keluar dari dungeon dengan sensng hati 

*+${rewardExp} Exp*
`;
  
        return await Exp.sendMessage(id, {
          text: teks4,
          contextInfo
        }, { quoted: cht })
      
        }
        
        const berlian = Math.floor(Math.random() * 5) + 5
        const emas = Math.floor(Math.random() * 5) + 6
        const potion = Math.floor(Math.random() * 5) + 1
        const naspad = Math.floor(Math.random() * 1) + 2
        
        user.inventory.berlian += berlian
        user.inventory.emas += emas
        user.inventory.potion += potion 
        user.makanan.naspad += naspad
        user.dungeon.lantai += 1;
        saveDB(db)
        
        const teks5 = `乂  *D U N G E O N  T U A*
        
✅ Kamu mengalahkan *${encounter}*
\`\`\`
ꕺ  Naik ke lantai : ${user.dungeon.lantai} 
ꕺ  Progres        : ${(user.dungeon.percent * 100).toFixed(0)}%

Loot:
◦ 🥤 Potion   : ${potion}
◦ 💎 Berlian  : ${berlian}
◦ 🪙 Emas     : ${emas}
◦ 🍙 Naspad   : ${naspad}
\`\`\`
Gunakan *.${cht.cmd} lanjut* untuk terus menjelajah lantai dungeon tua ini`;

        return await Exp.sendMessage(id, {
          text: teks5,
          contextInfo
        }, { quoted: cht })
        
      } else {
        const uangHilang = Math.floor(Math.random() * 55000) + 5000
        
        user.nyawa -= 10;
        user.tenaga -= 5;
        user.uang = Math.max(0, user.uang - uangHilang)

        
        if (user.nyawa <= 0) {
          
          const lantaiSebelumNya = user.dungeon.lantai
          
          user.dungeon.percent = 0.1
          user.cooldown.dungeon = now
          user.dungeon.status = 'idle';
          user.dungeon.lantai = 1;
          saveDB(db)
          
          const teks6 = `乂  *D U N G E O N  T U A*
          
☠️ Kamu dikalahkan oleh *${encounter}*...

Kamu gagal di lantai *ke-${lantaiSebelumNya}*.
Kamu pingsan dan diseret kembali ke desa...

Semua progres dungeon-mu hilang. Kamu harus mulai lagi dari lantai 1`;

          return await Exp.sendMessage(id, {
            text: teks6,
            contextInfo
          }, { quoted: cht })
      
        }

        const teks7 = `乂  *D U N G E O N  T U A*
        
☠️ Kamu gagal melawan *${encounter}*
\`\`\`
-10 Health
-5 Tenaga
-${uangHilang} Uang
\`\`\`
Gunakan potion atau mam sebelum melanjutkan\n`;

        return await Exp.sendMessage(id, {
          text: teks7,
          contextInfo
        }, { quoted: cht })
      
      }
      break;

    case 'out':
      if (!user.dungeon) return reply(`Kamu belum daftar dungeon.\nKetik \`.${cht.cmd} daftar\` dulu!`);
      if (user.dungeon.status === 'idle') return reply(`Kamu belum berada di dalam dungeon.`);
      
      user.dungeon.lantai = 1;
      user.dungeon.status = 'idle';
      saveDB(db)
      
      const teks8 = `乂  *D U N G E O N  T U A*
✅ Kamu naik ke daratan dengan selamat, dan keluar dari dungeon
`
      return await Exp.sendMessage(id, {
        text: teks8,
        contextInfo
      }, { quoted: cht })

      break;

    default:
      return
  }
})

ev.on({
  cmd: ['give'],
  listmenu: ['give'],
  tag: 'RPG',
  isGroup: true,
  isMention: "*❗ Tag orangnya*",
  args: "*❗ Ketik jenis, nama barang dan jumlahnya*\nContoh: .give barang potion 2"
}, async ({ args, cht }) => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);
  
  const mention = cht.mention[0];
  
  if (!db[mention]) return reply("❗ Target belum daftar RPG!");

  const [jenis, nama, jumlahRaw] = args.split(" ");
  if (!jenis || !nama || !jumlahRaw) return reply("❗ Format salah!\nContoh: .give barang potion 2");

  const jumlah = parseInt(jumlahRaw);
  if (isNaN(jumlah) || jumlah <= 0) return reply("❗ Jumlah harus berupa angka lebih dari 0");

  const target = db[mention];

  if (jenis === 'barang') {
    if (!(nama in user.inventory)) return reply(`❗ Kamu tidak punya barang bernama *${nama}*`);
    if (user.inventory[nama] < jumlah) return reply(`❗ Jumlah *${nama}* kamu tidak cukup!`);
    
    user.history.give = (user.history.give || 0) + 1
    user.inventory[nama] -= jumlah;
    target.inventory[nama] += jumlah;
    saveDB(db)

    await Exp.sendMessage(id, {
      text: `🎁 Berhasil memberi *${nama}* sebanyak *${jumlah}* ke @${mention.split('@')[0]}\n\nKamu sudah melakuakn give sebanyak:\n- ${user.history.give}x`,
      contextInfo: {
        ...contextInfo,
        mentionedJid: [mention]
      }
    }, { quoted: cht })
    
    await Exp.sendMessage(mention, {
      text: `🎁 ${sender.split("@")[0]} telah memberimu *${nama}* sebanyak *${jumlah}*\n\nBerterimakasih lah kepadanya`,
      contextInfo: {
        ...contextInfo,
        mentionedJid: [sender]
      }
    }, { quoted: cht })
    
  }

  else if (jenis === 'makanan') {
    if (!(nama in user.makanan)) return reply(`❗ Kamu tidak punya makanan bernama *${nama}*`);
    if (user.makanan[nama] < jumlah) return reply(`❗ Jumlah *${nama}* kamu tidak cukup!`);
    
    user.history.give = (user.history.give || 0) + 1
    user.makanan[nama] -= jumlah;
    target.makanan[nama] += jumlah;
    saveDB(db)

    await Exp.sendMessage(id, {
      text: `🎁 Berhasil memberi *${nama}* sebanyak *${jumlah}* ke @${mention.split('@')[0]}\n\nKamu sudah melakuakn give sebanyak:\n- ${user.history.give}x`,
      contextInfo: {
        ...contextInfo,
        mentionedJid: [mention]
      }
    }, { quoted: cht })
    
    await Exp.sendMessage(mention, {
      text: `🎁 ${sender.split("@")[0]} telah memberimu *${nama}* sebanyak *${jumlah}*\n\nBerterimakasih lah kepadanya`,
      contextInfo: {
        ...contextInfo,
        mentionedJid: [sender]
      }
    }, { quoted: cht })
    
  }

  else {
    await reply("❗ Jenis harus `barang` atau `makanan`");
  }
})

ev.on({
  cmd: ['sikaya', 'sisepuh', 'rajagacha', 'rajamancing', 'rajadungeon', 'rajaberburu'],
  listmenu: ['sikaya', 'sisepuh', 'rajagacha', 'rajamancing', 'rajadungeon', 'rajaberburu'],
  tag: 'RPG',
  isGroup: true
}, async () => {
  const user = db[userId];
  if (!user) return reply(peringatanDaftar);

if (cht.cmd === "sikaya") {
  const semuaUser = Object.entries(db)
    .map(([id, data]) => ({
      id,
      nama: data.nama,
      uang: data.uang
    }))
    .sort((a, b) => b.uang - a.uang)
    .slice(0, 5);

  let teks = `乂  *T O P  T E R K A Y A*\n\n`;

  semuaUser.forEach((u, i) => {
    const posisi = i + 1;
    const simbol = posisi === 1 ? '👑' : posisi === 2 ? '🥈' : posisi === 3 ? '🥉' : '';
    teks += `\`${u.nama} PERINGKAT KE-${posisi}\` ${simbol}\n> Dengan uang sebanyak *Rp ${rupiah(u.uang)}*\n\n`;
  })

  await Exp.sendMessage(id, {
    text: teks,
    contextInfo
  }, { quoted: cht })

} else if (cht.cmd === "sisepuh") {
  const semuaUser = Object.entries(db)
    .map(([id, data]) => {
      const stat = data.stat
      const totalStat = 
        stat.attack +
        stat.defense +
        stat.speed +
        stat.luck;
      return {
        id,
        nama: data.nama,
        totalStat
      };
    })
    .sort((a, b) => b.totalStat - a.totalStat)
    .slice(0, 5);

  let teks = `乂  *T O P  S E P U H*\n\n`;

  semuaUser.forEach((u, i) => {
    const posisi = i + 1;
    const simbol = posisi === 1 ? '👑' : posisi === 2 ? '🥈' : posisi === 3 ? '🥉' : '';
    teks += `\`${u.nama} PERINGAJT KE-${posisi}\` ${simbol}\n> Dengan total stat *${u.totalStat}*\n\n`;
  });

  await Exp.sendMessage(id, {
    text: teks,
    contextInfo
  }, { quoted: cht })

} else if (cht.cmd === "rajaberburu") {
    const semuaUser = Object.entries(db)
      .map(([id, data]) => ({
        id,
        nama: data.nama,
        berburu: data.history?.berburu || 0
      }))
      .sort((a, b) => b.berburu - a.berburu)
      .slice(0, 5);

    let teks = `乂  *R A J A  B E R B U R U*\n\n`;
    semuaUser.forEach((u, i) => {
      const posisi = i + 1;
      const simbol = posisi === 1 ? '👑' : posisi === 2 ? '🥈' : posisi === 3 ? '🥉' : '';
      teks += `\`${u.nama} PERINGKAT KE-${posisi}\` ${simbol}\n> Telah berburu sebanyak *${u.berburu}x*\n\n`;
    });

    await Exp.sendMessage(id, {
      text: teks,
      contextInfo
    }, { quoted: cht });

} else if (cht.cmd === "rajamancing") {
    const semuaUser = Object.entries(db)
      .map(([id, data]) => ({
        id,
        nama: data.nama,
        mancing: data.history?.mancing || 0
      }))
      .sort((a, b) => b.mancing - a.mancing)
      .slice(0, 5);

    let teks = `乂  *R A J A  M A N C I N G*\n\n`;
    semuaUser.forEach((u, i) => {
      const posisi = i + 1;
      const simbol = posisi === 1 ? '👑' : posisi === 2 ? '🥈' : posisi === 3 ? '🥉' : '';
      teks += `\`${u.nama} PERINGKAT KE-${posisi}\` ${simbol}\n> Sudah mancing sebanyak *${u.mancing}x*\n\n`;
    });

    await Exp.sendMessage(id, {
      text: teks,
      contextInfo
    }, { quoted: cht });
 
} else if (cht.cmd === "rajadungeon") {
    const semuaUser = Object.entries(db)
      .map(([id, data]) => ({
        id,
        nama: data.nama,
        dungeon: data.history?.dungeon || 0
      }))
      .sort((a, b) => b.dungeon - a.dungeon)
      .slice(0, 5);

    let teks = `乂  *R A J A  D U N G E O N*\n\n`;
    semuaUser.forEach((u, i) => {
      const posisi = i + 1;
      const simbol = posisi === 1 ? '👑' : posisi === 2 ? '🥈' : posisi === 3 ? '🥉' : '';
      teks += `\`${u.nama} PERINGKAT KE-${posisi}\` ${simbol}\n> Telah menjelajahi dungeon *${u.dungeon}x*\n\n`;
    });

    await Exp.sendMessage(id, {
      text: teks,
      contextInfo
    }, { quoted: cht });

} else {
    const semuaUser = Object.entries(db)
      .map(([id, data]) => ({
        id,
        nama: data.nama,
        gacha: data.history?.gacha || 0
      }))
      .sort((a, b) => b.gacha - a.gacha)
      .slice(0, 5);

    let teks = `乂  *R A J A  G A C H A*\n\n`;
    semuaUser.forEach((u, i) => {
      const posisi = i + 1;
      const simbol = posisi === 1 ? '👑' : posisi === 2 ? '🥈' : posisi === 3 ? '🥉' : '';
      teks += `\`${u.nama} PERINGKAT KE-${posisi}\` ${simbol}\n> Telah gacha sebanyak *${u.gacha}x*\n\n`;
    });

    await Exp.sendMessage(id, {
      text: teks,
      contextInfo
    }, { quoted: cht });
}
})

}