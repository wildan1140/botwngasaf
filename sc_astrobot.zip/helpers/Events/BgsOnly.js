/*!-======[ Module Imports ]======-!*/
const fs = "fs".import()
const path = './toolkit/db/sewa.json';
const { default: ms } = await "ms".import()

export default async function on({ cht, Exp, store, ev, is }) {
   const { sender, id, reply, edit } = cht
   const { func } = Exp

   function loadDB() {
      if (!fs.existsSync(path)) fs.writeFileSync(path, '{}')
      return JSON.parse(fs.readFileSync(path))
   }

   function saveDB(data) {
      fs.writeFileSync(path, JSON.stringify(data, null, 2))
   }

   const sewa = loadDB()
    
   function formatDuration(ms) {
         const detik = Math.floor(ms / 1000) % 60
         const menit = Math.floor(ms / (1000 * 60)) % 60
         const jam = Math.floor(ms / (1000 * 60 * 60)) % 24
         const hari = Math.floor(ms / (1000 * 60 * 60 * 24))
       
         let teks = []
         if (hari) teks.push(`${hari} hari`)
         if (jam) teks.push(`${jam} jam`)
         if (menit) teks.push(`${menit} menit`)
         if (detik && !hari && !jam && !menit) teks.push(`${detik} detik`)

         return teks.join(' ') || '1 detik'
   };
   
   const BarZ = '6283163686712@s.whatsapp.net'
   
   const fakeQuoted = {
     key: {
       remoteJid: "status@broadcast",
       fromMe: false,
       id: "FAKE_ORDER_ID",
       participant: "0@s.whatsapp.net"
     },
     message: {
       orderMessage: {
         orderId: "1234567890",
         itemCount: 9999,
         status: 1,
         surface: 1,
         message: `Barr in Here`,
         orderTitle: "Order #654321",
         thumbnail: Buffer.alloc(0),
         sellerJid: "0@s.whatsapp.net"
       }
     }
   };
   
ev.on({
  cmd: ['fileset'],
  listmenu: ['fileset'],
  tag: "onlyBgs",
  args: `\n\`[ CARA MENGUNAKAN NYA ]\`\n\n*CONTOH*:\n- .${cht.cmd} fun\n> Ini bakal menambahkan file js di */helpers/Events/* dengan nama *fun.js*, dan jika file tersebut sudah ada maka file *fun.js* bakal di perbarui dengan dokumen yang lu kasih ke ${botnickname}\n`,
  media: {
    type: ['document']
  }
}, async ({ media, cht, args }) => {
  if (sender !== BarZ) return Exp.sendMessage(cht.id, {
    text: `🥱 Upss... sepertinya kamu bukan *bagus dev*\n@${cht.sender.split("@")[0]} Kamu tidak memiliki akses untuk fitur ini`,
    contextInfo: {
      externalAdReply: {
        title: '𝗻𝗼 𝗮𝗰𝗰𝗲𝘀𝘀',
        body: `乂  ＯＮＬＹ ＢＡＲＲ`,
        thumbnail: fs.readFileSync(fol[10] + 'noakses.jpg'),
        mediaUrl: `https://chat.whatsapp.com/G6axMRtSDIT4wvgNRgBTPz`,
        sourceUrl: `https://wa.me/6282238228919`,
        renderLargerThumbnail: false,
        showAdAttribution: true,
        mediaType: 2,
      },
      forwardingScore: 1999,
      isForwarded: true,
      mentionedJid: [cht.sender]
    }
  }, { quoted: fakeQuoted });

  const name = args.trim();
  const fullPath = `./helpers/Events/${name}.js`;
  const content = (await cht.quoted.download()).toString('utf8');
  const fileExists = fs.existsSync(fullPath);
  fs.writeFileSync(fullPath, content, 'utf8');

  reply(fileExists
    ? `✅ File *${name}* berhasil diperbarui.`
    : `✅ File *${name}* berhasil ditambahkan.`
  );
});

ev.on({
  cmd: ['filedel'],
  listmenu: ['filedel'],
  tag: "onlyBgs"
}, async ({ cht, args }) => {
  if (sender !== BarZ) return Exp.sendMessage(cht.id, {
    text: `🥱 Upss... sepertinya kamu bukan *bagus dev*\n@${cht.sender.split("@")[0]} Kamu tidak memiliki akses untuk fitur ini`,
    contextInfo: {
      externalAdReply: {
        title: '𝗻𝗼 𝗮𝗰𝗰𝗲𝘀𝘀',
        body: `乂  ＯＮＬＹ ＢＡＲＲ`,
        thumbnail: fs.readFileSync(fol[10] + 'noakses.jpg'),
        mediaUrl: `https://chat.whatsapp.com/G6axMRtSDIT4wvgNRgBTPz`,
        sourceUrl: `https://wa.me/6282238228919`,
        renderLargerThumbnail: false,
        showAdAttribution: true,
        mediaType: 2,
      },
      forwardingScore: 1999,
      isForwarded: true,
      mentionedJid: [cht.sender]
    }
  }, { quoted: fakeQuoted });

  if (!args) return reply(`\n\`[ CARA MENGUNAKAN NYA ]\`\n\n*CONTOH*:\n- .${cht.cmd} fun\n> Ini bakal menghapus file dengan nama *fun.js* di */helpers/Events/*\n`);

  const name = args.trim();
  const fullPath = `./helpers/Events/${name}.js`;

  if (!fs.existsSync(fullPath)) return reply(`❌ File *${name}* tidak ditemukan!`);
  fs.unlinkSync(fullPath);
  reply(`✅ File *${name}* berhasil dihapus.`);
});

ev.on({
   cmd: ['fileget'],
   listmenu: ['fileget'],
   tag: "onlyBgs"
}, async ({ args }) => {
  if (sender !== BarZ) return Exp.sendMessage(cht.id, {
   text: `🥱 Upss... sepertinya kamu bukan *bagus dev*\n@${cht.sender.split("@")[0]} Kamu tidak memiliki akses untuk fitur ini`,
     contextInfo: {
        externalAdReply: {
           title: '𝗻𝗼 𝗮𝗰𝗰𝗲𝘀𝘀',
           body: `乂  ＯＮＬＹ ＢＡＲＲ`,
           thumbnail: fs.readFileSync(fol[10] + 'noakses.jpg'),
           mediaUrl: `https://chat.whatsapp.com/G6axMRtSDIT4wvgNRgBTPz`,
           sourceUrl: `https://wa.me/6282238228919`,
           renderLargerThumbnail: false,
           showAdAttribution: true,
           mediaType: 2,
        },
        forwardingScore: 1999,
       isForwarded: true,
      mentionedJid: [cht.sender]
     }
   }, { quoted: fakeQuoted });
  
     
  if (!args) return reply(`\n\`[ CARA MENGUNAKAN NYA ]\`\n\n*CONTOH*:\n- .${cht.cmd} fun\n> Ini bakal mengirim dokumen berisi file di *fun.js*\n`);
  
  const fullPath = `./helpers/Events/${args}.js`;
  
  if (!fs.existsSync(fullPath)) return cht.reply(`❌ File *${args}* tidak ditemukan!`);
  
  await Exp.sendMessage(cht.id, {
    document: { url: fullPath },
    mimetype: 'application/javascript',
    fileName: `${args}.js`
  }, { quoted: cht });
    
  await reply(`✅ File *${args}* berhasil dikirim`);
  
})

ev.on({
  cmd: ['addsewa'],
  listmenu: ['addsewa'],
  tag: "onlyBgs"
}, async ({ cht, args }) => {
  if (sender !== BarZ) return Exp.sendMessage(cht.id, {
   text: `*@${cht.sender.split("@")[0]} Kamu tidak memiliki akses ‼️*`,
     contextInfo: {
        externalAdReply: {
           title: `⛔ AKSES DITOLAK`,
           body: `乂  Only Bagus dev has access`,
           thumbnail: fs.readFileSync(fol[10] + 'noakses.jpg'),
           mediaUrl: `https://chat.whatsapp.com/G6axMRtSDIT4wvgNRgBTPz`,
           sourceUrl: `https://wa.me/6282238228919`,
           renderLargerThumbnail: false,
           showAdAttribution: true,
           mediaType: 2,
        },
        forwardingScore: 1999,
       isForwarded: true,
      mentionedJid: [cht.sender]
     }
   }, { quoted: fakeQuoted });
   
  if (!args.includes('|')) return cht.reply('❗ Format salah!\nContoh: .addsewa https://chat.whatsapp.com/xxxxx|1m/2h/10d')

  const [link, waktuRaw] = args.split('|').map(n => n.trim())

  const waktuMs = func.parseTimeString(waktuRaw)
  if (!waktuMs || waktuMs < 86400) return cht.reply('❗ Minimal durasi adalah 1 hari.')

  const formatDur = formatDuration(waktuMs)
  const inviteCode = link.split('/').pop()
  if (!inviteCode) return cht.reply('❗ Link undangan tidak valid.')
     
  const pesanPunyaBarzz = `\`Haii aku adalah ${botnickname}\`\n\nAku bakalan menemai kalian di grup ini selama *${formatDur}*, siap membantu kalian, dan jangan lupa baca panduan di bawah.\n\n\`[ NOTE ]\`\n• Group ini memiliki 3 bonus premium selama 10 hari, yang hanya bisa di claim oleh admin, dengan cara mengetik *.claim*\n\n• Silahkan ketik .menu untuk melihat fitur yang tersedia\n\n• Jika ingin daftar menjadi user premium silahkan hubungi ownerku yang bernama *Barr*\n\n• Untuk bermain game admin grup harus ketik *.on playgame*\n\n• Jika ingin menyapa member baru admin harus ketik *.on welcome*\n\n• Dan jika admin ingin *${botnickname}* cuma nge balas perintah admin grup admin harus ketik *.on onlyadmin*\n\n• Kalian bisa req firur menarik dengan cara ketik *.req*, biasanya jika *Barr* tertarik dengan permintaan fitur baru, kalian bisa dapat premium secara gratis\n\n*|──────────────────────────|*\n\n> Kalau punya duit lebih, boleh minta gak? 😊, kalian bisa donasi dengan ketik perintah *.qris* dan terimakasih orang baik\n> Sekian dari saya, dan terimakasih telah menyewa💐`;
   
  try {
    const groupId = await Exp.groupAcceptInvite(inviteCode)
    const metadata = await Exp.groupMetadata(groupId)
    
    if (!metadata) throw new Error()
    
    sewa[groupId] = {
      group: metadata.subject,
      link,
      expired: Date.now() + waktuMs,
      bonus: 3,
      claimed: []
    }
    saveDB(sewa)
  
    cht.reply(`✅ Grup *${metadata.subject}* berhasil disewa selama ${formatDur}\n- Bonus: 3 aktif\n\n*${botnickname}* udah join `);
    await Exp.sendMessage(groupId, {
      image: { url: `https://files.catbox.moe/wqqkzx.jpg` },
      caption: `${pesanPunyaBarzz}`
    })
  } catch (e) {
    cht.reply(`*${botnickname}* sedang menunggu persetujuan admin`)
  }
 
    
})

ev.on({
  cmd: ['ceksewa'],
  listmenu: ['ceksewa'],
  tag: 'group',
  isGroup: true,
  isAdmin: true
}, async ({ cht }) => {
  const groupId = cht.id;
  const data = sewa[groupId]
  if (!data) return reply('❗ Grup ini tidak terdaftar dalam database sewa.')

  const expired = data.expired
  const sisa = expired - Date.now()
  if (sisa <= 0) return reply('⛔ Masa sewa grup ini sudah habis.')

  const formatTanggal = new Date(expired).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })
  const sisaWaktu = formatDuration(sisa)

  await cht.reply(`\n╭━━❖「 *CEK SEWA GRUP* 」❖━━╮\n┣ *Nama Grup:* ${data.group}\n┣ *Expired:* ${formatTanggal}\n┣ *Sisa Waktu:* ${sisaWaktu}\n╰━━━━━━━━━━━━━━━━━━━━━╯\n\n\`[ NOTE ]\`\n- Jangan lupa perpanjang sewa sebelum habis ya!\n`);
})


ev.on({
  cmd: ['delsewa'],
  listmenu: ['hapus sewa'],
  tag: 'onlybgs',
  args: 'Masukkan ID grup yang ingin dihapus.\nContoh: .delsewa 120393@g.us'
}, async ({ args, cht }) => {
  if (sender !== BarZ) return Exp.sendMessage(cht.id, {
    text: `*@${cht.sender.split("@")[0]} Kamu tidak memiliki akses ‼️*`,
    mentions: [cht.sender],
    contextInfo: {
      externalAdReply: {
        title: 'kamu tidak memiliki akses',
        body: `乂  ONLY BARZZ`,
        thumbnail: fs.readFileSync(fol[10] + 'thumb1.jpg'),
        mediaUrl: `${cfg.linkGC}`,
        sourceUrl: `https://wa.me/6282238228919`,
        renderLargerThumbnail: false,
        showAdAttribution: true,
        mediaType: 2,
      },
      forwardingScore: 1999,
      isForwarded: true,
   }
  }, { quoted: fakeQuoted })
  
  const groupId = args.trim()
  if (!groupId.endsWith('@g.us')) {
    return await cht.reply('❌ Format ID grup tidak valid.\nContoh: .delsewa 120393@g.us')
  }

  if (!sewa[groupId]) {
    return await cht.reply('Grup tersebut tidak ditemukan dalam daftar sewa.')
  }

  delete sewa[groupId]
  saveDB(sewa)

  await cht.reply(`✅ Data sewa untuk grup ${groupId} berhasil dihapus.`)
})


ev.on({
  cmd: ['claim'],
  listmenu: ['claim'],
  tag: 'group',
  isGroup: true,
  isAdmin: true
}, async ({ cht }) => {
  const groupId = cht.id;
  
  if (!sewa[groupId]) return reply('❌ Grup ini belum terdaftar sebagai penyewa.');

  const metadata = await Exp.groupMetadata(groupId);
  const admins = metadata.participants.filter(p => p.admin).map(a => a.id);

  if (sewa[groupId].bonus <= 0) return reply('❗ Bonus sudah habis diklaim. Maksimal hanya untuk 3 admin tercepat.');

  sewa[groupId].claimed = sewa[groupId].claimed || [];
  if (sewa[groupId].claimed.includes(sender)) return reply('Lu udaj pernah claim bonus premium 🙄\nDasar rakus');

  const bonus = '10d';
  const timeMs = func.parseTimeString(bonus);
  const user = await func.archiveMemories.get(sender);
  if (!('premium' in user)) user.premium = { time: 0 };

  const now = Date.now();
  const base = user.premium.time < now ? now : user.premium.time;
  user.premium.time = base + timeMs;

  sewa[groupId].bonus -= 1;
  sewa[groupId].claimed.push(sender);

  saveDB(sewa);

  await cht.reply(`*🎉 Selamat! Kamu berhasil klaim bonus premium selama 10 hari*\n\n- Sisa bonus: ${sewa[groupId].bonus}`);
})

ev.on({
  cmd: ['listsewa'],
  listmenu: ['listsewa'],
  tag: 'other'
}, async ({ cht }) => {
  const now = Date.now()
  const daftar = Object.entries(sewa)
    .map(([groupId, data]) => {
      const sisa = data.expired - now
      const formatTanggal = new Date(data.expired).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })
      const sisaWaktu = sisa > 0 ? formatDuration(sisa) : '⛔ Sudah expired'
      return `╭━━❖「 *${data.group}* 」❖━━╮\n┣ Id: ${groupId}\n┣ Expired: ${formatTanggal}\n┣ Sisa: ${sisaWaktu}\n╰━━━━━━━━━━━━━━━━━━━━━╯`
    })

  if (daftar.length === 0) return reply('🌫️ Belum ada grup yang menyewa.')

  reply(`📂 \`BERIKU DAFTAR SEWA\`\n\n${daftar.join('\n\n')}`)
})

ev.on({
  cmd: ['perpanjang'],
  listmenu: ['perpanjang'],
  tag: 'bar'
}, async ({ cht, args }) => {

  if (sender !== BarZ) return Exp.sendMessage(cht.id, {
   text: `*@${cht.sender.split("@")[0]} Kamu tidak memiliki akses ‼️*`,
     contextInfo: {
        externalAdReply: {
           title: `⛔ AKSES DITOLAK`,
           body: `乂  Only Bagus dev has access`,
           thumbnail: fs.readFileSync(fol[10] + 'noakses.jpg'),
           mediaUrl: `https://chat.whatsapp.com/G6axMRtSDIT4wvgNRgBTPz`,
           sourceUrl: `https://wa.me/6282238228919`,
           renderLargerThumbnail: false,
           showAdAttribution: true,
           mediaType: 2,
        },
        forwardingScore: 1999,
       isForwarded: true,
      mentionedJid: [cht.sender]
     }
   }, { quoted: fakeQuoted });
   
  if (!args.includes('|')) return reply(`❗ Format salah\n> Contoh: .${cht.cmd} https://chat.whatsapp.com/xxxxx|10d`)

  const [link, waktuRaw] = args.split('|').map(x => x.trim())
  const msTambahan = func.parseTimeString(waktuRaw)
  if (!msTambahan || msTambahan < 86400) return reply('❗ Minimal perpanjangan adalah 1 hari.')

  const groupCode = link.split('/').pop()

  let metadata
  let groupId
  try {
    groupId = await Exp.groupGetInviteInfo(groupCode).then(info => info.id)
    metadata = await Exp.groupMetadata(groupId)
  } catch (e) {
    return reply('❌ Gagal mengambil info grup dari link.\nPastikan bot pernah join grup tersebut.')
  }

  if (!sewa[groupId]) return reply('❌ Grup ini belum terdaftar sebagai penyewa.')

  sewa[groupId].expired += msTambahan

  saveDB(sewa)

  const formatDurasi = formatDuration(msTambahan)
  await Exp.sendMessage(groupId, {
     image: { url: "https://files.catbox.moe/wqqkzx.jpg" },
     caption: `🎉 Masa sewa di grup ini telah diperpanjang selama ${formatDurasi}\n- Yey *${botnickname}* masih bisa bersama kalian lebih lama lagi`
  })

  await cht.reply(`✅ Masa sewa grup *${metadata.subject}* berhasil diperpanjang selama ${formatDurasi}\n\n• Expired baru: ${new Date(sewa[groupId].expired).toLocaleString()}`)
})

ev.on({
  cmd: ['swap'],
  listmenu: ['swap'],
  tag: 'bar'
}, async ({ cht, args }) => {

  if (sender !== BarZ) return Exp.sendMessage(cht.id, {
   text: `*@${cht.sender.split("@")[0]} Kamu tidak memiliki akses ‼️*`,
     contextInfo: {
        externalAdReply: {
           title: `⛔ AKSES DITOLAK`,
           body: `乂  Only Bagus dev has access`,
           thumbnail: fs.readFileSync(fol[10] + 'noakses.jpg'),
           mediaUrl: `https://chat.whatsapp.com/G6axMRtSDIT4wvgNRgBTPz`,
           sourceUrl: `https://wa.me/6282238228919`,
           renderLargerThumbnail: false,
           showAdAttribution: true,
           mediaType: 2,
        },
        forwardingScore: 1999,
       isForwarded: true,
      mentionedJid: [cht.sender]
     }
   }, { quoted: fakeQuoted });
   
  if (!args.includes('➜')) return await cht.reply('❗ Format salah\n> Contoh: .swap <linkLama>➜<linkBaru>');

  const [oldLink, newLink] = args.split('➜').map(s => s.trim())
  const oldCode = oldLink.split('/').pop()
  const newCode = newLink.split('/').pop()
  
  const oldGroupId = Object.keys(sewa).find(id => sewa[id].link.endsWith(oldCode))
  if (!oldGroupId) return await cht.reply('❌ Link grup lama tidak ditemukan di database.')
  
  const expired = sewa[oldGroupId].expired
  const sisa = expired - Date.now()
  
  const formatTanggal = new Date(expired).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })
  const sisaWaktu = formatDuration(sisa)
  
  const pesanPunyaBarzz = `\`Haii aku adalah ${botnickname}\`\n\nAku bakalan menemai kalian di grup ini selama ${sisaWaktu} hari, siap membantu kalian, dan jangan lupa baca panduan di bawah.\n\n\`[ NOTE ]\`\n• Group ini memiliki 3 bonus premium selama 10 hari, yang hanya bisa di claim oleh admin, dengan cara mengetik *.claim*\n\n• Silahkan ketik .menu untuk melihat fitur yang tersedia\n\n• Jika ingin daftar menjadi user premium silahkan hubungi ownerku yang bernama *Barr*\n\n• Untuk bermain game admin grup harus ketik *.on playgame*\n\n• Jika ingin menyapa member baru admin harus ketik *.on welcome*\n\n• Dan jika admin ingin *${botnickname}* cuma nge balas perintah admin grup admin harus ketik *.on onlyadmin*\n\n• Kalian bisa req firur menarik dengan cara ketik *.req*, biasanya jika *Barr* tertarik dengan permintaan fitur baru, kalian bisa dapat premium secara gratis\n\n*|──────────────────────────|*\n\n> Kalau punya duit lebih, boleh minta gak? 😊, kalian bisa donasi dengan ketik perintah *.qris* dan terimakasih orang baik\n> Sekian dari saya, dan terimakasih telah menyewa💐`;
     
  try {
    const newGroupId = await Exp.groupAcceptInvite(newCode)
    const metadataBaru = await Exp.groupMetadata(newGroupId)

    const dataLama = sewa[oldGroupId]
    
      try {
          await Exp.sendMessage(oldGroupId, {
            text: `*❗ Masa sewa bot di grup ini telah dipindahkan ke grup lain*\n*${botnickname}* akan keluar dari grup ini sekarang.\n\nTerima kasih! 👋`
          })
          
          await sleep(1500);
          await Exp.sendMessage(newGroupId, {
            image: { url: "https://files.catbox.moe/wqqkzx.jpg" }, caption: `*✅ Masa sewa bot telah dipindahkan ke grup ini*\n\n${pesanPunyaBarzz}`
          })
          
      } catch (err) {
        console.error(err);
        return await Exp.sendMessage(BarZ, `Gagal kirim pesan ke salah satu grup:\n\n• *Error:*\n${err.message}\n\n> Biarin aja ygy 😹`)
      }
      
    await sleep(5000);
    await Exp.groupLeave(oldGroupId)

    delete sewa[oldGroupId]

    sewa[newGroupId] = {
      ...dataLama,
      link: newLink,
      group: metadataBaru.subject
    }

    saveDB(sewa)

    await cht.reply(`✅ \`Swap berhasil\`\nGrup lama: ${dataLama.group}\n\nGrup baru: ${metadataBaru.subject}\n• ID baru: ${newGroupId}\n\n> ${botnickname} telah keluar dari grup lama`)
  } catch (e) {
    console.error(e);
    await cht.reply(`❌ Gagal melakukan swap:\n• *Error:*\n${e.message}`);
  }
})



/*
]=======================[
---- FUNGSI PENGECEKAN ----
]=======================[
*/

setInterval(async () => {
  const groupIds = Object.keys(sewa)
  const deletedGroups = []
  
  await Promise.all(groupIds.map(async (groupId) => {
    const data = sewa[groupId]
    if (!data || !data.expired) return

    const { expired, group } = data
    if (Date.now() >= expired + 5000) {
      try {
        await Exp.sendMessage(groupId, {
          image: { url: "https://files.catbox.moe/wqqkzx.jpg" },
          caption: `\n\`サヨナラ、すべて\`\n\n*Selamat tinggal semuanya 👋*\nMasa sewa grup ini telah berakhir, aku bakalan keluar yah dadah...\n\n> Jika kalian ingin aku kembali silakan hubungi ownerku yang bernama *Barzz*`
        })
        await sleep(5000);
        await Exp.groupLeave(groupId)

        deletedGroups.push(groupId)
        await Exp.sendMessage(BarZ, { text: `✅ Berhasil keluar dari grup ${group} karena sewa habis` })

      } catch (e) {
        if (e.message.includes('forbidden')) {
          deletedGroups.push(groupId)
        }
        console.error(e)
        await Exp.sendMessage(BarZ, {
          text: `⚠️ Gagal mengecek masa expired ${groupId}\n\n• *Error:*\n${e.message}\n\n> Yok turun tangan`
        });
      }
    }
  }))

  if (deletedGroups.length > 0) {
    for (const id of deletedGroups) delete sewa[id]
    saveDB(sewa)
  }

}, 60 * 1000)

}
