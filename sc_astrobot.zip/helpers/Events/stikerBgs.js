/*!-======[ Module Imports ]======-!*/
const fs = "fs".import()

/*!-======[ Function Imports ]======-!*/
const { writeExifImg } = await (fol[0] + 'exif.js').r();
const {
  getStickerSetByName,
  searchStickerSet,
  moreFromLink,
  lookupInput,
  requestSticker
} = await (fol[2] + 'fstiker.js').r();

/*!-======[ Default Export Function ]======-!*/
export default async function on({ cht, Exp, store, ev, is }) {
    let { sender, id, reply } = cht
    let { func } = Exp 
    let infos = Data.infos
    
   const bar = cfg.bar;
   
ev.on({
  cmd: ['cstick'],
  listmenu: ['cstick ℗'],
  tag: "search",
  premium: true,
  args: "*❓ Mau cari stiker apa*",
  energy: 10
}, async ({ args, cht }) => {
  try {
    const query = encodeURIComponent(args);
    const res = await fetch(`https://api.botcahx.eu.org/api/search/sticker?text1=${query}&apikey=${bar}`);
    const json = await res.json();

    if (!json.status || !json.result?.sticker_url?.length) {
      return cht.reply("❌ Stiker nggak ditemukan...");
    }

    const stik = json.result.sticker_url;
    const acak = stik.sort(() => 0.5 - Math.random()).slice(0, 5);

    for (const url of acak) {
      const buffer = await func.getBuffer(url);
      const hasil = await writeExifImg(buffer, {
        packname: `${cht.cmd}`,
        author: 'Ⓒ astrobot md'
      });

      await Exp.sendMessage(cht.id, {
        sticker: { url: hasil }
      }, {
        quoted: cht
      });

      await new Promise(r => setTimeout(r, 1500));
    }

  } catch (e) {
    console.error(e);
    cht.reply("⚠️ Gagal cari stiker, coba lagi nanti bro.");
  }
})

ev.on({
  cmd: ['fstik'],
  listmenu: ['fstik ℗'],
  tag: 'search',
  premium: true,
  energy: 25,
  args: `Masukkan namanya atau link sticker Telegram\n\nContoh:\n.fstik doraemon\n.fstik https://t.me/addstickers/memekocak`
}, async ({ args, cht }) => {
  try {
    const query = args.trim();

    const isLink = query.startsWith('https://t.me/addstickers/')
    const result = isLink
      ? await moreFromLink(query)
      : await lookupInput(query)

    if (!result.success) return cht.reply(result.result.error || 'Gagal ambil data stiker')

    const sendInfo = async (set) => {
      const caption = `*INFO STICKER SET*\n\n` +
        `- *Nama:* ${set.title}` +
        `\n- *id:* ${set.id}` +
        `\n- *Set:* ${set.name}` +
        `\n- *Deskripsi:* ${set.description || '—'}` +
        `\n- *Tags:* ${set.tags?.join(', ') || '—'}` +
        `\n- *Jenis:* ${set.kind}` +
        `\n- *Tipe:* ${set.type}` +
        `\n- *Publik:* ${set.public ? 'Ya' : 'Tidak'}` +
        `\n- *Aman:* ${set.safe ? 'Ya' : 'Tidak'}` +
        `\n- *Verified:* ${set.verified ? 'Ya' : 'Tidak'}` +
        `\n- *Jumlah:* ${set.stickerCount}` +
        `\n\n📎 https://t.me/addstickers/${set.name}`

      const preview = set.stickers?.[0]?.image_url
      if (preview) {
        await Exp.sendMessage(cht.id, {
          image: { url: preview },
          caption
        }, { quoted: cht })
      } else {
        await cht.reply(caption)
      }

      await sleep(2000)

      const max = 10
      const limitedStickers = set.stickers?.slice(0, max) || []

      for (const s of limitedStickers) {
        if (!s.image_url) continue
        try {
          const media = await func.getBuffer(s.image_url)
          const hasil = await writeExifImg(media, {
            packname: `ASTROBOT MD by bagus dev
`,
            author: '© astrobot md'
          })
          await Exp.sendMessage(cht.id, {
            sticker: { url: hasil },
          }, { quoted: cht })
          await sleep(1000)
        } catch (e) {
          console.error(`❌ Gagal kirim stiker ke ${cht.id}:`, e.message)
        }
      }
      
      if (set.stickerCount > max) {
        await cht.reply(`Sticker ini punya \`${set.stickerCount} stiker\` dam hanya \`${max} stiker\` pertama yang dikirim.`)
      }
    }

    const sets = result.result
    if (Array.isArray(sets)) {
      await sendInfo(sets[0])
    } else {
      await sendInfo(sets)
    }

  } catch (e) {
    console.error(e)
    cht.reply(`Gagal mencari stiker\n\n*Error:*\n${e.message}\n\n> segera lapor ke owner`)
  }
})
}