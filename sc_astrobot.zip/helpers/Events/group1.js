/*!-======[ Module Imports ]======-!*/
const fs = "fs".import()
const path = './toolkit/db/setwelcome.json';
const { default: ms } = await "ms".import()

/*!-======[ Default Export Function ]======-!*/
export default async function on({ cht, Exp, store, ev, is }) {
    const { id, sender } = cht
    const { func } = Exp
    let { archiveMemories:memories, parseTimeString, clearSessionConfess, findSenderCodeConfess, formatDuration } = func
    const infos = Data.infos 
    let time = "3 hari"
    
    function loadDB() {
      if (!fs.existsSync(path)) fs.writeFileSync(path, '{}');
      return JSON.parse(fs.readFileSync(path));
    }

    function saveDB(data) {
      fs.writeFileSync(path, JSON.stringify(data, null, 2));
    }
    
    const db = loadDB();

    const group = await Exp.groupMetadata(cht.id) //untuk list admin
    
    const energy = async (en)=> {
       memories.reduceEnergy(sender, en);
       await cht.reply(`-${en} Energy⚡`)
       if (cht.memories.energy < en) {
         await cht.reply(infos.messages.isEnergy({ uEnergy: cht.memories.energy, energy:en, charging:cht.memories.charging }))
         return false
       }
       return true 
    }

            
  const fakeQuoted = {
    key: {
      remoteJid: "status@broadcast",
      fromMe: false,
      id: "FAKE_ORDER_ID",
      participant: "0@s.whatsapp.net"
    },
    message: {
      orderMessage: {
        orderId: "1234567890",
        itemCount: 9999,
        status: 1,
        surface: 1,
        message: `ASTROBOT MD`,
        orderTitle: "Order #654321",
        thumbnail: Buffer.alloc(0),
        sellerJid: "0@s.whatsapp.net"
      }
    }
  };


ev.on({
  cmd: ['setwelcome', 'setbye'],
  listmenu: ['setwelcome'],
  tag: "group",
  isGroup: true,
  isAdmin: true,
  args: `Contoh:\n\n- .setwelcome Selamat datang @user di grup!\n- .setbye Sampai jumpa @user 👋`
}, async ({ cht, args }) => {
  
  if (!db[cht.id]) db[cht.id] = { welcome: [], bye: [] };

  if (cht.cmd === "setwelcome") {
    db[cht.id].welcome = [args];
    saveDB(db);
    cht.reply('✅ Pesan welcome berhasil disimpan!');
  } else {
    db[cht.id].bye = [args];
    saveDB(db);
    cht.reply('✅ Pesan leave berhasil disimpan!');
  }
});

ev.on({
 cmd: ['myenergy'],
 listmenu: ['myenergy'],
 tag: "group",
 isGroup: true
}, async () => {
  const user = await memories.get(sender)
  
  const txt = "*乂   E N E R G Y ➜* " + user.energy;
   
  const respon = {
    text: txt,
    contextInfo: {
      externalAdReply: {
        title: cht.pushName,
        body: `ＹＯＵＲ ＥＮＥＲＧＹ ⚡`,
        thumbnail: fs.readFileSync(fol[10] + 'energy.jpg'),
        mediaUrl: `https://chat.whatsapp.com/G6axMRtSDIT4wvgNRgBTPz`,
        sourceUrl: "https://www.tiktok.com/@bagus.ganz",
        renderLargerThumbnail: false,
        showAdAttribution: true,
        mediaType: 2,
      },
      forwardingScore: 1999,
      isForwarded: true,
    }
 }

 Exp.sendMessage(cht.id, respon, { quoted: cht });
})

ev.on({
 cmd: ['listadmin'],
 listmenu: ['listadmin'],
 tag: "group",
 isAdmin: true,
 isGroup: true
}, async () => {
const groupMetadata = await Exp.groupMetadata(cht.id)
 const admins = groupMetadata.participants.filter(p => p.admin)
 const mentions = admins.map(p => p.id)
 const listAdmin = admins.map((p, i) => `${i + 1}. @${p.id.split('@')[0]}`).join('\n')

 await Exp.sendMessage(cht.id, {
 text: `🔰 \`LIST ADMIN DI GRUP ${group.subject}\`\n─────────────────\n\n${listAdmin}`,
 mentions
 }, { quoted: fakeQuoted });
})

}