/*!-======[ Module Imports ]======-!*/
const fs = "fs".import()
const { catbox } = await (fol[0] + 'catbox.js').r()
const { fakeNgl } = await (fol[2] + 'makerMach.js').r()

/*!-======[ Default Export Function ]======-!*/
export default async function on({ cht, Exp, store, ev, is }) {
  const { id } = cht;
  const { func } = Exp;

ev.on({
  cmd: ['cpp', 'cprofile', 'buatprofile'],
  listmenu: ['cprofile ℗'],
  tag: "maker",
  energy: 25,
  premium: true,
  args: `*❗ Berikan dua link image*
  
Contoh:
> .${cht.cmd} <url foto panjang> <url foto 1:1> <overlay> <name>

> .${cht.cmd} https://files.catbox.moe/a4cy6s.jpg https://files.catbox.moe/rh49zx.jpg ${botnickname}`
}, async ({ cht, args }) => {
  try {
    const [
      url1, 
      url2, 
      restName,
      overlay
    ] = args.split(' ').map(v => v.trim());

    if (!url1 || !url2) {
      return cht.reply(`❌ Format salah!\n\n${cht.cmd} <url1> <url2> <name?>`);
    }

    let ovrly = 'dark';
    if (overlay && ['ice', 'dark'].includes(overlay.toLowerCase())) {
      ovrly = overlay.toLowerCase();
    }

    const hasil = await profileKece(url1, url2, restName, ovrly);

    await Exp.sendMessage(cht.id, {
      image: hasil,
      caption: `✅ Berhasil membuat profile anda`
    }, { quoted: cht });

  } catch (e) {
    return cht.reply("Gagal membuat profile kamu\n\n*Error*:\n" + e);
  }
})

ev.on({
 cmd: ['balogo'],
 listmenu: ['balogo'],
 tag: "maker",
 energy: 25
}, async ({ args }) => {

if (!args || !args.includes('|')) return Exp.sendMessage(cht.id, { text: 'Contoh penggunaan: .balogo text1|text2' }, { quoted: cht });

  let [text1, text2] = args.split('|').map(a => a.trim());
  if (!text1 || !text2) return Exp.sendMessage(cht.id, { text: 'Kedua teks tidak boleh kosong!\nContoh: .balogo Barr|Sensei' }, { quoted: cht });

 await Exp.sendMessage(cht.id, { image: { url: `https://api.nekorinn.my.id/maker/ba-logo?textL=${encodeURIComponent(text1)}&+&textR=${encodeURIComponent(text2)}`
}
}, { quoted: cht });
})

ev.on({
 cmd: ['fakexnxx'],
 listmenu: ['fakexnxx'],
 tag: "maker",
 energy: 25
}, async ({ args, cht }) => {
  const query = Array.isArray(args) ? args.join(' ') : String(args || '');
  
  if (!query.includes('|')) {
    return cht.reply('❌ Format salah\n> Contoh: `.fake Barzz|hy sayang|1k`');
  }

  const [name, quote, likes] = query.split('|');
  if (!name || !quote || !likes) {
    return cht.reply('❌ Format tidak lengkap\n> Format: `nama|quote|likes`\nContoh: `.fake Bagus|hy sayang|10k`');
  }

  try {
    await Exp.sendMessage(cht.id, {
      image: {
        url: `https://api.siputzx.my.id/api/m/fake-xnxx?name=${encodeURIComponent(name)}&quote=${encodeURIComponent(quote)}&likes=${encodeURIComponent(likes)}`
      }
    }, { quoted: cht });
  } catch (e) {
    cht.reply('❌ Gagal mengambil gambar. Coba lagi nanti.');
  }
})

ev.on({
  cmd: ['cktp','ktp'],
  listmenu: ['cktp'],
  tag: "maker",
  energy: 30,
}, async ({ cht, args }) => {
  const EXAMPLE = `.cktp provinsi | kota | nik | nama | ttl | jenis_kelamin | golongan_darah | alamat | rt/rw | kel/desa | kecamatan | agama | status | pekerjaan | kewarganegaraan | masa_berlaku | terbuat | pas_photo`

  if (!args) {
    return cht.reply(`*Contoh:* ${EXAMPLE}\n\n*Misalnya:* .cktp Jawa Barat | Cikarang | 1234567890123456 | Erickson | New York, 03-03-1990 | Laki-laki | O | Jl. Perjuangan No. 110 | 001/002 | Tangerang | Cikarang Barat | Islam | Belum Kawin | Konten Kreator | WNI | Seumur Hidup | 04-06-2006 | https://files.image/example.jpg`)
  }

  const parts = args.split('|').map(part => part.trim())
  if (parts.length < 18) {
    return cht.reply(`*Contoh:* ${EXAMPLE}\n\n*Misalnya:* .cktp Jawa Barat | Cikarang | 1234567890123456 | Erickson | New York, 03-03-1990 | Laki-laki | O | Jl. Perjuangan No. 110 | 001/002 | Tangerang | Cikarang Barat | Islam | Belum Kawin | Konten Kreator | WNI | Seumur Hidup | 04-06-2006 | https://files.image/example.jpg`)
  }
  

  const [
    provinsi, kota, nik, nama, ttl,
    jenis_kelamin, golongan_darah, alamat, rtrw, keldesa,
    kecamatan, agama, status, pekerjaan, kewarganegaraan,
    masa_berlaku, terbuat, pas_photo
  ] = parts

  const PARAMS = new URLSearchParams({
    provinsi, kota, nik, nama, ttl,
    jenis_kelamin, golongan_darah, alamat,
    'rt/rw': rtrw, 'kel/desa': keldesa,
    kecamatan, agama, status, pekerjaan,
    kewarganegaraan, masa_berlaku, terbuat, pas_photo
  })

  try {
    await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } })

    await Exp.sendMessage(cht.id, {
      image: { url: `https://api.siputzx.my.id/api/m/ektp?${PARAMS.toString()}` },
      caption: ''
    }, { quoted: cht })
  } catch (err) {
    console.error('Terjadi kesalahan:', err)
    cht.reply('Terjadi kesalahan saat membuat eKTP.')
  }
})

ev.on({
  cmd: ['iqc1'],
  listmenu: ['iqc1'],
  tag: "maker",
  energy: 25,
  args: "Mana teksnya? Contoh: .iqc Halo|left"
}, async ({ args, cht }) => {
  const waktuJakarta = new Date().toLocaleTimeString("id-ID", {
    timeZone: "Asia/Jakarta",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false
  });

  let [teks, posisi] = args.split("|").map(v => v?.trim());


  if (!teks) return cht.reply("⚠️ Teks-nya mana? Contoh: .iqc Halo|left");
  if (!posisi || !["left", "right"].includes(posisi.toLowerCase())) posisi = "left";

  if (teks.length > 100 ) {
  return cht.reply("⚠️ Maksimal 100 karakter ya!");
  }

  const apih = `https://velyn.mom/api/maker/iqc?message=${encodeURIComponent(teks)}&position=${posisi}&jam=${encodeURIComponent(waktuJakarta)}`;

try {

  await Exp.sendMessage(cht.id, {
    image: { url: apih },
    caption: "✅ Nih Kaka"
  }, { quoted: cht });
} catch (e) {
  console.error(e);
  return cht.reply(`Gagal membuat iqc\n\n• *Error*:\n${e.message}\n\n> Segera lapor ke owner`);
}
});

ev.on({
  cmd: ['phlogo'],
  listmenu: ['phlogo'],
  tag: "maker",
  enrgy: 55
}, async ({ args, cht }) => {
  if (!args || !args.includes('|')) return Exp.sendMessage(cht.id, { text: 'Contoh penggunaan: .ph text1|text2' }, { quoted: cht });

  let [text1, text2] = args.split('|').map(a => a.trim());
  if (!text1 || !text2) return Exp.sendMessage(cht.id, { text: 'Kedua teks tidak boleh kosong!\nContoh: .ph Barr|hub' }, { quoted: cht });

  const apiUrl = `https://apikey.sazxofficial.web.id/api/imagecreator/pornhub?text1=${encodeURIComponent(text1)}&text2=${encodeURIComponent(text2)}`;
  try {
    const res = await fetch(apiUrl);
    const json = await res.json();

    if (!json.status) return Exp.sendMessage(cht.id, { text: 'Gagal mengambil gambar dari API.' }, { quoted: cht });

    await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });

    await Exp.sendMessage(cht.id, {
      image: { url: json.result },
      caption: `✅ \`BERHASIL...\``,
      contextInfo: {
        externalAdReply: {
          title: "Elaina",
          body: "© Elaina MD V1.0",
          thumbnail: fs.readFileSync(fol[3] + "pict2.jpg"),
          mediaType: 1,
          renderLargerThumbnail: false,
          sourceUrl: json.result
        }
      }
    }, { quoted: cht });

  } catch (err) {
    Exp.sendMessage(cht.id, { text: 'Terjadi kesalahan saat memproses permintaan.' }, { quoted: cht });
  }
})

ev.on({
  cmd: ['sdmtinggi', 'ppsdmtinggi'],
  listmenu: ['sdmtinggi'],
  tag: "maker",
  energy: 25,
  media: { type: ['image'] }
}, async ({ media, cht }) => {
  let ah = await catbox(media);

  try {
    await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
    const hasil = `https://zenzxz.dpdns.org/maker/tosdmtinggi?url=${encodeURIComponent(ah)}`

    await Exp.sendMessage(cht.id, { image: { url: hasil }, caption: "Selamat anda telah menjadi orang dengan SDM tinggi 😳🥶🥶🥶🤓" }, { quoted: cht })

  } catch (e) {
     console.error(e);
     return cht.reply(`Gagal membuat pp sdm tinggi\n\n• *Error*:\n${e.message}\n\n> Segera lapor ke owner`);
  }
})

ev.on({
  cmd: ['gura', 'guraa'],
  listmenu: ['guraa'],
  tag: "maker",
  energy: 25,
  media: { type: ['image']}
}, async ({ media, cht }) => {
  await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
  
  let bkp = await catbox(media);
  let apih = `https://nirkyy-dev.hf.space/api/v1/gura?url=${encodeURIComponent(bkp)}&top=200&left=400&width=310&height=310`;
  
  try {
    await Exp.sendMessage(cht.id, { image: { url: apih }, caption: "🦈 Nihh si gura udah jadi~" }, { quoted: cht })
    
  } catch (e) {
    console.error(e);
    return cht.reply(`Gagal membuat si gura\n\n• *Error*:\n${e.message}\n\n> Segera lapor ke owner`);
  }
})

ev.on({
  cmd: ['gura2', 'guraa2'],
  listmenu: ['guraa2'],
  tag: "maker",
  energy: 25,
  media: { type: ['image']}
}, async ({ media, cht }) => {
  await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
  
  let bkp = await catbox(media);
  let apih = `https://nirkyy-dev.hf.space/api/v1/gura?url=${encodeURIComponent(bkp)}&bg=https://files.catbox.moe/0508ae.jpg&top=150&left=400&width=310&height=310`;
  
  try {
    await Exp.sendMessage(cht.id, { image: { url: apih }, caption: "🦈 Nihh si gura udah jadi~" }, { quoted: cht })
    
  } catch (e) {
    console.error(e);
    return cht.reply(`Gagal membuat si gura\n\n• *Error*:\n${e.message}\n\n> Segera lapor ke owner`);
  }
})

ev.on({
  cmd: [
    'meme1',    
    'meme2',
    'meme3',
    'meme4'
  ],
  listmenu: [
    'meme1',
    'meme2',
    'meme3',
    'meme4'
  ],
  energy: 25,
  media: {
    type: ['image']
  }
}, async ({ media, cht }) => {
  let tmp = await catbox(media);
  const o = cht.cmd;
  await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
  
  if (o === "meme1") {
     let jmb = `https://nirkyy-dev.hf.space/api/v1/gura?url=${encodeURIComponent(tmp)}&bg=https://files.catbox.moe/is6mt6.jpg&top=255&left=75&width=210&height=210`
     
     try {
       await Exp.sendMessage(cht.id, {
          image: {
            url: jmb
          },
          caption: "Nihh dah jadi..." 
       }, { quoted: cht });
     
     } catch (e) {
       console.error(e);
       return cht.reply(`Gagal membuat ${cht.cmd}\n\n• *Error*:\n${e.message}\n\n> Segera lapor ke owner`);
     }
     
  } else if (o === "meme2") {
     let jmb = `https://nirkyy-dev.hf.space/api/v1/gura?url=${encodeURIComponent(tmp)}&bg=https://files.catbox.moe/iie4a4.jpg&top=275&left=60&width=620&height=580`
     
     try {
       await Exp.sendMessage(cht.id, {
          image: {
            url: jmb
          },
          caption: "Nihh dah jadi..." 
       }, { quoted: cht });
     
     } catch (e) {
       console.error(e);
       return cht.reply(`Gagal membuat ${cht.cmd}\n\n• *Error*:\n${e.message}\n\n> Segera lapor ke owner`);
     }
     
  } else if (o === "meme3") {
     let jmb = `https://nirkyy-dev.hf.space/api/v1/gura?url=${encodeURIComponent(tmp)}&bg=https://files.catbox.moe/r8io46.jpg&top=155&left=285&width=390&height=390`
     
     try {
       await Exp.sendMessage(cht.id, {
          image: {
            url: jmb
          },
          caption: "Nihh dah jadi..." 
       }, { quoted: cht });
     
     } catch (e) {
       console.error(e);
       return cht.reply(`Gagal membuat ${cht.cmd}\n\n• *Error*:\n${e.message}\n\n> Segera lapor ke owner`);
     }
     
  } else {
     let jmb = `https://nirkyy-dev.hf.space/api/v1/gura?url=${encodeURIComponent(tmp)}&bg=https://files.catbox.moe/5lai2l.jpg&top=155&left=370&width=350&height=430`
     
     try {
       await Exp.sendMessage(cht.id, {
          image: {
            url: jmb
          },
          caption: "Nihh dah jadi..." 
       }, { quoted: cht });
     
     } catch (e) {
       console.error(e);
       return cht.reply(`Gagal membuat ${cht.cmd}\n\n• *Error*:\n${e.message}\n\n> Segera lapor ke owner`);
     }
     
  }
  
})

ev.on({
 cmd: ['sitolol'],
 listmenu: ['sitolol'],
 tag: "maker",
 energy: 25
}, async ({ args }) => {

const query = Array.isArray(args) ? args.join(' ') : String(args || '');
  if (!query) return cht.reply("Ketik nama orang nya\n> Contoh: `.sitolol Rehan`");

  await Exp.sendMessage(cht.id, { image: { url: `https://api.siputzx.my.id/api/m/sertifikat-tolol?text=${query}`
 }
}, { qukted: cht })
})

ev.on({
 cmd: ['tulis'],
 listmenu: ['tulis'],
 tag: "maker",
 energy: 15
}, async ({ args }) => {
const q = Array.isArray(args) ? args.join(' ') : String(args || '');
if (!q) return cht.reply("Masukkan teks yang mau di catat\n> Contoh: `.tulis i love you`");
await Exp.sendMessage(cht.id, {
  image: { url: 'https://abella.icu/nulis?text=' + encodeURIComponent(q) }
}, { quoted: cht });
})

}
