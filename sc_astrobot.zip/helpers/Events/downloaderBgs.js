/*!-======[ Module Imports ]======-!*/
const axios = "axios".import()
const fs = "fs".import()

/*!-======[ Default Export Function ]======-!*/
export default async function on({ cht, Exp, store, ev, is }) {
    let infos = Data.infos
    let { func } = Exp
    let { archiveMemories:memories } = func
    let { sender, id, reply } = cht
    
    const bar = cfg.bar; 
    const fakeQuoted = {
    key: {
      remoteJid: "status@broadcast",
      fromMe: false,
      id: "FAKE_ORDER_ID",
      participant: "0@s.whatsapp.net"
    },
    message: {
      orderMessage: {
        orderId: "1234567890",
        itemCount: 9999,
        status: 1,
        surface: 1,
        message: `${cht.pushName}`,
        orderTitle: "Order #654321",
        thumbnail: Buffer.alloc(0),
        sellerJid: "0@s.whatsapp.net"
      }
    }
  };

ev.on({
 cmd: ['capcutdl','capcutdownload'],
 listmenu: ['capcutdl'],
 tag: 'downloader',
 urls: {
   formats: ["capcut"],
   msg: true
 },
 energy: 15
 }, async ({ cht, urls }) => {
  const crot = urls[0];

  try {
    const res = await fetch(`https://api.botcahx.eu.org/api/dowloader/capcut?url=${encodeURIComponent(crot)}&apikey=barXbar`)
    const json = await res.json()
    if (!json.status) return cht.reply('❌ Gagal mengambil data CapCut.')

    const { id, title, author, owner, video, thumbnail } = json.result

    const teks = `
\`[ CAPCUT TEMPLATE ]\`

• ID       : *${id}*
• Author   : *${author || 'Tidak diketahui'}*
• Owner    : *${owner || 'Tidak diketahui'}*
• Hastag    :
- _${title || 'No Hastag'}_

⧗ Video sedang diproses, harap tunggu...
`.trim();

    await Exp.sendMessage(cht.id, {
       image: {
          url: thumbnail 
       },
       caption: teks 
    }, { quoted: cht });

    await sleep(1500);

    await Exp.sendMessage(cht.id, {
       video: {
         url: video 
       },
       caption: '✅ `Terkirim...`' 
    }, { quoted: cht });
    
  } catch (err) {
    console.error(err)
    cht.reply('🚫 Terjadi kesalahan saat mengambil data.')
  }
})

ev.on(
    {
      cmd: ['gdrive', 'gdrivedl', 'gdownload'],
      listmenu: ['gdrivedl'],
      tag: "downloader",
      energy: 25,
      urls: { 
        formats: [
          'drive.google'
        ], 
        msg: true 
      }
    }, 
    async ({ urls }) => {
    
      await Exp.sendMessage(
        id,
        { 
          react: { 
            text: "⏱️",
            key: cht.key
          }
        }
      );
  
      try {
      
        const res = await fetch(
          `https://api.botcahx.eu.org/api/download/gdrive?url=${encodeURIComponent(urls[0])}&apikey=barXbar`
        );
        const json = await res.json();

        const { 
          data: dl_link, 
          fileName, 
          fileSize,
          mimetype
        } = json.result;

        let teks = `乂  *G D R I V E  D L*\n\n`;
        teks += `• Nama File ′: *${fileName}*\n`;
        teks += `• Ukuran ′: *${fileSize}*\n\n`;
        teks += `_✅ Sukses terkirim..._`;

        await Exp.sendMessage(
          id, 
          {
            document: { 
              url: dl_link 
            },
            fileName,
            mimetype,
            caption: teks
          }, { quoted: cht }
        );

      } catch (e) {
        return reply( 
          "Gagal mengunduh file gdrive\n\n*Error*:\n" + e
        );
      }
    }
  )
  
ev.on({ 
          cmd: ['playmp4', 'video', 'mp4'],
          listmenu: ['playmp4', 'video', 'mp4'],
          tag: 'downloader',
          badword: true,
          args: "Harap sertakan url/judul videonya!",
          energy: 50
        }, async ({ args, urls }) => {
            const _key = keys[sender]
            let q = urls?.[0] || args || null
            if (!q) return cht.reply('Harap sertakan url/judul videonya!')
            try {
                await cht.edit("Sebentar...", _key)
                
                let apiUrl;
                if (q.includes("youtube.com") || q.includes("youtu.be")) {
                    apiUrl = `https://api.vreden.my.id/api/ytplaymp4?query=${encodeURIComponent(q)}`
                } else {
                    apiUrl = `https://api.vreden.my.id/api/ytplaymp4?query=${encodeURIComponent(q)}`
                }
                
                let data = await fetch(apiUrl, {
                    headers: {
                        'accept': 'application/json',
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'
                    }
                }).then(a => a.json())

                if (data.status !== 200 || !data.result?.status) {
                    return cht.reply("Can't download from that url!")
                }
                
                if (!data.result?.download?.url) {
                    if (data.result?.message) {
                        return cht.reply(`Can't download from that url! ${data.result.message}`)
                    } else {
                        return cht.reply("Can't download from that url!")
                    }
                }

                await cht.edit("Mengirimkan Media...", _key)
                
                let item = {
                    title: data.result.metadata?.title || "Video YouTube",
                    thumbnail: data.result.metadata?.thumbnail || data.result.metadata?.image,
                    quality: data.result.download?.quality || 'unknown'
                }
                
                let videoUrl = data.result.download.url
                
                let video = {
                    video: { url: videoUrl },
                    mimetype: 'video/mp4',
                    fileName: item.title + ".mp4",
                    caption: `*Judul:* ${item.title}\n*Kualitas:* ${item.quality}`,
                    contextInfo: {
                        externalAdReply: {
                            title: " " + item.title,
                            body: `Kualitas: ${item.quality}`,
                            thumbnailUrl: item.thumbnail,
                            sourceUrl: "",
                            mediaUrl: "http://ẉa.me/6283110928302?text=Idmsg: " + Math.floor(Math.random() * 100000000000000000),
                            renderLargerThumbnail: true,
                            mediaType: 1,
                        },
                    },
                }
                await cht.edit("```Berhasil🥳```", _key)
                await Exp.sendMessage(id, video, { quoted: cht })
            } catch (e) {
                console.log(e)
                cht.reply("Can't download from that url!")
            }
        })
        
ev.on({
  cmd: ['xvideosh', 'xvideosearch'],
  listmenu: ['xvideosh ℗'],
  tag: "search",
  args: "*❗ Ketik judul film-nye*",
  energy: 55,
  premium: true
}, async ({ args, cht }) => {
  await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
  try {
    const res = await fetch(`https://api.botcahx.eu.org/api/search/xvideos?query=${encodeURIComponent(args)}&apikey=barXbar`);
    const data = await res.json();

    if (!data.result || !Array.isArray(data.result) || data.result.length === 0) {
      return cht.reply(`❌ Tidak ditemukan hasil untuk: *${args}*`);
    }

    const list = data.result.slice(0, 5).map((v, i) => {
      return `${i + 1}. ${v.title}\n› Durasi: ${v.duration}\n› Link: ${v.url}`;
    }).join("\n\n");

    const thumb = 'https://files.catbox.moe/bh72ga.jpg' || null;

    if (thumb) {
      await Exp.sendMessage(cht.id, {
        text: `乂  *X V I D S E A R C H*\n\n${list}`,
          contextInfo: {
             externalAdReply: {
                title: `Nihh kak ${cht.pushName}`,
                body: `Xnxx Search`,
                thumbnailUrl: thumb,
                mediaUrl: `https://chat.whatsapp.com/G6axMRtSDIT4wvgNRgBTPz`,
                sourceUrl: `${data.result[0]?.url}`,
                renderLargerThumbnail: true,
                showAdAttribution: true,
                mediaType: 1,
             },
            forwardingScore: 1999,
            isForwarded: true,
          }
        }, { quoted: cht});
    } else {
      await cht.reply(`乂  *X V I D S E A R C H*\n\n${list}`);
    }

  } catch (e) {
    console.error(e);
    return cht.reply(`Gagal mengambil data xvid\n\n• *Error*:\n${e.message}\n\n> Segera lapor ke owner`);
  }
});

ev.on({
   cmd: ['mediafire2', 'mediafiredl2', 'md2', 'mfdl2'], 
   listmenu: ['mediafire2'], 
   tag: 'downloader',
   urls: {
      formats: ["mediafire"],
      msg: true
   },
   energy: 75
}, async ({ urls, cht }) => {
    await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
   
    try {
        const response = await fetch(`https://api.botcahx.eu.org/api/dowloader/mediafire?url=${urls[0]}&apikey=barXbar`);
        const json = await response.json();
        
        if (!json.result) {
           return cht.reply("❌ Gagal mengambil data MediaFire, pastikan link nya udah bener");
        }
        
        let {
          url,
          filename,
          ext,
          upload_date: aploud,
          filesize,
          filesizeH
        } = json.result;
        
        let caption = `
*📛 Name:* ${filename}
*📊 Size:* ${filesizeH}
*🗂️ Extension:* ${ext}
*📨 Uploaded:* ${aploud}
`.trim();
        
        await cht.reply(caption);
        await Exp.sendMessage(cht.id, { document: { url: url }, mimetype: ext, fileName: filename }, { quoted: cht });
        
    } catch (e) {
      console.error(e);
      return cht.reply(`Gagal mengunduh link MediaFire\n\n• *Error*:\n${e.message}\n\n> Segera lapor ke owner`)
    }
});

ev.on(
    {
      cmd: ['instagramdl2', 'igdl2', 'instagramdownload2'],
      listmenu: ['instagramdl2'],
      tag: "downloader",
      energy: 25,
      urls: {
        formats: [
          'instagram'
        ],
        msg: true
      }
    }, 
    async ({ urls }) => {
    
      await Exp.sendMessage(
        id, 
        {
          react: {
            text: "⏱️",
            key: cht.key 
          }
        }
      );
      
      try {
        const api = await fetch(
          `https://api.botcahx.eu.org/api/dowloader/igdowloader?url=${urls[0]}&apikey=barXbar`
        );
        const res = await api.json();
        
        const {
          wm,
          thumbnail,
          url
        } = res.result[0];
        
        let teks = `乂  *I N S T A G R A M  D L*\n\n`;
        teks += `• *Wm* ′: ${wm}\n`;
        teks += `• *Satatus* ′: sukses\n\n`;
        teks += `_Video segera di kirim..._`;
        
        await Exp.sendMessage(
          id,
          {
            text: teks,
            contextInfo: {
              externalAdReply: {
                title: "Instagram downloader",
                body: `❏ Elaina [ イレイナ ]`,
                thumbnailUrl: 'https://files.catbox.moe/vj4bqi.jpg',
                mediaUrl: cfg.gcurl,
                sourceUrl: `https://wa.me/${owner[0]}`,
                renderLargerThumbnail: true,
                showAdAttribution: true,
                mediaType: 1,
              },
              forwardingScore: 19,
              isForwarded: true,
            }
          }, { quoted: cht }
        );
        
        await Exp.sendMessage(
          id,
          {
            video: {
              url
            },
            caption: "✅ Video instagram berhasil terkirim..."
          }, { quoted: cht }
        )
        
      } catch (e) {
        return reply(
          "Gagal mengunduh video instagram\n\n*Error*:\n" + e
        );
      }
    }
  )
  
  ev.on(
    {
      cmd: ['facebookdl2', 'facebookdownload2', 'fbdl2'],
      listmenu: ['facebookdl2'],
      tag: "downloader",
      energy: 25,
      urls: {
        formats: [
          'facebook'
        ],
        msg: true
      }
    }, 
    async ({ urls }) => {
    
      await Exp.sendMessage(
        id,
        { 
          react: {
            text: "⏱️",
            key: cht.key 
          }
        }
      );
      
      try {
        const api = await fetch(
          `https://api.botcahx.eu.org/api/dowloader/fbdown3?url=${encodeURIComponent(urls[0])}&apikey=barXbar`
        );
        const res = await api.json();
        
        const {
          urls: rs
        } = res.result.url;
        
        let teks = `乂  *F A C E B O O K  D L*\n\n`;
        teks += `• *Tautan* ′: ${urls[0]}\n`;
        teks += `• *Resolusi* ′: HD`;
        
        await Exp.sendMessage(
          id,
          {
            video: {
              url: rs[0].hd
            },
            caption: teks
          }, { quoted: cht}
        );
        
      } catch (e) {
        return reply(
          "Gagal mengunduh video facebook\n\n*Error*:\n" + e 
        );
      }
    }
  )

ev.on({
  cmd: ['snackvideodl'],
  listmenu: ['snackvideodl'],
  tag: 'downloader',
  energy: 25
}, async ({ cht, args }) => {
  const query = Array.isArray(args) ? args.join(' ') : String(args || '');
  if (!query) return Exp.sendMessage(cht.id, { text: '⚠️ Masukkan link SnackVideo terlebih dahulu!' });
  
  await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
  
  try {
    const res = await fetch(`https://api.botcahx.eu.org/api/download/snackvideo?url=${encodeURIComponent(query)}&apikey=barXbar`);
    const json = await res.json();

    if (!json.status) return Exp.sendMessage(cht.id, { text: '❌ Gagal mengambil data dari SnackVideo!' });

    const { title, thumbnail, media, author, authorImage, like, comment, share } = json.result;

    await Exp.sendMessage(cht.id, {
      image: { url: thumbnail },
      caption: `🎬 *${title}*\n👤 Author: ${author}\n❤️ ${like}  💬 ${comment}  🔄 ${share}`
    });

    await Exp.sendMessage(cht.id, {
      video: { url: media },
      caption: '✅ Nih kak...'
    });

  } catch (e) {
    console.error(e);
    await Exp.sendMessage(cht.id, { text: '🚨 Terjadi kesalahan saat mengunduh video SnackVideo.' });
  }
})

ev.on({
  cmd: ['spotifydownload', 'spdl'],
  listmenu: ['spotifydownload'],
  tag: "downloader",
  energy: 55
}, async ({ args, cht }) => {
  const url = Array.isArray(args) ? args.join(' ') : String(args || '');

  if (!url || !url.includes('spotify.com/track')) {
    return cht.reply('❌ *Masukkan link lagu Spotify yang valid!*\nContoh: .spotify https://open.spotify.com/track/xxxx')
  }

  try {
    await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
    await Exp.sendMessage(cht.id, {
      audio: { url: `https://nirkyy-dev.hf.space/api/v1/spotifydlv2?url=${encodeURIComponent(url)}` },
      mimetype: 'audio/mpeg',
      ptt: true,
      contextInfo: {
        externalAdReply: {
          title: `Spotify Downloader 🎧`,
          body: `© ASTROBOT MD ✓`,
          thumbnail: fs.readFileSync(fol[3] + 'spotify.jpg'),
          mediaUrl: `https://chat.whatsapp.com/G6axMRtSDIT4wvgNRgBTPz`,
          sourceUrl: `${url}`,
          renderLargerThumbnail: true,
          showAdAttribution: true,
          mediaType: 1
        },
        forwardingScore: 1999,
        isForwarded: true
      }
    }, { quoted: fakeQuoted });

  } catch (err) {
    console.error(err);
    return cht.reply('⚠️ Terjadi kesalahan saat mencoba download lagu.');
  }
})


  ev.on(
    {
      cmd: ['pinterestdl2', 'pindl2', 'pindownload2'],
      listmenu: ['pindl2'],
      tag: "downloader",
      energy: 25,
      urls: {
        formats: [
          'pin'
        ],
        msg: true
      }
    },
    async ({ urls, cht }) => {
      
      let type = ''
      await Exp.sendMessage(
        cht.id, 
        {
          react: {
            text: "⏱️", 
            key: cht.key 
          }
        }
      );
      
      try {
        const api = await fetch(
          `https://api.botcahx.eu.org/api/download/pinterest?url=${urls[0]}&apikey=barXbar`
        );
        
        const res = await api.json();
        
        const {
          media_type,
          poster,
          title
        } = res.result.data;
        
        if (media_type === "image") {
          type = "foto"
        } else if (media_type === "video/mp4") {
          type = "video"
        } else {
          type = media_type
        }
        
        let teks = `乂  *P I N T E R E S T  D L*\n\n`;
        teks += `• *Judul* ′: ${title}\n`;
        teks += `• *Tipe* ′: ${type}\n\n`;
        teks += `_${type} segera di kirim..._`
        
        await cht.reply(teks)
        
        if (type === "foto") {
          Exp.sendMessage(
            cht.id,
            {
              image: {
                url: res.result.data.image
              },
              caption: "✅ Foto pinterest berhssil terkirim..."
            }, { quoted: cht }
          )
        } else {
          Exp.sendMessage(
            cht.id,
            { 
              video: {
                url: res.result.data.video
              },
              caption: "✅ Video pinterest berhasil terkirim..."
            }, { quoted: cht }
          )
        }
      
      } catch (e) {
        return cht.reply(
          `Gagal mengunduh ${type} pinterest\n\n*Error*:\n` + e
        )
      }
    }
  )

ev.on({
  cmd: ['tiktok2', 'tiktokdl2', 'ttdl2', 'tiktokdownload2', 'tt2'],
  listmenu: ['tiktok2'],
  tag: "downloader",
  energy: 25,
  urls: {
    formats: ['tiktok'],
    msg: true
  }
}, async ({ urls, cht }) => {
  let url = urls[0];
  
  try {
    const res = await fetch(`https://api.botcahx.eu.org/api/dowloader/tiktok?url=${encodeURIComponent(url)}&apikey=barXbar`);
    const json = await res.json();
   
    if (!json.status || !json.result) {
      return cht.reply('❌ Gagal mengambil video. Pastikan link TikTok-nya benar.')
    }

    const { title, video, audio } = json.result;
    
    if (video?.length) {
      await Exp.sendMessage(cht.id, {
        video: { url: video[0] },
        caption: `乂  ＴＩＫＴＯＫ\n\n*title:\n${title}`
      }, { quoted: cht })
    }
      
    if (audio?.length) {
      await Exp.sendMessage(cht.id, {
        audio: { url: audio[0] },
        mimetype: 'audio/mpeg',
        ptt: true
      })
    } return;
    
  } catch (e) {
    console.error(e)
    cht.reply(`Gagal mengunduh link tiktok\n\n• *Error*:\n${e.message}\n\n> Segera lapor ke owner`)
  }
})

ev.on({
  cmd: ['tiktokslide', 'ttslide'],
  listmenu: ['tiktokslide'],
  tag: 'downloader',
  energy: 25,
  urls: {
    formats: ['tiktok'],
    msg: true
  }
}, async ({ urls, cht }) => {
   let url = urls[0];
    
  try {
    const res = await fetch(`https://api.botcahx.eu.org/api/download/tiktokslide?url=${url}&apikey=barXbar`)
    const json = await res.json();
    
    if (!json.status || !json.result) {
      return cht.reply('❌ Gagal mengambil video. Pastikan link TikTok-nya benar.')
    }

    const { title, thumbnail, audio, images, totalSlide } = json.result;
 
    await Exp.sendMessage(cht.id, {
      text: `乂  ＴＩＫＴＯＫ\n\n*title*:\n${title}`,
        contextInfo: {
        externalAdReply: {
          title: `Tiktok Slide Downloader`,
          body: `© ASTROBOT MD ✓`,
          thumbnailUrl: thumbnail,
          mediaUrl: `https://chat.whatsapp.com/G6axMRtSDIT4wvgNRgBTPz`,
          sourceUrl: `${url}`,
          renderLargerThumbnail: true,
          showAdAttribution: true,
          mediaType: 1,
        },
        forwardingScore: 1999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: "120363388627433447@newsletter",
          newsletterName: "🪀 𝐁𝐚𝐫𝐫 𝐢𝐧 𝐇𝐞𝐫𝐞",
        //serverMessageId: 152
        }
      }      
    }, { quoted: cht })
    
    await sleep(1500)
    
    if (images?.length) {
      for (let i = 0; i < images.length; i++) {
        await Exp.sendMessage(cht.id, {
          image: { url: images[i] },
          caption: `\`Slide ke ${i + 1} dari ${totalSlide}\``
        }, { quoted: cht })
      }
    }

    if (audio?.length) {
      await Exp.sendMessage(cht.id, {
        audio: { url: audio[0] },
        mimetype: 'audio/mpeg',
        ptt: true
      })
    } return;
     
  } catch (e) {
    console.error(e)
    cht.reply(`Gagal mengunduh link tiktok\n\n• *Error*:\n${e.message}\n\n> Segera lapor ke owner`)
  }
})

ev.on({
  cmd: ['twitterdl','twitterdownload'],
  listmenu: ['twitterdl'],
  tag: 'downloader',
  energy: 25
}, async ({ args, cht }) => {
  const query = Array.isArray(args) ? args.join(' ') : String(args || '');
  if (!query) return cht.reply('🚫 Masukkan link Twitter!\nContoh: .twitter https://twitter.com/faqeeyaaz/status/1242789155173617664');

  await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });

  try {
    let res = await fetch(`https://api.botcahx.eu.org/api/dowloader/twitter?url=${encodeURIComponent(query)}&apikey=barXbar`)
    let json = await res.json()

    if (!json.status || !json.result?.url?.[0]?.hd) {
      return cht.reply('❌ Gagal ambil video. Pastikan link valid dan berisi video.')
    }

    await Exp.sendMessage(cht.id, {
      video: { url: json.result.url[0].hd },
      caption: '✅ `Nih kak...`'
    }, { quoted: cht })

  } catch (e) {
    console.error(e)
    cht.reply('⚠️ Terjadi kesalahan saat mengunduh video.')
  }
})

ev.on({
  cmd: ['videydl','videydownlod'],
  listmenu: ['videydl'],
  tag: 'downloader',
  energy: 25
}, async ({ args, cht }) => {
  const query = Array.isArray(args) ? args.join(' ') : String(args || '');
  if (!query) return cht.reply('🚫 Masukkan link Videy!\nContoh: .videy https://videy.co/v?id=xxxxx');

  await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });

  try {
    let res = await fetch(`https://api.botcahx.eu.org/api/dowloader/videy?url=${encodeURIComponent(query)}&apikey=barXbar`)
    let json = await res.json()

    if (!json.status || !json.result) {
      return cht.reply('❌ Gagal mengambil video. Pastikan link valid dan coba lagi.')
    }

    await Exp.sendMessage(cht.id, {
      video: { url: json.result },
      caption: '✅ `Nihh kak...`'
    }, { quoted: cht })

  } catch (e) {
    console.error(e)
    cht.reply('⚠️ Terjadi kesalahan saat mengunduh video')
  }
})

ev.on({
 cmd: ['xnxxdl','xnxxdownload'],
 listmenu: ['xnxxdl ℗'],
 tag: "downloader",
 energy: 15,
 premium: true
}, async ({ cht, args }) => {
  const query = Array.isArray(args) ? args.join(' ') : String(args || '');
  if (!query) return Exp.sendMessage(cht.id, { text: 'Masukkan link video xnxx yang valid!' });

  await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });

  try {
    const res = await fetch(`https://api.botcahx.eu.org/api/download/xnxxdl?url=${encodeURIComponent(query)}&apikey=barXbar`);
    const json = await res.json();

    if (!json.status) return Exp.sendMessage(cht.id, { text: 'Gagal mengambil data, coba lagi nanti!' });

    const result = json.result;

    await Exp.sendMessage(cht.id, {
      image: { url: result.thumb },
      caption: `\`[ XNXX VIDEO ]\`\n\n• Duration: ${result.duration.trim() || '-'}\n• Quality: ${result.quality.trim() || '-'}\n• Views: ${result.views}\n\n─────────────`
    });

    await Exp.sendMessage(cht.id, {
      video: { url: result.url },
      caption: "✅ `Terkirim...`"
    });

  } catch (e) {
    console.error(e);
    await Exp.sendMessage(cht.id, { text: 'Terjadi kesalahan saat mengambil video.' });
  }
})

}
