/*!-======[ Module Imports ]======-!*/
const fs = "fs".import()
const { default: ms } = await "ms".import()
const { downloadContentFromMessage } = "baileys".import()

export default async function on({ cht, Exp, store, ev, is }) {
    const { sender, id, reply, edit } = cht
    const { func } = Exp
    let infos = Data.infos
   
    const kontak = ['6283163686712@s.whatsapp.net'];
   
ev.on({
 cmd: ['sewabot'],
 listmenu: ['sewabot'],
 tag: "other"
}, async () => {

 reply("🕑 _PROSES MENAMPILKAN HARGA..._")
 await sleep(1500)
 
await Exp.sendMessage(cht.id, {
   document: fs.readFileSync("./index.js"),
   mimetype: 'application/pdf',
   fileName: `Barr in here`,
  fileLength: 1000000000000,
  caption: `
_── 「 \`𝗟𝗶𝘀𝘁 𝗛𝗮𝗿𝗴𝗮 𝗦𝗲𝘄𝗮\`」 ──_

• 4 hari = 5k
• 7 hari = 10k
• 10 hari = 13k
• 13 hari = 15k
• 15 hari = 20k
• 20 hari = 23k
• 30 hari = 30k
• 60 hari = 50k

Permanen = Hannya 70k saja deh soalnya butuh panel kalo mau permanen GK ada panel ya GK bisa aktif botnya
`,
   contextInfo: {
       externalAdReply: {
         title: "S E W A 🌸",
          body: `Ownerku Baik Kok`,
          thumbnailUrl: "https://files.catbox.moe/jlh7i6.jpg",
          mediaUrl: `https://chat.whatsapp.com/G6axMRtSDIT4wvgNRgBTPz`,
          renderLargerThumbnail: true,
          showAdAttribution: true,
          mediaType: 1,
       },
          forwardingScore: 19,
          isForwarded: true,
        },
        footer: `[ NOTE ]\n❗ Minimal 1 grup/sewa`,
            buttons: [
        {
            buttonId: ".nogw",
            buttonText: { displayText: "💬 Chat owner" }
        },
        {
            buttonId: ".premium",
            buttonText: { displayText: "💎 Harga Premium" }
        }
       ],
        viewOnce: true,
headerType: 6
      },
 { quoted: cht} );
  Data.audio?.menu?.length > 0 && Exp.sendMessage(cht.id, { audio: { url: Data.audio.menu.getRandom() }, ptt: true, mimetype: "audio/mpeg" }, { quoted: cht })
})

ev.on({
 cmd: ['nogw']
}, async () => {
 await Exp.sendContacts(cht, kontak)
 await sleep(1500)
 reply("Nih kak... Jangan php yahh 😾")
});
}