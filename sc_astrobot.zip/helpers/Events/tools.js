/*!-======[ Module Imports ]======-!*/
const fs = 'fs'.import();
const { generateWAMessageFromContent } = 'baileys'.import();
const axios = await 'axios'.import();
const sharp = (await 'sharp'.import()).default

/*!-======[ Functions Imports ]======-!*/
const { musixSearch } = await (fol[2] + 'musixsearch.js').r();
const { transcribe } = await (fol[2] + 'transcribe.js').r();
const { tmpFiles } = await (fol[0] + 'tmpfiles.js').r();
const { catbox } = await (fol[0] + 'catbox.js').r();
const { TermaiCdn } = await (fol[0] + 'cdn.termai.js').r();
const { hdVideo } = await (fol[2] + 'hdVideo.js').r();
const { EncryptJs } = await (fol[2] + 'encrypt.js').r();

/*!-======[ Default Export Function ]======-!*/
export default async function on({ cht, Exp, store, ev, is }) {
  let infos = Data.infos;
  let { sender, id, reply, edit } = cht;
  const { func } = Exp;

  ev.on(
    {
      cmd: ['remini', 'hd'],
      listmenu: ['remini'],
      tag: 'tools',
      energy: 30,
      media: {
        type: ['image'],
      },
    },
    async ({ media }) => {
      const _key = keys[sender];
      await cht.edit('Bntr...', _key);
      let tph = await TermaiCdn(await func.minimizeImage(media));
      await cht.edit('Processing...', _key);
      let res = (
        await fetch(
          api.xterm.url +
            '/api/tools/remini?url=' +
            tph +
            '&key=' +
            api.xterm.key
        ).then((a) => a.json())
      ).data;
      await Exp.sendMessage(
        id,
        { image: { url: res.url }, caption: `Response Time: ${res.run_Time}` },
        { quoted: cht }
      );
    }
  );
  
  ev.on({ 
        cmd: ['sc', 'scbot', 'scriptbot'],
        listmenu: ['sc'],
        tag: 'other'
    }, async () => {

    // Gantilah dengan link Saweria kamu
    const nomorlink = "wa.me/6283163686712";

    const txt = `🎮 *SC ASTROBOT MD* 🎮\n\n`
        + `SC BOT INI BERBAYAR YA UNTUK HARGA BISA CHAT NOMOR DI BAWAH\n\n`
        + `🔗 *link sc hubungin nomor ini*: ${nomorlink}\n\n`
        + `fitur sc bot ini di jamin enak untuk di pakai buatan dari`
        + `sc original *rifza/bella* untuk rename dari bagus dev`;

    return cht.reply(txt);
});

  ev.on(
    {
      cmd: ['pastebin', 'pastebincopy'],
      listmenu: ['pastebin'],
      tag: "tools",
      energy: 25,
      urls: { 
        formats: [
          'pastebin'
        ],
        msg: true 
      }
    }, 
    async ({ urls }) => {
    
      const link = urls[0];
      const pasteId = link.split('/').pop();

      try {
        const response = await fetch(`https://pastebin.com/raw/${pasteId}`);
        if (!response.ok) throw new Error('Gagal mengambil isi dari Pastebin.');
    
        const content = await response.text();
        if (!content.trim()) {
          return reply('📄 Tidak ada isi yang ditemukan di Pastebin!');
        }

        reply(`📑 *Isi Pastebin:*\n\n${content}`);
        
      } catch (e) {
        console.error(e);
        return reply(
          "Gagal mengambil data pstebin\n\n*Erro*:\n" + e
        );
      }
    }
  )
  
  ev.on({
   cmd: ['hd2', 'remini2'],
   listmenu: ['hd2 ℗'],
   tag: "tools",
   premium: true,
   energy: 55,
   media: {
      type: ['image']
   }
}, async ({ cht, media }) => {
   try {
      await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });

      const url = await catbox(media);

      const api1 = `https://api.botcahx.eu.org/api/tools/remini?url=${encodeURIComponent(url)}&apikey=barXbar`;
      const res1 = await fetch(api1);
      const json1 = await res1.json();

      let hdUrl;

      if (json1.status && json1.url) {
         hdUrl = json1.url;
      } else {
         const api2 = `https://api.botcahx.eu.org/api/tools/remini-v2?url=${encodeURIComponent(url)}&apikey=barXbar`;
         const res2 = await fetch(api2);
         const json2 = await res2.json();

         if (!json2.status || !json2.url) {
            return cht.reply("❌ Gagal memproses gambar HD.");
         }

         hdUrl = json2.url;
      }

      await Exp.sendMessage(cht.id, {
         image: { url: hdUrl },
         caption: `🍟 Sukses memperbaiki resolusi`
      },{ quoted: cht });

   } catch (err) {
      console.error(err);
      return cht.reply(`Gagal memperbaiki resolusi fotonya\n\n• *Error*:\n${err.message}\n\n> Segera lapor ke owner`);
   }
});

ev.on(
    {
      cmd: ['resize', 'ubahukuran'],
      listmenu: ['resize'],
      tag: "tools",
      energy: 15,
      media: {
         type: [
           'image'
         ]
      },
      args: `ga gitu, contoh .${cht.cmd} 1920x1080`
    },
    async ({ media, args }) => {
  
      await Exp.sendMessage(
        id,
        { 
          react: { 
            text: "⏱️",
            key: cht.key
          } 
        }
      );
    
      const mediaUrl = await catbox(media)

      const [w, h] = args.split(/\D+/).map(v => parseInt(v));
      if (!w || !h || w < 1 || h < 1) {
        return reply("❌ Ukuran tidak valid.\nContoh: .resize 1920 1080");
      }

      try {
        const res = await axios.get(mediaUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(res.data);

        const resized = await sharp(buffer).resize(w, h).toBuffer()

        await Exp.sendMessage(
          id, 
          {
            image: resized,
            caption: `✅ Berhasil ubah ukuran menjadi *${w}x${h}*`
          }, { quoted: cht }
        );

      } catch (e) {
        console.error(e);
        return reply(`gagal mengubah ukuran foto tersebut\n\n*Error*:` + e);
      }
    }
  )
  
ev.on({ 
    cmd: ['sejarah'], 
    listmenu: ['sejarah'],
    tag: 'tools'
}, async () => {
    const res = await fetch("https://history.muffinlabs.com/date");
    const data = await res.json();
    await cht.reply(`Hari ini dalam sejarah:\n${data.data.Events[0].text}`);
   });
   
ev.on({
  cmd: ["cekrute", "goo", "rute"],
  listmenu: ["cekrute ℗"],
  tag: "search",
  premium: true,
  energy: 50
}, async ({ cht, args }) => {
  if (!args || !args.includes(',')) return cht.reply('Format salah! Gunakan: jarak [kota asal],[kota tujuan]\nContoh: jarak bekasi,madiun');
  
  let [from, to] = args.split(',').map(v => v.trim());
  let url = `https://api.vreden.my.id/api/tools/jarak?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`;
  
  try {
    let response = await fetch(url);
    let data = await response.json();
    
    if (data.status !== 200) return cht.reply('Gagal mendapatkan data jarak! Pastikan kota yang dimasukkan benar.');
    
    let result = data.result;
    let msg = `📍 \`\`\`Informasi Jarak 📍\n 🚗 *Dari:* ${result.asal.alamat}\n 📍 *Ke:* ${result.tujuan.alamat}\n 📏 *Jarak:* ${result.detail.split('menempuh jarak ')[1].split(',')[0]}\n ⏳ *Estimasi Waktu:* ${result.detail.split('estimasi waktu ')[1]}\n ⛽ *Estimasi BBM:* ${result.estimasi_biaya_bbm.total_liter} liter (~${result.estimasi_biaya_bbm.total_biaya})\n 🗺️ *Peta:* ${result.peta_statis}\n 📍 *Rute Perjalanan:* ${result.arah_penunjuk_jalan.map(step => `🚘 ${step.instruksi} (${step.jarak})`).join('\n')}\`\`\``;
    
    cht.reply(msg);
  } catch (e) {
    console.error(e);
    cht.reply('Terjadi kesalahan saat mengambil data!');
  }
})

ev.on(
  {
    cmd: ['tinyurl1'],
    listmenu: ['tinyurl1'],
    tag: "tools",
    args: "*❗ Berikan url yang ingin di pendek kan*"
  },
  async ({ args, cht }) => {

    try {
      let api = await fetch(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(args)}`)
      let shortUrl = await api.text() 

      cht.reply(`🔗 URL Asli: ${args}\n👉 URL Pendek: ${shortUrl}`)
    } catch (e) {
      cht.reply("Gagal membuat url tinyurl\n\n*Error*:\n" + e)
    }
  }
)

ev.on({
        cmd: ['tiny', 'tinyurl', 'shortlink'],
        listmenu: ['tinyurl'],
        tag: "tools",
        args: "Masukkan link yang ingin diperpendek atau .tinyurl https://example.com",
        energy: 5
    }, async() => {
        try {
            if (!cht.q || cht.q.trim() === '') {
                return cht.reply("Harap masukkan link yang ingin diperpendek!\n\nContoh: .tiny https://example.com");
            }
            
            let url = cht.q.trim();
            if (!url.startsWith('http://') && !url.startsWith('https://')) {
                url = 'https://' + url;
            }
            
            if (!url.includes('.')) {
                return cht.reply("Link tidak valid! Pastikan menggunakan format URL yang benar.\n\nContoh: .tiny https://example.com");
            }
            
            await cht.edit(infos.messages.wait, keys[sender]);
            
            let response = await fetch(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(url)}`);
            let shortUrl = (await response.text()).trim();
            
            if (!shortUrl || shortUrl.includes('Error') || !shortUrl.startsWith('https://tinyurl.com')) {
                return cht.reply("failed");
            }
            
            cht.reply(`${shortUrl}`);
            
        } catch (e) {
            console.error("TinyURL Error:", e);
            cht.reply("failed " + e.message);
        }
    })
    
ev.on(
    {
      cmd: ['spamngl', 'nglspam'],
      listmenu: ['spamngl'],
      tag: "tools",
      energy: 55,
      premium: true,
      urls: {
        formats: [
          'ngl', 'ngl.link'
        ],
        msg: "Berukan url ngl nya contoh nya gini:\n .spamngl https://ngl.link/powerranggers1 10 Haii"
      }
    },
    async ({ cht, urls, args }) => {
      let [link, jumlahStr, ...pesanArr] = args.split(' ')
      let jumlah = parseInt(jumlahStr)
      let pesan = pesanArr.join(' ').trim()

      if (!link || !jumlahStr || !pesan) {
          return cht.reply(`Contoh: .${cht.cmd} https://ngl.link/username 3 pesan kamu`)
      }
    
      if (jumlah < 1 || jumlah > 20) return cht.reply('Jumlah 1-20 saja!') //nih atur aja yang 20 itu ubah sesuka hati 

      await Exp.sendMessage(
        cht.id,
        {
          react: {
            text: "⏱️", 
            key: cht.key 
          } 
        }
      );

      try {
        const username = link.split('ngl.link/')[1]
        if (!username) return cht.reply('Username tidak valid')

        for (let i = 0; i < jumlah; i++) {
            await fetch('https://ngl.link/api/submit', {
                method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded',
                },
                body: `username=${username}&question=${encodeURIComponent(pesan)}&deviceId=1`
            })
            await sleep(1000)
        }

        cht.reply(`✅ Berhasil kirim ${jumlah} pesan ke ${username}`)

      } catch (e) {
        return cht.reply(
          "Gagal mengirim pesan ngl\n\n*Error*:\n" + e
        );
      }
    }
  )
  
  ev.on(
    {
      cmd: ['pastebin', 'pastebincopy'],
      listmenu: ['pastebin'],
      tag: "tools",
      energy: 25,
      urls: { 
        formats: [
          'pastebin'
        ],
        msg: true 
      }
    }, 
    async ({ urls }) => {
    
      const link = urls[0];
      const pasteId = link.split('/').pop();

      try {
        const response = await fetch(`https://pastebin.com/raw/${pasteId}`);
        if (!response.ok) throw new Error('Gagal mengambil isi dari Pastebin.');
    
        const content = await response.text();
        if (!content.trim()) {
          return reply('📄 Tidak ada isi yang ditemukan di Pastebin!');
        }

        reply(`📑 *Isi Pastebin:*\n\n${content}`);
        
      } catch (e) {
        console.error(e);
        return reply(
          "Gagal mengambil data pstebin\n\n*Erro*:\n" + e
        );
      }
    }
  )
  
  ev.on(
    {
      cmd: ['tmpfile', 'tmpfiles'],
      listmenu: ['tmpfiles'],
      tag: 'tools',
      energy: 5,
      media: {
        type: ['image', 'sticker', 'audio', 'video'],
      },
    },
    async ({ media }) => {
      let tmp = await tmpFiles(media);
      await cht.edit(tmp, keys[sender]);
    }
  );

ev.on(
    {
      cmd: ['hdvideo', 'videohd', 'hdvid', 'vidhd'],
      listmenu: ['hdvideo ℗'],
      tag: "tools",
      premium: true,
      energy: 75,
      media: { 
        type: [
          'video'
        ]
      }
    },
    async ({ media }) => {
      const link = await catbox(media)
        
      await edit(
        `⏳ Video telah di proses, tunggu 1 - 4 menit lah`,
        keys[sender] 
      )
  
      try {
        const buffer = await hdVideo(link)
        await Exp.sendMessage(
          id, 
          { 
            video: buffer,
            caption: "🍟 Berhssil memperbaiki resolusi video"
          }, { quoted: cht }
        )
    
      } catch (e) {
        return reply("Gagal memperbaiki resolusi video\n\n*Error*:\n" + e)
      }
    }
  )
  
ev.on({
  cmd: ['hdvideo1'],
  listmenu: ['hdvideo1 ℗'],
  tag: "tools",
  premium: true,
  energy: 150,
  media: { type: ['video'] }
}, async ({ media, cht }) => {
  
  let inputPath = await catbox(media);
  let outputPath = './receptacle/video_1080p.mp4';

  await Exp.sendMessage(cht.id, { react: { text: "⏱️", key: cht.key } });
  await sleep(1500);

  try {
    if (!fs.existsSync('./receptacle')) fs.mkdirSync('./receptacle', { recursive: true });

    const ffmpegCommand = `ffmpeg -fflags +genpts -copyts -avoid_negative_ts make_zero -i "${inputPath}" -vf scale=1920:1080 -c:v libx264 -preset medium -crf 20 -c:a aac -b:a 128k -movflags +faststart "${outputPath}"`;

    await execPromise(ffmpegCommand);
    await sleep(1000);

    await Exp.sendMessage(cht.id, {
      video: fs.readFileSync(outputPath),
      fileName: 'video_1080p.mp4',
      caption: '✅ Berhasil memperbaiki resolusi video'
    }, { quoted: cht } );

  } catch (e) {
    console.error(e);
    cht.reply(`❌ Gagal mengubah resolusi video.\n\n*Error:* ${e.message}\n\n> Segera lapor ke owner`);
  } finally {
    if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
    if (fs.existsSync(inputPath) && inputPath.startsWith('./tmp')) fs.unlinkSync(inputPath);
  }
});

  ev.on(
    {
      cmd: ['catbox'],
      listmenu: ['catbox'],
      tag: 'tools',
      energy: 5,
      media: {
        type: ['image', 'sticker', 'audio', 'video', 'document'],
      },
    },
    async ({ media }) => {
      let tmp = await catbox(media);
      await cht.edit(tmp, keys[sender]);
    }
  );
  ev.on(
    {
      cmd: ['tourl'],
      listmenu: ['tourl', 'termaicdn'],
      tag: 'tools',
      energy: 5,
      media: {
        type: ['image', 'sticker', 'audio', 'video', 'document'],
      },
    },
    async ({ media }) => {
      let tmp = await TermaiCdn(media);
      await cht.edit(tmp, keys[sender]);
    }
  );

  ev.on(
    {
      cmd: [
        'img2prompt',
        'tomprompt',
        'imgtoprompt',
        'imagetoprompt',
        'image2prompt',
      ],
      listmenu: ['img2prompt'],
      tag: 'tools',
      energy: 28,
      media: {
        type: ['image'],
      },
    },
    async ({ media }) => {
      await cht.edit('Bntr...', keys[sender]);
      let tph = await TermaiCdn(await func.minimizeImage(media));
      let dsc = await fetch(
        `${api.xterm.url}/api/img2txt/instant-describe?url=${tph}&key=${api.xterm.key}`
      ).then((response) => response.json());
      cht.reply(dsc.prompt);
    }
  );
  ev.on(
    {
      cmd: ['enhance', 'upscale'],
      listmenu: ['enhance', 'enhance list'],
      tag: 'tools',
      energy: 35,
      media: {
        type: ['image'],
      },
    },
    async ({ media }) => {
      const _key = keys[sender];
      let type = cht.q ? cht.q : 'stdx4';
      if (cht.q == 'list') return cht.reply(infos.tools.enhance);
      if (
        cht.q &&
        ![
          'phox2',
          'phox4',
          'anix2',
          'anix4',
          'stdx2',
          'stdx4',
          'cf',
          'text',
        ].includes(cht.q)
      )
        return cht.reply(
          'Type tidak ada! mungkin salah ketik!\n\n' + infos.tools.enhance
        );
      await cht.edit('Uploading image...', _key, true);
      let imgurl = await TermaiCdn(await func.minimizeImage(media));
      let ai = await fetch(
        `${api.xterm.url}/api/tools/enhance/createTask?url=${imgurl}&type=${type}&key=${api.xterm.key}`
      ).then((response) => response.json());

      if (!ai.status) return cht.reply(ai.cht);
      while (true) {
        try {
          let s = await fetch(
            `${api.xterm.url}/api/tools/enhance/taskStatus?id=${ai.id}`
          ).then((response) => response.json());
          if (!s.status)
            return cht.reply(`Status: ${s?.status}\nMessage: Failed!`);
          await cht.edit(
            `Status: ${s?.status}\nProgress: ${s?.progress}%`,
            _key,
            true
          );
          if (s.task_status == 'failed') {
            return cht.reply(s.task_status);
          }
          if (s.task_status == 'done') {
            await Exp.sendMessage(
              id,
              { image: { url: s.output } },
              { quoted: cht }
            );
            break;
          }
          await new Promise((resolve) => setTimeout(resolve, 3000));
        } catch (e) {
          await cht.reply('TypeErr:' + e.message);
          break;
        }
      }
    }
  );


ev.on({
 cmd: ['styletxt', 'style'],
 listmenu: ['styletxt'],
 tag: 'tools',
 energy: 10
}, async ({ cht, args }) => {

 try {
  const api = `https://api.botcahx.eu.org/api/tools/styletext?text=${encodeURIComponent(args)}&apikey=barXbar`
  const res = await fetch(api)
  const json = await res.json()

  if (!json.status || !json.result) return cht.reply('❌ Gagal mengambil data.')

  const styledTexts = json.result
    .filter(x => x.result) 
    .map((x, i) => `*${i + 1}.*\n- ${x.result}`)
    .join('\n\n')

  cht.reply(`✅ *Hasil Style Text:*\n\n${styledTexts}`)

 } catch (err) {
  console.error(err)
  cht.reply('⚠️ Terjadi kesalahan saat memproses permintaan.')
 }
});


  ev.on(
    {
      cmd: ['ss', 'ssweb'],
      listmenu: ['ssweb'],
      tag: 'tools',
      energy: 7.5,
      urls: {
        msg: true,
      },
    },
    async () => {
      let q = is.quoted?.url || is.url;
      Exp.sendMessage(
        id,
        {
          image: {
            url:
              'https://image.thum.io/get/width/1900/crop/1000/fullpage/' + q[0],
          },
          caption: `Result✔️`,
        },
        { quoted: cht }
      );
    }
  );

  ev.on(
    {
      cmd: [
        'musixsearch',
        'searchmusic',
        'whatmusic',
        'searchsong',
        'musicrecognition',
      ],
      listmenu: ['whatmusic'],
      tag: 'tools',
      energy: 10,
      media: {
        type: ['audio'],
      },
    },
    async ({ media }) => {
      await cht.edit('Bntar tak dengerin dulu...', keys[sender]);
      musixSearch(media).then((a) => cht.reply(a));
    }
  );

  ev.on(
    {
      cmd: ['audio2text', 'audio2txt', 'transcribe'],
      listmenu: ['transcribe'],
      tag: 'tools',
      energy: 25,
      media: {
        type: ['audio'],
      },
    },
    async ({ media }) => {
      transcribe(media).then((a) => cht.reply(a.text));
    }
  );

  ev.on(
    {
      cmd: ['getchid', 'getchannelid', 'getsaluranid', 'getidsaluran'],
      listmenu: ['getchid'],
      tag: 'tools',
      energy: 10,
      isQuoted: 'Reply pesan yang diteruskan dari saluran!',
    },
    async () => {
      try {
        let res = (await store.loadMessage(id, cht.quoted.stanzaId)).message[
          cht.quoted.type
        ].contextInfo.forwardedNewsletterMessageInfo;
        if (!res) return cht.reply('Gagal, id saluran mungkin tidak tersedia');
        cht.edit(
          `[ *📡ID SALURAN/CH* ]` +
            `\nID Saluran: ${res.newsletterJid}` +
            `\nID Pesan: ${res.serverMessageId}`,
          keys[sender]
        );
      } catch (e) {
        cht.reply('Error get Channel id' + e.message);
      }
    }
  );

  ev.on(
    {
      cmd: ['colong', 'c'],
      listmenu: ['colong'],
      tag: 'tools',
      premium: true,
    },
    async ({ cht }) => {
      try {
        if (!cht.quoted) return;
        let res = (await store.loadMessage(id, cht.quoted.stanzaId)).message;
        let evaled =
          `(async()=>{let msg = await generateWAMessageFromContent(cht.sender, ${JSON.stringify(res, null, 2)}, {})` +
          `\n  await Exp.relayMessage(msg.key.remoteJid, msg.message, {` +
          `\n      messageId: msg.key.id` +
          `\n  })` +
          `\n})()`;

        let random = Math.floor(Math.random() * 10000);
        await eval(`ev.on({ 
             cmd: ['${random}'],
             listmenu: ['${random}'],
             tag: 'other'
         }, async({ cht }) => {
             ${evaled.replace('cht.sender', 'cht.id')}
         })`);
        await sleep(3000);
        // await cht.reply(`Code telah dikirimkan melalui chat pribadi!. Ketik .${random} Untuk melihat hasil`)
        await sleep(3000);
        await Exp.sendMessage(semder, { text: evaled }, { quoted: cht });
      } catch (e) {
        console.log(cht.quoted);
      }
    }
  );

  ev.on(
    {
      cmd: ['vocalremover', 'stems'],
      listmenu: ['vocalremover'],
      tag: 'tools',
      energy: 50,
      media: {
        type: ['audio'],
        msg: 'Mana audionya?',
      },
    },
    async ({ media }) => {
      await cht.edit('Tunggu ya, sabar', keys[sender]);
      let response = await fetch(
        `${api.xterm.url}/api/audioProcessing/stems?key=${api.xterm.key}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/octet-stream',
          },
          body: media,
        }
      );
      let a = (await response.json()).data;
      await Exp.sendMessage(
        id,
        { audio: { url: a[0].link }, mimetype: 'audio/mpeg' },
        { quoted: cht }
      );
      await Exp.sendMessage(
        id,
        { audio: { url: a[1].link }, mimetype: 'audio/mpeg' },
        { quoted: cht }
      );
    }
  );

  ev.on(
    {
      cmd: ['enc', 'encryptjs', 'encrypt'],
      listmenu: ['encryptjs'],
      tag: 'tools',
      args: 'Mana code js nya?',
      energy: 2,
    },
    async () => {
      let res = await EncryptJs(cht.q);
      Exp.sendMessage(
        cht.id,
        {
          document: Buffer.from(res.data),
          mimetype: 'application/javascript',
          fileName: 'encrypt.js',
        },
        { quoted: cht }
      );
    }
  );

  ev.on(
    {
      cmd: ['removebg'],
      listmenu: ['removebg'],
      tag: 'tools',
      energy: 15,
      media: {
        type: ['image'],
      },
    },
    async ({ media }) => {
      const _key = keys[sender];
      await cht.edit('Bntr...', _key);
      let tph = await TermaiCdn(await func.minimizeImage(media));
      await cht.edit('Processing...', _key);
      let res = (
        await fetch(
          api.xterm.url +
            '/api/tools/image-removebg?url=' +
            tph +
            '&key=' +
            api.xterm.key
        ).then((a) => a.json())
      ).data;
      await Exp.sendMessage(id, { image: { url: res.url } }, { quoted: cht });
    }
  );

  ev.on(
    {
      cmd: ['objectdetection'],
      listmenu: ['objectdetection'],
      tag: 'tools',
      energy: 15,
      media: {
        type: ['image'],
      },
    },
    async ({ media }) => {
      const _key = keys[sender];
      await cht.edit('Bntr...', _key);
      let tph = await TermaiCdn(await func.minimizeImage(media));
      await cht.edit('Processing...', _key);
      let res = await fetch(
        api.xterm.url +
          '/api/tools/object-detection?url=' +
          tph +
          '&key=' +
          api.xterm.key
      ).then((a) => a.json());
      let result = `Status: ${res.status}\n`;
      result += `Image URL: ${res.url}\n\n`;

      res.DetectedObjects.forEach((object, index) => {
        result += `Object ${index + 1}:\n`;
        result += `  Label  : ${object.Label}\n`;
        result += `  Score  : ${(object.Score * 100).toFixed(2)}%\n`;
        result += `  Bounds :\n`;
        result += `    X     : ${object.Bounds.X}\n`;
        result += `    Y     : ${object.Bounds.Y}\n`;
        result += `    Width : ${object.Bounds.Width}\n`;
        result += `    Height: ${object.Bounds.Height}\n\n`;
      });
      await Exp.sendMessage(
        id,
        { image: { url: res.url }, caption: result },
        { quoted: cht }
      );
    }
  );

  ev.on(
    {
      cmd: ['hextorgba', 'rgbatohex', 'change'],
      listmenu: ['hextorgba', 'rgbatohex'],
      tag: 'tools',
      args: 'Sertakan rgba atau hex untuk di konversi?',
      energy: 2,
    },
    async ({ args }) => {
      let [r, g, b, a] = args.match(/\((.*?)\)/)[1].split(',');
      if (/rgb/.test(args)) return cht.reply(func.rgbaToHex(r, g, b, a));
      func.hexToRgba(args);
    }
  );
}