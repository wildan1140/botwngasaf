/*!-======[ Module Imports ]======-!*/
const fs = "fs".import()
const path = "path".import()
const { getContentType, generateWAMessage, STORIES_JID, generateWAMessageFromContent } = "baileys".import()

export default async function on({ cht, Exp, store, ev, is }) {
  let infos = Data.infos
  const { func } = Exp
  const { getDirectoriesRecursive, archiveMemories: memories } = func
  const { id, sender } = cht
  
  ev.on({
    cmd: ['addcmd'],
    listmenu: ['addcmd'],
    tag: 'owner',
    isOwner: true,
    args: 'Example .addcmd <code>'
  }, async ({ args, cht }) => {
    const syntaxError = (await import('syntax-error')).default

    if (!args || !args.trim().startsWith('ev.on')) {
      return cht.reply('Example .addcmd <code>')
    }

    const code = args.trim()
    const tagMatch = code.match(/tag\s*:\s*['"`]([^'"`]+)['"`]/)
    if (!tagMatch) return cht.reply('Gagal membaca tag. Pastikan ada `tag: "namatag"` dalam ev.on().')

    const tag = tagMatch[1].toLowerCase()
    const filePath = path.resolve(`./helpers/Events/${tag}.js`)
    const dir = path.dirname(filePath)

    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })

    try {
      let insert = `\n  // Auto inserted by .addcmd at ${new Date().toLocaleString()}\n  ${code.replace(/\n/g, '\n  ')}\n`

      if (!fs.existsSync(filePath)) {
        let full = `// ${tag} commands\n\nexport default async function on(ev) {${insert}}\n`
        const error = syntaxError(full, 'newfile.js', {
          sourceType: 'module',
          allowReturnOutsideFunction: true,
          allowAwaitOutsideFunction: true
        })
        if (error) return cht.reply(`Terdapat syntax error:\n\n${error}`)
        fs.writeFileSync(filePath, full)
      } else {
        let old = fs.readFileSync(filePath, 'utf-8')
        if (!old.includes('export default async function on')) {
          return cht.reply('File tidak sesuai format on(ev). Tidak bisa disisipkan.')
        }

        const error = syntaxError(code, 'append.js', {
          sourceType: 'module',
          allowReturnOutsideFunction: true,
          allowAwaitOutsideFunction: true
        })
        if (error) return cht.reply(`Terdapat syntax error:\n\n${error}`)

        const newContent = old.replace(/\}\s*$/, insert + '}')
        fs.writeFileSync(filePath, newContent)
      }

      await cht.reply(`Command berhasil ditambahkan ke file *${tag}.js*\nLokasi: helpers/Events/${tag}.js`)
    } catch (e) {
      console.error('Addcmd Error:', e)
      await cht.reply('Gagal menyimpan command. Silakan cek console log.')
    }
  })
  
  ev.on({
  cmd: ['jpm'],
  listmenu: ['jpm'],
  tag: "owner",
  isOwner: true,
}, async ({ cht, args }) => {
  const delayjpm = 1500
  const text = Array.isArray(args) ? args.join(' ') : String(args || '')
  if (!text && !cht.quoted) return cht.reply("*❗ Masukkan teks atau balas pesan yang berisi teks.*")

  const teks = cht.quoted?.text || text
  let total = 0

  const allGroups = await Exp.groupFetchAllParticipating()
  const groupList = Object.values(allGroups)
  const groupIds = groupList.map(group => group.id)
  const metadata = await Exp.groupMetadata(cht.id)
  const mentions = metadata.participants.map(p => p.id)
      
  await Exp.sendMessage(cht.id, {
    text: `📨 Mengirim pesan ke *${groupIds.length} grup*...\nHarap tunggu sebentar...`,
    contextInfo: {
      externalAdReply: {
        title: `Wait Kak ${cht.pushName}`,
        body: `© Elaina MD V1.0`,
        thumbnail: fs.readFileSync(fol[10] + 'ch3.jpg'),
        mediaUrl: `https://chat.whatsapp.com/IRCN3GDrdAG74X98zDi5Hc`,
        sourceUrl: `https://www.tiktok.com/@barzz918`,
        renderLargerThumbnail: false,
        showAdAttribution: true,
        mediaType: 2,
      },
      forwardingScore: 999,
      isForwarded: true,
    }
  }, { quoted: cht })

  for (let jid of groupIds) {
    try {
      const messageText = `
📢 *PESAN DARI OWNER ${cht.pushName || 'BAGUS DEV'}*

*Informasi:*
- ${teks || 'Aku pedo dan aku bangga'}
      `.trim()

      await Exp.sendMessage(jid, {
        text: messageText,
        contextInfo: {
          externalAdReply: {
            title: `Information From The Owner`,
            body: `© Elaina MD V1.0`,
            thumbnail: fs.readFileSync(fol[10] + `${haSil2}`),
            mediaUrl: `https://chat.whatsapp.com/IRCN3GDrdAG74X98zDi5Hc`,
            sourceUrl: `https://www.tiktok.com/@barzz918`,
            renderLargerThumbnail: false,
            showAdAttribution: true,
            mediaType: 2,
          },
          forwardingScore: 999,
          isForwarded: true,
          mentionedJid: mentions
        }
      })

      total++
    } catch (err) {
      console.log(`❌ Gagal kirim ke ${jid}:`, err?.message || err)
    }
    await sleep(delayjpm)
  }

  await Exp.sendMessage(cht.id, {
    text: `✅ Selesai!\nPesan berhasil dikirim ke *${total} grup* dari *${groupIds.length} grup* total.`,
    contextInfo: {
      externalAdReply: {
        title: `Selesai Kak ${cht.pushName}`,
        body: `© Elaina MD V1.0`,
        thumbnail: fs.readFileSync(fol[10] + 'ch3.jpg'),
        mediaUrl: `https://chat.whatsapp.com/IRCN3GDrdAG74X98zDi5Hc`,
        sourceUrl: `https://www.tiktok.com/@barzz918`,
        renderLargerThumbnail: false,
        showAdAttribution: true,
        mediaType: 2,
      },
      forwardingScore: 999,
      isForwarded: true,
    }
  }, { quoted: cht })
})

  ev.on({
    cmd: ['delcmd'],
    listmenu: ['delcmd'],
    tag: 'owner',
    isOwner: true,
    args: 'Contoh: .delcmd pingl\nPastikan cmd menggunakan *listmenu* agar dapat dikenali.'
  }, async ({ args, cht }) => {
    const cmd = args?.toLowerCase()?.trim()
    if (!cmd) return cht.reply('Contoh: *.delcmd pingl*')

    const folder = 'helpers/Events'
    let fileKetemu = null
    let blokTerhapus = null

    function hapusBlokEvOn(filePath) {
      const isi = fs.readFileSync(filePath, 'utf-8')
      const baris = isi.split('\n')
      let dalamEvOn = false
      let blokSementara = []
      let depth = 0
      let mulaiIndex = -1
      let akhirIndex = -1

      for (let i = 0; i < baris.length; i++) {
        const line = baris[i]

        if (!dalamEvOn && line.includes('ev.on({')) {
          dalamEvOn = true
          blokSementara = [line]
          mulaiIndex = i
          depth = (line.match(/{/g) || []).length - (line.match(/}/g) || []).length
          continue
        }

        if (dalamEvOn) {
          blokSementara.push(line)
          depth += (line.match(/{/g) || []).length
          depth -= (line.match(/}/g) || []).length

          if (depth <= 0 || i === baris.length - 1) {
            akhirIndex = i
            const fullBlok = blokSementara.join('\n')
            if (fullBlok.toLowerCase().includes(`'${cmd}'`) || fullBlok.toLowerCase().includes(`"${cmd}"`)) {
              const barisAkhir = baris[baris.length - 1].trim()
              const hapusTerakhir = akhirIndex === baris.length - 1 && barisAkhir === '}'
              const hapusCount = hapusTerakhir ? akhirIndex - mulaiIndex : akhirIndex - mulaiIndex + 1

              baris.splice(mulaiIndex, hapusCount)
              fs.writeFileSync(filePath, baris.join('\n'))

              fileKetemu = filePath
              blokTerhapus = fullBlok
            }

            dalamEvOn = false
            blokSementara = []
          }
        }
      }
    }

    function scanFolder(folderPath) {
      const files = fs.readdirSync(folderPath)
      for (let file of files) {
        const fullPath = path.join(folderPath, file)
        if (fs.statSync(fullPath).isDirectory()) {
          scanFolder(fullPath)
        } else if (file.endsWith('.js')) {
          hapusBlokEvOn(fullPath)
          if (blokTerhapus) break
        }
      }
    }

    scanFolder(folder)

    if (!blokTerhapus) {
      return cht.reply(`Tidak menemukan command *.${cmd}* untuk dihapus.`)
    }

    await cht.reply(`Command *.${cmd}* berhasil dihapus dari file *${path.basename(fileKetemu)}*`)
    return cht.reply(`${blokTerhapus.trim()}`)
  })
  
  ev.on({
  cmd: ['carifitur'],
  isOwner: true,
  listmenu: ['carifitur'], 
  tag: 'owner', 
  args: 'Masukkan nama command yang ingin dicari, contoh: .carifitur topenergy'
}, async ({ args, cht }) => {
  const cari = args?.toLowerCase()?.trim()
  if (!cari) return cht.reply('❓ Masukkan nama command yang ingin dicari.\nContoh: *.carifitur unduh*')

  const folder = fol[7]
  let ditemukan = null

  function scanFile(filePath) {
    const isi = fs.readFileSync(filePath, 'utf-8').toLowerCase()
    const adaCmd = isi.includes(`cmd: [`) && isi.includes(`'${cari}'`)
    const adaList = isi.includes(`listmenu: [`) && isi.includes(`'${cari}'`)

    if (adaCmd || adaList) {
      ditemukan = filePath
    }
  }

  function scanFolder(folderPath) {
    const files = fs.readdirSync(folderPath)
    for (let file of files) {
      const fullPath = path.join(folderPath, file)
      if (fs.statSync(fullPath).isDirectory()) {
        scanFolder(fullPath)
      } else if (file.endsWith('.js')) {
        scanFile(fullPath)
        if (ditemukan) break
      }
    }
  }

  scanFolder(folder)

  if (!ditemukan) return cht.reply(`❌ Command *.${cari}* tidak ditemukan di folder *helpers/Events/*`)

  const fileName = path.basename(ditemukan)
  return cht.reply(`✅ Command *.${cari}* ditemukan di file: *${fileName}*`)
})

  ev.on({
    cmd: ['getcmd'],
    listmenu: ['getcmd'],
    tag: 'owner',
    isOwner: true,
    args: 'Contoh: .getcmd ping\nPastikan cmd menggunakan *listmenu* agar dapat dikenali.'
  }, async ({ args, cht }) => {
    const cmd = args?.toLowerCase()?.trim()
    if (!cmd) return cht.reply('Contoh: *.getcmd ping*')

    const folder = 'helpers/Events'
    let fileKetemu = null
    let blokKetemu = null

    function ambilBlokEvOnLengkap(filePath) {
      const isi = fs.readFileSync(filePath, 'utf-8')
      const baris = isi.split('\n')
      let dalamEvOn = false
      let blokSementara = []
      let depth = 0

      for (let i = 0; i < baris.length; i++) {
        const line = baris[i]

        if (!dalamEvOn && line.includes('ev.on({')) {
          dalamEvOn = true
          blokSementara = [line]
          depth = (line.match(/{/g) || []).length - (line.match(/}/g) || []).length
          continue
        }

        if (dalamEvOn) {
          blokSementara.push(line)
          depth += (line.match(/{/g) || []).length
          depth -= (line.match(/}/g) || []).length

          if (depth <= 0 || i === baris.length - 1) {
            const fullBlok = blokSementara.join('\n')
            if (fullBlok.toLowerCase().includes(`'${cmd}'`) || fullBlok.toLowerCase().includes(`"${cmd}"`)) {
              blokKetemu = fullBlok
              fileKetemu = filePath
              break
            } else {
              dalamEvOn = false
              blokSementara = []
            }
          }
        }
      }
    }

    function scanFolder(folderPath) {
      const files = fs.readdirSync(folderPath)
      for (let file of files) {
        const fullPath = path.join(folderPath, file)
        if (fs.statSync(fullPath).isDirectory()) {
          scanFolder(fullPath)
        } else if (file.endsWith('.js')) {
          ambilBlokEvOnLengkap(fullPath)
          if (blokKetemu) break
        }
      }
    }

    scanFolder(folder)

    if (!blokKetemu) {
      return cht.reply(`Tidak menemukan command *.${cmd}* dalam folder *${folder}*`)
    }

    await cht.reply(`Command *.${cmd}* ditemukan di file *${path.basename(fileKetemu)}*`)
    return cht.reply(`${blokKetemu.trim()}`)
  })

  ev.on({
    cmd: ['caricmd'],
    isOwner: true,
    listmenu: ['caricmd'], 
    tag: 'owner', 
    args: 'Masukkan nama command yang ingin dicari, contoh: ping'
  }, async ({ args, cht }) => {
    const cari = args?.toLowerCase()?.trim()
    if (!cari) return cht.reply('Masukkan nama command yang ingin dicari.\nContoh: *.caricmd unduh*')

    const folder = 'helpers/Events'
    let ditemukan = null

    function scanFile(filePath) {
      const isi = fs.readFileSync(filePath, 'utf-8').toLowerCase()
      const adaCmd = isi.includes(`cmd: [`) && isi.includes(`'${cari}'`)
      const adaList = isi.includes(`listmenu: [`) && isi.includes(`'${cari}'`)

      if (adaCmd || adaList) {
        ditemukan = filePath
      }
    }

    function scanFolder(folderPath) {
      const files = fs.readdirSync(folderPath)
      for (let file of files) {
        const fullPath = path.join(folderPath, file)
        if (fs.statSync(fullPath).isDirectory()) {
          scanFolder(fullPath)
        } else if (file.endsWith('.js')) {
          scanFile(fullPath)
          if (ditemukan) break
        }
      }
    }

    scanFolder(folder)

    if (!ditemukan) return cht.reply(`Command *.${cari}* tidak ditemukan di folder *helpers/Events/*`)

    const fileName = path.basename(ditemukan)
    return cht.reply(`Command *.${cari}* ditemukan di file: *${fileName}*`)
  })
    
  ev.on({
    cmd: ['editcmd'],
    listmenu: ['editcmd'],
    tag: 'owner',
    isOwner: true,
    args: 'Contoh: .editcmd ping <kode JS baru>\nPastikan cmd menggunakan *listmenu* agar dapat dikenali.'
  }, async ({ args, cht }) => {
    const syntaxError = (await import('syntax-error')).default
    const [cmd, ...potongan] = args.trim().split(' ')
    const kodeBaru = potongan.join(' ').trim()

    if (!cmd || !kodeBaru) return cht.reply('Contoh: *.editcmd ping <kode>*')

    const folder = 'helpers/Events'
    let fileKetemu = null
    let blokLama = null
    let indexMulai = -1, indexAkhir = -1

    function editEvOn(filePath) {
      const isi = fs.readFileSync(filePath, 'utf-8')
      const baris = isi.split('\n')
      let dalamEvOn = false
      let blokSementara = []
      let depth = 0

      for (let i = 0; i < baris.length; i++) {
        const line = baris[i]

        if (!dalamEvOn && line.includes('ev.on({')) {
          dalamEvOn = true
          blokSementara = [line]
          indexMulai = i
          depth = (line.match(/{/g) || []).length - (line.match(/}/g) || []).length
          continue
        }

        if (dalamEvOn) {
          blokSementara.push(line)
          depth += (line.match(/{/g) || []).length
          depth -= (line.match(/}/g) || []).length

          if (depth <= 0 || i === baris.length - 1) {
            indexAkhir = i
            const blokGabung = blokSementara.join('\n')
            if (blokGabung.toLowerCase().includes(`'${cmd}'`) || blokGabung.toLowerCase().includes(`"${cmd}"`)) {
              fileKetemu = filePath
              blokLama = blokGabung
            }
            dalamEvOn = false
            blokSementara = []
          }
        }
      }

      if (fileKetemu) {
        const error = syntaxError(kodeBaru, 'edit.js', {
          sourceType: 'module',
          allowReturnOutsideFunction: true,
          allowAwaitOutsideFunction: true
        })
        if (error) return cht.reply(`Syntax error:\n\n${error}`)

        const newLines = [
          `  // Diedit otomatis via .editcmd pada ${new Date().toLocaleString()}`,
          ...kodeBaru.split('\n').map(line => '  ' + line)
        ]
        baris.splice(indexMulai, indexAkhir - indexMulai + 1, ...newLines)
        fs.writeFileSync(filePath, baris.join('\n'))
      }
    }

    function scanFolder(folderPath) {
      const files = fs.readdirSync(folderPath)
      for (let file of files) {
        const fullPath = path.join(folderPath, file)
        if (fs.statSync(fullPath).isDirectory()) {
          scanFolder(fullPath)
        } else if (file.endsWith('.js')) {
          editEvOn(fullPath)
          if (blokLama) break
        }
      }
    }

    scanFolder(folder)

    if (!blokLama) return cht.reply(`Tidak menemukan command *.${cmd}* untuk diedit.`)

    await cht.reply(`Command *.${cmd}* berhasil diedit di file *${path.basename(fileKetemu)}*`)
    return cht.reply(`Blok yang digantikan:\n${blokLama.trim()}`)
  })  
  
  ev.on({
    cmd: ['getfile'],
    listmenu: ['getfile'], 
    tag: ['owner'], 
    isOwner: true,
    args: 'Contoh: .getfile ping.js'
  }, async ({ args, cht }) => {
    const nama = args?.trim()
    if (!nama) return cht.reply('Contoh: .getfile ping.js')

    const filePath = path.resolve('./helpers/Events/' + nama)
    if (!fs.existsSync(filePath)) return cht.reply('File tidak ditemukan.')

    const isi = fs.readFileSync(filePath, 'utf-8')

    if (!isi.trim()) return cht.reply('File kosong.')

    return cht.reply(`Isi file *${nama}* (${isi.length} karakter):\n\n${isi}`) 
  })
}